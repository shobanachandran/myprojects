<?php
include('includes/config.php');

	if($_SESSION['userid']==''){
		echo "<script>window.location.href='login.php';</script>";
	}

	if($_GET['id']!=''){
		$id = $_GET['id'];
	} else {
		$id = $_REQUEST['costing_no'];
	}

	if(isset($_POST['save'])){
		$process_sql = mysqli_query($zconn,"insert into process_planning_master(order_no,style_no,total_loss,created_by,created_date) values('".$_POST['sel_order']."','".$_POST['txt_style']."','".$_POST['total_loss']."','".$_SESSION['userid']."',now())");
		$process_id = mysqli_insert_id($zconn);
		$trows = count($_POST['fabric_name']);
		for($tr=0;$tr<$trows;$tr++){
			$ins_details = mysqli_query($zconn,"insert into process_planning(fabric_name,process_id,process_name,
			sub_process_name,ycolor,content,ycomp,dia,gsm,wgt,total_weight,rate_kg,rate_pc,rows_total,process_loss,order_no,style_no)
			 values('".$_POST['fabric_name'][$tr]."','".$process_id."','".$_POST['process_name'][$tr]."',
			 '".$_POST['subprocess_name'][$tr]."','".$_POST['ycolor'][$tr]."','".$_POST['content'][$tr]."','".$_POST['ycomp'][$tr]."',
			 '".$_POST['dia'][$tr]."','".$_POST['gsm'][$tr]."','".$_POST['wgt'][$tr]."','".$_POST['total_weight'][$tr]."',
			 '".$_POST['rate'][$tr]."','".$_POST['rate_pcs'][$tr]."','".$_POST['total'][$tr]."',
			 '".$_POST['process_loss'][$tr]."','".$_POST['sel_order']."','".$_POST['txt_style']."')");
		}
		if($process_sql){
			echo "<script>alert('Added Successfully!!!');</script>";
			echo "<script>window.location.href='process_planning_list.php';</script>";
		}
    }

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - Other Process Costing Entry</title>
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
	<link href="dist/css/bootstrap-datepicker.css" rel="stylesheet">

	<link href="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.min.css" rel="stylesheet"/>
	<script src="dist/js/jquery.min.js"></script>
	<script src="dist/js/chosen.jquery.min.js"></script>


	<style>
        /* CSS for the container */
        .scroll-container {
            width: 100%; /* Set the width as needed */
            overflow-x: auto; /* Enable horizontal scrolling */
        }
		.hidden {
    display: none;
}
.table-container {
            width: 100%; /* Set the width as needed */
            overflow-x: auto; /* Enable horizontal scrolling */
            white-space: nowrap; /* Prevent text wrapping */
        }

        th {
            font-size: 12px;
            font-weight: bold;
            background-color: #626F80;
            color: #fff;
            text-align: center;
        }

    </style>
</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php  include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- Page wrapper  -->
        <div class="page-wrapper" style="min-height: 100%; height: auto;">
            <!-- Bread crumb and right sidebar toggle -->
                          <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Process Planning</h4>
						&nbsp;&nbsp;&nbsp;&nbsp;<a href="planning.php"> <button type="button" class="btn btn-info">Planning Process</button></a>
						<div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item " aria-current="page">Merch</li>
									<!-- <li class="breadcrumb-item " aria-current="page"><a href="costing.php">Costing</a></li> -->
									<li class="breadcrumb-item active" aria-current="page"><a href="planning.php">Process Palnning</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- Sales chart -->
				<form name="other_process" method="post">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
								<div class="card-body" style="width:100%">
									<div class="card-body" style="width:100%">
										<div class="card" style="width:50%; float:left; left: 50px; ">
										<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">Indent No</label>
										<div class="col-sm-6">
                                			<select class="select2 form-control custom-select chosen-select" name="sel_order" id="sel_order" required onchange="this.form.submit();">
                                				<option value="">--Select--</option>
                                			      <?php
											
												  $sel_buyer = mysqli_query($zconn,"select * from order_entry_master where (`order_no`,`style_no`) NOT IN(select order_no,style_no from process_planning_master)  and (`order_no`,`style_no`) IN (select order_no,style_no from process_planning_flow)");

												while($res_buyer =mysqli_fetch_array($sel_buyer,MYSQLI_ASSOC)){
													if($_POST['sel_order']==$res_buyer['order_no']){ ?>
													   <option selected value="<?php echo $res_buyer['order_no'];?>"><?php echo $res_buyer['order_no'];?></option>
													   <?php } else { ?>
													   <option value="<?php echo $res_buyer['order_no'];?>"><?php echo $res_buyer['order_no'];?></option>
													   <?php } ?>
													   <?php } ?>
                                			</select>
										





										</div>
									</div>

		<?php $sel_style = mysqli_fetch_array(mysqli_query($zconn,"select * from order_entry_master where order_no='".$_POST['sel_order']."'"),MYSQLI_ASSOC);
			$order_date_arr = explode(" ",$sel_style['created_date']);
			$order_dt_arr = explode("-",$order_date_arr['0']);
			$order_date = $order_dt_arr['2']."-".$order_dt_arr['1']."-".$order_dt_arr['0'];
		?>
		<div class="form-group row">
			<label for="fname" class="col-sm-3 text-right control-label col-form-label">Style Code</label><div class="col-sm-6">
			<?php $sel_styles = mysqli_query($zconn,"select * from order_entry_master where order_no='".$_POST['sel_order']."'");
			?>
			<select name="txt_style" id="txt_style" class="select2 form-control custom-select chosen-select" onchange="this.form.submit();">
				<option value="">--Select--</option>
				<?php while($res_style = mysqli_fetch_array($sel_styles,MYSQLI_ASSOC)){?>
				<option value="<?php echo $res_style['style_no'];?>" <?php if($_POST['txt_style']==$res_style['style_no']){echo "selected";}?>><?php echo $res_style['style_no'];?></option>
				<?php } ?>
			</select>
			<script type="text/javascript">
												$(".chosen-select").chosen({
											  	no_results_text: "Oops, nothing found!"
												})
											</script>
			<!--<input type="text" name="txt_style" id="txt_style" value="<?php echo $sel_style['style_no'];?>" class="form-control" readonly>-->
			</div>
		</div>

	</div>
	<div class="card" style="width:50%; float:left; right: 50px;">
		<div class="form-group row">
			<label for="fname" class="col-sm-3 text-right control-label col-form-label">Buyer name</label>
			<div class="col-sm-6"><input type="text" name="buyer_name" id="buyer_name" value="<?php echo $sel_style['buyer_name'];?>" class="form-control" readonly>
			</div>
		</div>
		<div class="form-group row">
			<label for="cono1" class="col-sm-3 text-right control-label col-form-label">Order Date</label>
			<div class="col-sm-6">
			<?php if($_REQUEST['sel_order']!=''){ ?>
				<input type="text" class="form-control"  value="<?php echo $order_date; ?>" readonly id="order_date">
			<?php } else{ ?>
				<input type="text" class="form-control" value="<?php echo $sel_c['costing_date']; ?>" readonly id="order_date">
			<?php } ?>	
				</div>
				</div>
			</div>
		</div>

		
	<div class="form-group">
		<h4 class="page-title"><b>Component Details</b></h4>
	</div>
	<table id="example" class="table table-striped table-bordered">
		<thead style="background-color: #626F80; color: #fff; padding: 0px; font-size: 16px;">
			<tr>
				<th>Indent No</th>
				<th>Style Code</th>
				<th>Pcs Weight</th>
				<th>Order Quantity + Excess</th>
				<th>Total Weight [KGS]</th>
			</tr>
		</thead>
        	<?php
        	 $coso = mysqli_fetch_array(mysqli_query($zconn,"SELECT * FROM `costing_entry_master` where order_no='".$_REQUEST['sel_order']."' and style_no='".$_REQUEST['txt_style']."'"),MYSQLI_ASSOC);
			 $cost_ido=$coso['id'];
			 if ($cost_ido!='') {
			 $cos = mysqli_fetch_array(mysqli_query($zconn,"SELECT * FROM `costing_entry_master` where order_no='".$_REQUEST['sel_order']."' and style_no='".$_REQUEST['txt_style']."'"),MYSQLI_ASSOC);
			 $sel_c = mysqli_query($zconn,"SELECT *  FROM `costing_entry_details` where costing_id='".$cos['id']."'");
			 $order = mysqli_fetch_array(mysqli_query($zconn,"SELECT * FROM `order_entry_master` where order_no='".$_REQUEST['sel_order']."' and style_no='".$_REQUEST['txt_style']."'"),MYSQLI_ASSOC);	
			 }
			 else{
			 $cos = mysqli_fetch_array(mysqli_query($zconn,"SELECT * FROM `order_entry_master` where order_no='".$_REQUEST['sel_order']."' and style_no='".$_REQUEST['txt_style']."'"),MYSQLI_ASSOC);
			 $sel_0 = mysqli_query($zconn,"SELECT * FROM `order_quantity_details` where yarn_id='".$cos['id']."'");

			 $order = mysqli_fetch_array(mysqli_query($zconn,"SELECT * FROM `order_entry_master` where order_no='".$_REQUEST['sel_order']."' and style_no='".$_REQUEST['txt_style']."'"),MYSQLI_ASSOC);
			 }

			if ($sel_c!='') {
				$sel=$sel_c;
				$tb="costing_entry_details";
				$cond="costing_id";
			} else {
				$sel=$sel_0;
				$tb="yarn_entry_details";
				$cond="yarn_id";
			}
			$tow =0;
			while($resc=mysqli_fetch_array($sel)){ 
			 	$pcs = mysqli_fetch_array(mysqli_query($zconn,"SELECT sum(pcs_weight) as pcs_weight FROM $tb where  $cond='".$cos['id']."'"),MYSQLI_ASSOC);

			//	$exc_cal = ($order['excess_percent']*$order['order_qty'])/100;
				$exc_cal = ($order['excess_percent']*$order['cutting_qty'])/100;
				$excess_cal = $order['cutting_qty'];

			//	$print_order_qty = $order['order_qty']*$order['excess_percent'];
			$pcsweight = number_format($resc['pcs_weight'], 2, '.', "");
			$tow =$pcsweight*$excess_cal;
			 	?>
				<tr>
					<td><?php echo $_REQUEST['sel_order'];?></td>
					<td><?php echo $_REQUEST['txt_style'];?></td>
					<td><?php echo $pcsweight;?><input type="hidden" name="pcs_weight" class="form-control" value="<?php echo $resc['pcs_weight'];?>"></td>
					<td><?php echo $excess_cal;?><input type="hidden" name="order_qty" class="form-control"  value="<?php echo $excess_cal;?>"></td>
					<td><?php echo number_format($tow, 2, '.', "");?><input type="hidden" name="totweight[]" class="form-control" value="<?php echo number_format($tow, 2, '.', "");?>" id="totweight"></td>
				</tr>
			<?php }
			 ?>
    </table>

		<h4 class="page-title"><b>Material Details</b></h4>
		<?php
		$check_cost = mysqli_query($zconn,"select * from other_costing_list where order_no='".$_POST['sel_order']."' AND  style_no='".$_POST['txt_style']."'");
		$row_cost = mysqli_num_rows($check_cost);
		?>
		<div class="table-container" >
		<table id="material"  style="width:150%">
			<thead style="background-color: #626F80; color: #fff; padding: 0px; font-size: 12px;">
				<tr>
					<th style="width: 10%;">Fabric Name</th>
				    <!-- <th style="width: 15%;">colour</th> -->
					<th style="width: 10%;">Process Name</th>
					<th style="width: 10%;">Color</th>
					<th style="width: 10%;">Content</th>
					<th style="width: 10%;">Component</th>
					<th style="width: 10%;">Dia</th>
					<th style="width: 10%;">Gsm</th>
					<th style="width: 12%;">Weight</th>
					<!-- <th style="width: 11%;">Rate/Kg</th> -->
					<!--<th style="width: 11%;">Rate/PC</th>-->
					<th style="width: 10%;">Process Loss</th>
					<th style="width: 12%;">Total</th>
					<?php //if($row_cost=="0"){?>
					<th style="width: 6%;"><button type="button" class="btn btn-info add-new"><i class="fa fa-plus"></i></button></th>
					<?php //} ?>
				</tr>
			</thead>
		<tbody>

		<?php
				if($row_cost>0){ // if it has costing entry
					$res_cost = mysqli_fetch_array($check_cost,MYSQLI_ASSOC);
					$totalwgt=0;
					$total_rate = 0;
					$totalloss=0;
					$sel_costing1 = mysqli_query($zconn,"select * from other_costing WHERE `costing_no` ='".$res_cost['costing_no']."'");
					$rows_costing1 = mysqli_num_rows($sel_costing1);

					if($rows_costing1>0){ ?>
					<?php 
					$f = 0;
					while($res_costing1 = mysqli_fetch_array($sel_costing1,MYSQLI_ASSOC)){

				?>
						<tr id="delete_1">
							<td>
								<select  class="select2  form-control custom-select chosen-select"  data-no="<?php echo $f; ?>" name="fabric_name[]" id="fabric_name<?php echo $f; ?>" onchange="fabric(this);">
									<?php $fabrics = explode(",",$res_costing1['fabric_name']); ?>

									<?php 
							$sel_cost_details1 = mysqli_query($zconn,"select * from other_costing WHERE `costing_no` ='".$res_cost['costing_no']."'");
							while($res_det1 = mysqli_fetch_array($sel_cost_details1,MYSQLI_ASSOC)) {
								if(in_array($res_det1['fabric_name'], $fabrics)) 
								{
									$selected = "selected";
								} else {
									$selected = "";
								}
							?>
							<option value="<?php echo $res_det1['fabric_name'];?>" <?php echo $selected; ?>><?php echo $res_det1['fabric_name'];?></option>
							<?php } ?>
						</select>
						<script type="text/javascript">
												$(".chosen-select").chosen({
											  	no_results_text: "Oops, nothing found!"
												})
											</script>
					</td>

							
								<!-- <td>
								<span>
				<!?php
					$sel_sub = mysqli_query($zconn,"select * from sub_process where process_name='".$res_costing1["process_name"]."'");
					while($res_sub = mysqli_fetch_array($sel_sub,MYSQLI_ASSOC)){
						$sub_id = $res_sub['id'];
						$sub_name = $res_sub['sub_process_name'];
						if($res_costing1['subprocess_name'] == $sub_id) {
							$sel_sub = "selected";
						} else {
							$sel_sub = "";
						}

						$sublist ="<option value='".$sub_id."'  ".$sel_sub." >".$sub_name."</option>";
					}
				?>
				<select class="select2 form-control custom-select chosen-select" id="sub_list<!?php echo $f; ?>" name="subprocess_name[]" data-no="<!?php echo $f; ?>" style="">
				<option value="">Select</option>
					<!?php echo $sublist; ?>
				</select>
				<script type="text/javascript">
												$(".chosen-select").chosen({
											  	no_results_text: "Oops, nothing found!"
												})
											</script>
							<!?php
							if(count($fabrics) > 1) {
							?>
							<select style="display:none" class="select2 form-control custom-select" id="sub_list_hidden<!?php echo $f; ?>" name="subprocess_name[]"   data-no="<!?php echo $f; ?>" style="">
							<option value="">Select</option>
							<!?php echo $sublist; ?>
							</select>
							<!?php } $sublist = ""; ?>
						</span>
					</td> -->

					



					<td>
    <select class="select2 form-control custom-select chosen-select" id="process_name<?php echo $f; ?>" data-no="<?php echo $f; ?>" name="process_name[]" onchange="sel_sub(this);">
        <option value="">Select</option>
        <?php 
        $costing_no = $res_cost['costing_no']; // Get the costing_no
        $query = "SELECT DISTINCT process_name FROM other_costing WHERE costing_no = '$costing_no'";
        $sel_process = mysqli_query($zconn, $query);

        while ($res_process = mysqli_fetch_array($sel_process, MYSQLI_ASSOC)) {
            $process_name = $res_process['process_name'];

            if ($process_name == $res_costing1["process_name"]) {
                $process_selected = "selected";
            } else {
                $process_selected = "";
            }
        ?>
        <option value="<?php echo $process_name; ?>" <?php echo $process_selected; ?>><?php echo $process_name; ?></option>
        <?php } ?>
    </select>
    <?php 
    if (count($fabrics) > 1) {
    ?>
    <select style="display:none" class="select2 form-control custom-select chosen-select" id="process_name_hidden<?php echo $f; ?>" data-no="<?php echo $f; ?>" name="process_name[]" onchange="sel_sub(this);">
        <option value="">Select</option>
        <?php  
        $sel_process = mysqli_query($zconn, "SELECT DISTINCT process_name FROM other_costing WHERE costing_no = '$costing_no'");
        
        while ($result_process = mysqli_fetch_array($sel_process, MYSQLI_ASSOC)) {
            $process_name = $result_process['process_name'];

            if ($process_name == $res_costing1["process_name"]) {
                $process_selected = "selected";
            } else {
                $process_selected = "";
            }
        ?>
        <option value="<?php echo $process_name; ?>" <?php echo $process_selected; ?>><?php echo $process_name; ?></option>
        <?php } ?>
    </select>
    <?php
    }
    ?>
    <script type="text/javascript">
        $(".chosen-select").chosen({
            no_results_text: "Oops, nothing found!"
        });
    </script>
</td>
								<td>
				<select class="select2 form-control custom-select chosen-select" name="ycolor[]" id="ycolor0">
					<option value="">Select</option>
					<?php
					$sel_ycolor = mysqli_query($zconn,"select * from color_master where status='0'");
					while($res_ycolor = mysqli_fetch_array($sel_ycolor,MYSQLI_ASSOC)){
						if($res_costing['color_name']==$res_ycolor['colour_name']){	?>
						<option selected  value="<?php echo $res_ycolor['colour_name'];?>"><?php echo $res_ycolor['colour_name'];?></option>
						<?php } else { ?>
						<option value="<?php echo $res_ycolor['colour_name'];?>"><?php echo $res_ycolor['colour_name'];?></option>
						<?php } ?>
					<?php } ?>
				</select> 
			</td>
			<td>
				<select class="select2 form-control custom-select chosen-select" name="content[]" id="content">
					<option value="">Select</option>
					<?php
					$sel_ycolor1 = mysqli_query($zconn,"select * from content_master where status='0'");
					while($res_ycolor1 = mysqli_fetch_array($sel_ycolor1,MYSQLI_ASSOC)){
						if($res_costing1['content_name']==$res_ycolor1['content_name']){	?>
						<option selected  value="<?php echo $res_ycolor1['content_name'];?>"><?php echo $res_ycolor1['content_name'];?></option>
						<?php } else { ?>
						<option value="<?php echo $res_ycolor1['content_name'];?>"><?php echo $res_ycolor1['content_name'];?></option>
						<?php } ?>
					<?php } ?>
				</select> 
			</td>


			<td>
										<select class="select2 form-control custom-select chosen-select" name="ycomp[]" id="ycomp<?php echo $co;?>">
										<option value="">Select</option>
										<?php $selcomp = mysqli_query($zconn,"select * from components where status='0'");
										while($res_comp = mysqli_fetch_array($selcomp,MYSQLI_ASSOC)){
											if($res_costing['comp_id']==$res_comp['comp_name']){
										?>
										<option selected value="<?php echo $res_comp['comp_name'];?>"><?php echo $res_comp['comp_name'];?></option>
											<?php } else { ?>
											<option value="<?php echo $res_comp['comp_name'];?>"><?php echo $res_comp['comp_name'];?></option>
										<?php } 
										} ?>
										</select>
										</td>
									
			<!-- <td><input type="text" name="dia[]"  class="form-control" id="dia"  onKeyUp="multiply()" required autocomplete="off"></td> -->
			<td>
				<select class="select2 form-control custom-select chosen-select" id="dia" name="dia[]">
				<option value="">Select</option>
				<?php $sel_ycounts = mysqli_query($zconn,"select * from dia_master where status='0'");
				while($res_ycounts = mysqli_fetch_array($sel_ycounts,MYSQLI_ASSOC)){?>
				<option value="<?php echo $res_ycounts['dia_name'];?>"><?php echo $res_ycounts['dia_name'];?></option>
				<?php } ?>
				</select>
				</td>
				
			<td>
			<select class="select2 form-control custom-select chosen-select" id="gsm" name="gsm[]">
				<option value="">Select</option>
				<?php $sel_ycounts = mysqli_query($zconn,"select * from gsm_master where status='0'");
				while($res_ycounts = mysqli_fetch_array($sel_ycounts,MYSQLI_ASSOC)){?>
				<option value="<?php echo $res_ycounts['gsm_name'];?>"><?php echo $res_ycounts['gsm_name'];?></option>
				<?php } ?>
				</select> 
			</td>
				<!-- <td>
					<input type="text" name="gsm[]"  class="form-control " id="gsm" required onKeyUp="multiply_loss()">
				</td> -->
				
				
			
					<!-- <td>
						<?php
						if($_REQUEST['id']!=''){
							$ro = "readonly";
						} else {
							$ro = "";
						}
						?>
							<input type="text" readonly class="form-control wgt" value="<?php  echo number_format($res_costing1['weight'],2); $totalwgt+= $res_costing1['weight']; ?>"  data-no="<?php echo $f; ?>" id="wgt_<?php echo $f; ?>" name="wgt[]" <?php echo $ro;?> placeholder="Weight" onkeyup="rate_cal(<?php echo $f; ?>);" onblur="rate_cal(<?php echo $f; ?>);">
							<?php
							if(count($fabrics) > 1) {
							?>
							<input type="text" style="display:none" readonly class="form-control wgt" value="<?php  echo $res_costing1['weight']; $totalwgt;?>"  data-no="<?php echo $f; ?>" id="wgt_hidden<?php echo $f; ?>" name="wgt[]" <?php echo $ro;?> placeholder="Weight" onkeyup="rate_cal(<?php echo $f; ?>);" onblur="rate_cal(<?php echo $f; ?>);">
							<?php } ?>
					</td> -->
					<!-- <td>
						   <input type="text" class="form-control rate"  value="<?php  echo $res_costing1['rate'];?>" placeholder="Rate/Kg" id="rate<?php echo $f; ?>" name="rate[]"  onkeyup="rate_cal(<?php echo $f; ?>);" onblur="rate_cal(<?php echo $f; ?>);" >
						   <?php if(count($fabrics) > 1) {
							?>
						   <input type="text" style="display:none" class="form-control rate"  value="<?php  echo $res_costing1['rate'];?>" placeholder="Rate/Kg" id="rate_hidden<?php echo $f; ?>" name="rate[]"  onkeyup="rate_cal(<?php echo $f; ?>);" onblur="rate_cal(<?php echo $f; ?>);" >
						   <?php } ?>
					</td> -->
					<!--<td>
					<input type="text" class="form-control" value="<?php  echo $res_costing1['rate_pcs'];?>" data-no="<?php echo $f; ?>" id="rate_pcs<?php echo $f; ?>" name="rate_pcs[]" placeholder="Rate/Pcs">

					<?php if(count($fabrics) > 1) { ?>
							<input type="text" style="display:none"  class="form-control" value="<?php  echo $res_costing1['rate_pcs'];?>" data-no="<?php echo $f; ?>" id="rate_pcs_hidden<?php echo $f; ?>" name="rate_pcs[]" placeholder="Rate/Pcs">
							<?php } ?>
					
					</td>-->
					<td><input type="text" name="wgt[]" class="form-control" onkeyup="calculateTotal(this)" required autocomplete="off"></td>
<td><input type="text" class="form-control proloss" name="process_loss[]" onkeyup="calculateTotal(this)" placeholder="Process Loss Percentage" required></td>
<td><input type="text" class="form-control" name="total_weight[]"></td>

					<td>
						<a class="delete-row" title="Delete"><button type="button" class="btn btn-info"><i class="fa fa-minus"></i></button></a>
					</td>
				</tr>

			<?php $f++; } ?>
			<?php } ?>
				<?php } else { // NO costing entry
				$totalwgt=0;
				$total_rate = 0;
				$totalloss=0;
				$sel_costing1 = mysqli_query($zconn,"select costing_no,process_name, subprocess_name,GROUP_CONCAT(fabric_name) as fabric_name,sum(weight) as weight,max(rate) as rate, sum(rate_pcs) as rate_pcs ,sum(total) as total, max(process_loss) as process_loss FROM  `other_costing` where costing_no='".$id."' group by process_name,subprocess_name");
				$rows_costing1 = mysqli_num_rows($sel_costing1);

				if($rows_costing1>0){ ?>
				<?php 
					$f = 0;
					while($res_costing1 = mysqli_fetch_array($sel_costing1,MYSQLI_ASSOC)){
				?>
				<tr id="delete_1">
					<td>
						<select multiple="multiple" class="select2 mdb-select form-control custom-select chosen-select"  data-no="<?php echo $f; ?>" name="fabric_name[]" id="fabric_name<?php echo $f; ?>" onchange="fabric(this);">
						<?php $fabrics = explode(",",$res_costing1['fabric_name']); ?>
						<?php 
					$sel_cost_details1 = mysqli_query($zconn,"select distinct(fabric_name)as fabric_name from costing_entry_details WHERE `costing_id` ='".$id."'");
						while($res_det1 = mysqli_fetch_array($sel_cost_details1,MYSQLI_ASSOC)) {
							if(in_array($res_det1['fabric_name'], $fabrics)) 
							{
								$selected = "selected";
							} else {
								$selected = "";
							}
						?>
						<option value="<?php echo $res_det1['fabric_name'];?>" <?php echo $selected; ?>><?php echo $res_det1['fabric_name'];?></option>
						<?php } ?>
					</select>
				</td>

				<td>
					<select class="select2 form-control custom-select chosen-select" id="process_name<?php echo $f; ?>" data-no="<?php echo $f; ?>" name="process_name[]" onchange="sel_sub(this);">
						<option value="">Select</option>
					<?php $sel_process = mysqli_query($zconn,"select * from process_master where status='0'"); 

					while($res_process = mysqli_fetch_array($sel_process,MYSQLI_ASSOC)){
						if( $res_process['process_name'] == $res_costing1["process_name"]) {
							$process_selected = "selected";
						} else {
							$process_selected  = "";
						}
					?>
					<option value="<?php echo $res_process['process_name'];?>" <?php echo $process_selected; ?>><?php echo $res_process['process_name'];?></option>
					<?php } ?>
					</select>
					<script type="text/javascript">
												$(".chosen-select").chosen({
											  	no_results_text: "Oops, nothing found!"
												})
											</script>
					<?php 
					if(count($fabrics) > 1) {
					?>
					<select style="display:none;" class="select2 form-control custom-select chosen-select" id="process_name_hidden<?php echo $f; ?>" data-no="<?php echo $f; ?>" name="process_name[]" onchange="sel_sub(this);">
					<?php
					$sel_process = mysqli_query($zconn,"select * from process_master where status='0'"); 
					while($result_process = mysqli_fetch_array($sel_process,MYSQLI_ASSOC)){
						if( $result_process['process_name'] == $res_costing1["process_name"]) {
							$process_selected = "selected";
						} else {
							$process_selected  = "";
						}
					?>
					<option value="">Select</option>
					<option value="<?php echo $result_process['process_name'];?>" <?php echo $process_selected; ?>><?php echo $result_process['process_name'];?></option>
					<?php } ?>
					</select>
					<?php
					}
					?>
						
				</td>
				<td>
					<span>
					<?php
				   $sel_sub = mysqli_query($zconn,"select * from sub_process where process_name='".$res_costing1["process_name"]."'");
					while($res_sub = mysqli_fetch_array($sel_sub,MYSQLI_ASSOC)){
						$sub_id = $res_sub['id'];
						$sub_name = $res_sub['sub_process_name'];
						if($res_costing1['subprocess_name'] == $sub_id) {
							$sel_sub = "selected";
						} else {
							$sel_sub = "";
						}
						$sublist ="<option value='".$sub_id."' ".$sel_sub." >".$sub_name."</option>";
						}
					?>
					<select class="select2 form-control custom-select chosen-select" id="sub_list<?php echo $f; ?>" name="subprocess_name[]"   data-no="<?php echo $f; ?>" style="">
					<option value="">Select</option>
						<?php echo $sublist; ?>
					</select>
					<?php
					if(count($fabrics) > 1) { ?>
					<select style="display:none;" class="select2 form-control custom-select chosen-select" id="sub_list_hidden<?php echo $f; ?>" name="subprocess_name[]"   data-no="<?php echo $f; ?>" style="">
					<option value="">Select</option>
					<?php echo $sublist; ?>
					</select>
					<script type="text/javascript">
												$(".chosen-select").chosen({
											  	no_results_text: "Oops, nothing found!"
												})
											</script>
					<?php } $sublist = ""; ?>
				
				</span>
			</td>
			<td>
				<?php
				if($_REQUEST['id']!=''){
					$ro = "readonly";
				} else {
					$ro = "";
				}
				?>
				<input type="text" readonly class="form-control wgt" value="<?php  echo $res_costing1['weight']; $totalwgt+= $res_costing1['weight']; ?>"  data-no="<?php echo $f; ?>" id="wgt_<?php echo $f; ?>" name="wgt[]" <?php echo $ro;?> placeholder="Weight" onkeyup="rate_cal(<?php echo $f; ?>);" onblur="rate_cal(<?php echo $f; ?>);">
				<?php
				if(count($fabrics) > 1) { ?>
				<input type="text" style="display:none" readonly class="form-control wgt" value="<?php  echo $res_costing1['weight']; $totalwgt;?>"  data-no="<?php echo $f; ?>" id="wgt_hidden<?php echo $f; ?>" name="wgt[]" <?php echo $ro;?> placeholder="Weight" onkeyup="rate_cal(<?php echo $f; ?>);" onblur="rate_cal(<?php echo $f; ?>);">
				<?php } ?>
			</td>
			<td>
			   <input type="text" class="form-control rate"  value="<?php  echo $res_costing1['rate'];?>" placeholder="Rate/Kg" id="rate<?php echo $f; ?>" name="rate[]"  onkeyup="rate_cal(<?php echo $f; ?>);" onblur="rate_cal(<?php echo $f; ?>);" >
			   <?php if(count($fabrics) > 1) { 	?>
			   <input type="text" style="display:none;" class="form-control rate"  value="<?php  echo $res_costing1['rate'];?>" placeholder="Rate/Kg" id="rate_hidden<?php echo $f; ?>" name="rate[]"  onkeyup="rate_cal(<?php echo $f; ?>);" onblur="rate_cal(<?php echo $f; ?>);" >
			   <?php } ?>
			</td>
			<td>
			<input type="text" class="form-control" value="<?php  echo $res_costing1['rate_pcs'];?>" data-no="<?php echo $f; ?>" id="rate_pcs<?php echo $f; ?>" name="rate_pcs[]" placeholder="Rate/Pcs">

			<?php if(count($fabrics) > 1) { ?>
			<input type="text" style="display:none"  class="form-control" value="<?php  echo $res_costing1['rate_pcs'];?>" data-no="<?php echo $f; ?>" id="rate_pcs_hidden<?php echo $f; ?>" name="rate_pcs[]" placeholder="Rate/Pcs">
			<?php } ?>
			</td>
			<td>
			<input type="text" class="form-control total" data-no="<?php echo $f; ?>" id="total<?php echo $f; ?>" value="<?php  echo $res_costing1['total'];$total_rate +=$res_costing1['total'];?>" name="total[]" readonly placeholder="Total">

			<?php if(count($fabrics) > 1) { ?>

			<input type="text" style="display:none"  class="form-control total" data-no="<?php echo $f; ?>" id="total_hidden<?php echo $f; ?>" value="<?php  echo $res_costing1['total'];$total_rate;?>" name="total[]" readonly placeholder="Total">
			<?php } ?>

			</td>
			<td>
			<input type="text" class="form-control proloss" value="0" onkeyup="proloss();" id="process_loss<?php echo $f; ?>" name="process_loss[]" placeholder="Process Loss" >
			</td>
			<td>
				<a class="delete-row" title="Delete"><button type="button" class="btn btn-info"><i class="fa fa-minus"></i></button></a>
			</td>
		</tr>

			<?php $f++; } ?>
			<?php } ?>

				<?php } ?>
				<script type="text/javascript">
												$(".chosen-select").chosen({
											  	no_results_text: "Oops, nothing found!"
												})
											</script>
	</tbody>
		</table>
			</div>
			
		<!-- <table id="example1" class="table table-striped table-bordered">
			<tr id="delete_0">
				<td style="width: 15%;">&nbsp;</td><td style="width: 15%;">&nbsp;</td>
				<td style="width: 15%;"></td>
				<td style="width: 11%;"><h6 class="page-title">Total Weight:</h6><br>
					<input type="text" class="form-control" id="total_wgt" name="total_wgt" value="<?php echo $totalwgt;?>" readonly placeholder="" style="border: 1px solid #000;">
				</td> -->
				<!--td style="width: 15%;">Total</td>
				<!-- <td style="width: 11%;"><h6 class="page-title">Total Rate:</h6><br><input type="text" name="total_amount" class="form-control" id="total_rate" value="<?php echo  $totalwgt;?>" readonly placeholder="" style="border: 1px solid #000;"></td> 
				<td width="20%">
				<input type="text" class="form-control" id="grand_total" name="grand_total" readonly placeholder="" style="border: 1px solid #000;">
					</td>
				<td style="width: 11%;"><h6 class="page-title">Total Loss:</h6><br>
				<input type="text" name="total_loss" class="form-control" id="tot_loss" value="" readonly placeholder="" style="border: 1px solid #000;"></td>
				<td style="width: 6%;"></td>
			</tr>
		</table> -->
							<div class="border-top">
								<div class="card-body" style="margin-left: 250px;">
									<button type="submit" name="save" class="btn btn-success">Save</button>
									<button type="submit" class="btn btn-primary">Reset</button>
									<a href="process_planning_list.php"><button type="button" class="btn btn-danger">List</button></a>
								</div>
							</div>
                        </div>
                    </div>
                </div>
                <!-- Sales chart -->
            </div>
            <!-- End Container fluid  -->
			</form>
        </div>

        <!-- End Page wrapper  -->
    </div>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
    <!-- End Wrapper -->
	<!-- ============================================================== -->
            <!-- footer -->
            <?php include('includes/footer.php');?>
            <!-- End footer -->
    <!-- All Jquery -->

    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="assets/extra-libs/bootstrap-multiselect/dist/css/bootstrap-multiselect.css" type="text/css">
	<script type="text/javascript" src="assets/extra-libs/bootstrap-multiselect/dist/js/bootstrap-multiselect.js"></script>    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
	<script src="dist/js/bootstrap-datepicker.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js"></script>


<script>
	function fabric(id){
		var datano = $(id).data('no');
		var	fabric_name = $(id).val();
		var	costing_no = $("#costing_no").val();
		var index = $("#example tbody tr:last-child").index();
		var id=parseInt(index)+parseInt(1);
		$.ajax({
			type: 'POST',
			url:'ajax/dye_weight.php',
			data: {fabric_name:fabric_name,costing_no:costing_no},
			success:function(data){
			//	alert(data);
			$('#wgt_'+datano).val(data);
			}
		});
	}

	function proloss(){
		var loss_val=0;
		$('.proloss').each(function(){
			loss_val += parseFloat($(this).val());  // Or this.innerHTML, this.innerText
		});
		$('#tot_loss').val(loss_val);
	}

	function rate_cal(id){
		var weig = 0;
		var sm=0;
		var cons = $('#wgt_'+id).val();
		var rat = $('#rate'+id).val();
		var ctrws=0;
		if(rat){
			ctrws = parseFloat(cons)*parseFloat(rat);
		} 
		$('#rate_pcs'+id).val(ctrws);
		$('#total'+id).val(ctrws);

		$('.wgt').each(function(e){
			if($(this).attr('style') != "display:none"){
				weig += parseFloat($(this).val());
			}
		 });

		 $('.total').each(function(){
			if($(this).attr('style') != "display:none"){
				sm += parseFloat($(this).val());
			}
		 });
		$('#total_wgt').val(weig.toFixed(2));
		$('#total_rate').val(sm.toFixed(2));

		if($("#fabric_name"+id).val().length > 1) {
			if($("#process_name_hidden"+id).length) {
				$("#process_name_hidden"+id).remove();
			}
			$("#process_name"+id).clone().prependTo("#process_name"+id).hide().prop('id', 'process_name_hidden'+id ).val($("#process_name"+id).val());

			if($("#sub_list_hidden"+id).length) {
				$("#sub_list_hidden"+id).remove();
			}
			$("#sub_list"+id).clone().prependTo("#sub_list"+id).hide().prop('id', 'sub_list_hidden'+id ).val($("#sub_list"+id).val());
			if($("#wgt_hidden"+id).length) {
				$("#wgt_hidden"+id).remove();
			}
			$("#wgt_"+id).clone().prependTo("#wgt_"+id).hide().prop('id', 'wgt_hidden'+id );

			if($("#rate_hidden"+id).length) {
				$("#rate_hidden"+id).remove();
			}
			$("#rate"+id).clone().prependTo("#rate"+id).hide().prop('id', 'rate_hidden'+id );

			if($("#rate_pcs_hidden"+id).length) {
				$("#rate_pcs_hidden"+id).remove();
			}
			$("#rate_pcs"+id).clone().prependTo("#rate_pcs"+id).hide().prop('id', 'rate_pcs_hidden'+id );
			
			if($("#total_hidden"+id).length) {
				$("#total_hidden"+id).remove();
			}
			$("#total"+id).clone().prependTo("#total"+id).hide().prop('id', 'total_hidden'+id );

			if($("#process_loss_hidden"+id).length) {
				$("#process_loss_hidden"+id).remove();
			}
			$("#process_loss"+id).clone().prependTo("#process_loss"+id).hide().prop('id', 'process_loss_hidden'+id ).val($("#process_loss"+id).val());
	
		}
	}
</script>
<?php
		$sql_fabs = mysqli_query($zconn,"select * from fabric_master where status='0'");
		$fabs_list ='';
		while($res_fabs = mysqli_fetch_array($sql_fabs,MYSQLI_ASSOC)){
			$fabs_list .='<option value="'.$res_fabs['fabric_name'].'">'.$res_fabs['fabric_name'].'</option>';
		}

		$sel_ycolor = mysqli_query($zconn,"select * from color_master where status='0'");
	    $color_list='';
		while($res_ycolor = mysqli_fetch_array($sel_ycolor,MYSQLI_ASSOC)){
			$color_list .='<option value="'.$res_ycolor['colour_name'].'">'.$res_ycolor['colour_name'].'</option>';
		}

		$sel_ycolor1 = mysqli_query($zconn,"select * from content_master where status='0'");
		$content_list='';
		while($res_ycolor1 = mysqli_fetch_array($sel_ycolor1,MYSQLI_ASSOC)){
			$content_list .='<option value="'.$res_ycolor1['content_name'].'">'.$res_ycolor1['content_name'].'</option>';
		}

		$selcomp = mysqli_query($zconn,"select * from components where status='0'");
		$comp_list='';
		while($res_comp = mysqli_fetch_array($selcomp,MYSQLI_ASSOC)){
			$comp_list .='<option value="'.$res_comp['comp_name'].'">'.$res_comp['comp_name'].'</option>';
		}
		$sel_ycounts = mysqli_query($zconn,"select * from dia_master where status='0'");
		$ycountlist= '';
		while($res_ycounts = mysqli_fetch_array($sel_ycounts,MYSQLI_ASSOC)){
		   $ycountlist .='<option value="'.$res_ycounts['dia_name'].'">'.addslashes($res_ycounts['dia_name']).'</option>';
		}
		$sel_ycoun = mysqli_query($zconn,"select * from gsm_master where status='0'");
		$ygsm ='';
		while($res_ycoun = mysqli_fetch_array($sel_ycoun,MYSQLI_ASSOC)){
			$ygsm .='<option value="'.$res_ycoun['gsm_name'].'">'.addslashes($res_ycoun['gsm_name']).'</option>';
		}

?>
	<script type="text/javascript">
	function sel_sub(pname){
		 var data_no = $(pname).data('no');
		 var pr_name = $(pname).val();
	 $.ajax({
		url : 'ajax/process.php',
		type: 'POST',
		data: '&pr_name='+pr_name+'&action=list_subprocess',
		success: function(data){
			$('#sub_list'+data_no).html(data);
			$('#sub_list_hidden'+data_no).html(data);
		}
		});
	}

$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
	var actions = $("#material td:last-child").html();
	$('.mdb-select').multiselect();

	// Append table with add row form on add new button click
    $(".add-new").click(function(){

		var index = $("#material tbody tr:last-child").index();
		if($("#material tbody tr").length == 0) {
			var id=parseInt(index)+parseInt(1);
		} else {
			var id = parseInt($("#material tbody tr:last-child td select").data('no')) + 1;
		}

        var row = 
		'<tr>' +'<td><select name="fab_name[]" class="select2 form-control custom-select chosen-select"><option value="">--Select--</option><?php echo $fabs_list;?></select></td>'+
		'<td><select class="select2 form-control custom-select chosen-select" name="process_name[]" data-no="'+id+'" id="process_name'+id+'" onchange="sel_sub(this);"><option value="">Select</option><?php $sel_process = mysqli_query($zconn,"select * from process_master where status='0'"); while($res_process = mysqli_fetch_array($sel_process,MYSQLI_ASSOC)){
		?><option value="<?php echo $res_process['process_name'];?>"><?php echo $res_process['process_name'];?></option><?php } ?></select></td>' +
		
		'<td><select class="select2 form-control custom-select chosen-select" name="ycolor[]" id="ycolor0'+id+'"><option value="">--Select--</option><?php echo $color_list;?></select>'+
		'<td><select class="select2 form-control custom-select chosen-select" name="content[]" id="content'+id+'"><option value="">--Select--</option><?php echo $content_list;?></select>'+
		'<td><select class="select2 form-control custom-select chosen-select" name="ycomp[]" id="ycomp'+id+'"><option>Select</option><?php echo $comp_list;?></select></td>' +
		'<td><select class="select2 form-control custom-select chosen-select" id="dia'+id+'" name="dia[]"><option> Select</option><?php echo $ycountlist;?></select></td>' +
			'<td><select class="select2 form-control custom-select chosen-select" id="gsm'+id+'" name="gsm[]"><option> Select</option><?php echo $ygsm;?></select></td>' +
		//'<td><input type="text" name="dia[]"  class="form-control" id="dia'+id+'"  onKeyUp="multiply()" required autocomplete="off"></td>'+
		//'<td><input type="text" name="gsm[]"  class="form-control " id="gsm'+gsm+'" required onKeyUp="multiply_loss()"></td>'+
		'<td><input type="text" class="form-control wgt" id="wgt_'+id+'" placeholder="Weight" name="wgt[]" onkeyup="rate_cal('+id+');" onblur="rate_cal('+id+');"></td>' +
        '<td><input type="text" class="form-control proloss " id="process_loss'+id+'" onkeyup="proloss(this);" name="process_loss[]"  placeholder="Process Loss"></td>'+
        '<td><input type="text" class="form-control total" id="total'+id+'" name="total[]" readonly placeholder="Total"></td>' +
        
		'<td><a class="delete-row" title="Delete" ><button type="button" class="btn btn-info"><i class="fa fa-minus"></i></button></a></td>' +
        '</tr>';

    	$("#material").append(row);
		$(".chosen-select").chosen({
		no_results_text: "Oops, nothing found!"
		})
		$("#material tbody tr").eq(index + 1).find(".add, .edit").toggle();
        $('[data-toggle="tooltip"]').tooltip();
		$('.mdb-select').multiselect();
    });
	// Add row on add button click
	$(document).on("click", ".add", function(){
		var empty = false;
		var input = $(this).parents("tr").find('input[type="text"]');
        input.each(function(){
		//	if(!$(this).val()){
		//		$(this).addClass("error");
		//		empty = true;
		//	} else{
        //        $(this).removeClass("error");
        //    }
		});
		$(this).parents("tr").find(".error").first().focus();
		if(!empty){
			input.each(function(){
				$(this).parent("td").html($(this).val());
			});			
			$(this).parents("tr").find(".add, .edit").toggle();
			$(".add-new").removeAttr("disabled");
		}
    });
	// Edit row on edit button click
	$(document).on("click", ".edit", function(){
        $(this).parents("tr").find("td:not(:last-child)").each(function(){
			$(this).html('<input type="text" class="form-control" value="' + $(this).text() + '">');
		});
		$(this).parents("tr").find(".add, .edit").toggle();
		$(".add-new").attr("disabled", "disabled");
    });
	// Delete row on delete button click
	$(document).on("click", ".delete-row", function(){
		// $(this).closest("tr.mdb-select").remove();
        $(this).closest("tr").remove();
		$(".add-new").removeAttr("disabled");
    });
});

$('#order_date').datepicker({
	format:'dd-mm-yyyy',
      autoclose: true
    })


</script>
<script>
function calculateTotal(input) {
    var row = input.closest('tr'); // Find the parent row
    var wgt = parseFloat(row.querySelector('[name="wgt[]"]').value) || 0; // Get the value of "wgt" or 0 if empty
    var processLossPercentage = parseFloat(row.querySelector('[name="process_loss[]"]').value) || 0; // Get the value of "process_loss" percentage or 0 if empty

    // Calculate the process loss based on the percentage
    var processLoss = (wgt * processLossPercentage) / 100;

    // Calculate the total weight
    var total = wgt - processLoss;

    // Update the "total_weight" input field in the same row
    row.querySelector('[name="total_weight[]"]').value = total.toFixed(2);
}
</script>
</body>
</html>