<?php 
include('includes/config.php');

if($_SESSION['userid']==''){
	echo "<script>window.location.href='login.php';</script>";
}
if(isset($_POST['proc']))
{ 
	$id=$_POST['id'];
	$start=$_POST['StartDate'];
	$end=$_POST['endDate'];
if(empty($id)){$eid="Please Enter the ID";}
else{
   
     $sql=mysqli_query("select distinct name,dept,possion,image from persondetail where id='".$_REQUEST['id']."'");
	 
	 while($row=mysqli_fetch_array($sql))
	 {
	    	$name1=$row['name'];
	 		$dep=$row['dept'];
			$possion=$row['possion'];
			$frame=$row['image'];		  
	  }
	if($possion=="Contractor" || $possion=="Labor"){$ec="This is an contractor or Labor id"; $name1=""; $dep=""; $possion="";}

}

}
elseif(isset($_POST['submit']))
{//echo "hai";

   	$id=$_POST['id'];
	$start=$_POST['StartDate'];
	$end=$_POST['endDate'];
	$name1=$_POST['nam'];
	$dep=$_POST['det'];
	$a=$_POST['leave'];

	
	  $dateCheck=mysqli_query("SELECT startdate,enddate FROM attendance where id='$id' and startdate='$start' and enddate='$end'");
	 if(mysqli_num_rows($dateCheck)!='0'){$sqlerror="Date All ready Present!!!";}
	 
	  else{
		
		
			$num = cal_days_in_month(CAL_GREGORIAN, $start, $end); 
				
			
			$nums=$num-$a;
			$sql="insert into attendance(id,abs,startdate,enddate,workingday,present,status)values('$id','$a','$start','$end','$num','$nums','unpaid')";
	//		echo($sql);
			
			if(!mysqli_query($sql))
			{
				$sqlerror="error".mysqli_error()."Please Check the ID!!!";
			}
			else
			{
				$ok="ATTENDANCE SAVED SUCESSFULLY!!!";
				$id="";$name1="";$dep="";$a="";
			}
			
	 }

}
if(!isset($_SERVER['HTTP_HOST'])){	
?>
<link id="bs-css" href="css/bootstrap-cerulean.css" rel="stylesheet">
<?php }?>
 <script>
    function checkForm1() 
	{
	if (document.forms.reg.elements['id'].value.length == "") {
	alert('Please select the ID');
	document.forms.reg.elements['id'].focus();
		return false;
	}
	}
	</script>
<script>
    function checkForm() 
	{
	if (document.forms.reg.elements['StartDate'].value == "Month") {
	alert('Please enter a value for the "Select Month" field');
	document.forms.reg.elements['StartDate'].focus();
		return false;
	}
	if (document.forms.reg.elements['endDate'].value == "Year") {
	alert('Please enter a value for the " Select year " ');
	document.forms.reg.elements['endDate'].focus();
		return false;
	}
	if (document.forms.reg.elements['leave'].value.length == '0') {
	alert('Please enter a no of leave taken" ');
	document.forms.reg.elements['leave'].focus();
		return false;
	}
	}
</script>

  <?php if (isset($ok)) {echo alert_success('ATTENDANCE SAVED');} ?>
  <?php if(isset($sqlerror)){ echo alert_error($sqlerror); }?>
	<?php $year=date("Y");
		$noofmonths=mysqli_num_rows(mysqli_query("SELECT * FROM `attendance` WHERE `id` = '".$_REQUEST['id']."' AND `enddate` = '$year'"));
		$noofmonths=$noofmonths+1;	
	?>


<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - Staff Attendence 	</title>
    <!-- Custom CSS -->
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">  

</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <div class="page-wrapper" style="min-height: 100%; height: auto;">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
             <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Staff Attendance </h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="#">Staff Attendance</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
			<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <form name="reg" action="" method="post" enctype="multipart/form-data">
                   
                    <div class="card-body">
                        <fieldset>
                            <legend>Staff Details</legend>

                            <div class="form-group row">
                                <label for="id" class="col-md-3 col-form-label text-md-right font-weight-bold">Staff ID</label>
                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="id" id="id" value="<?php if(isset($id)){echo $id;}?>" style="text-transform:uppercase">
                                </div>
                                <div class="col-md-2">
                                    <input type="submit" class="btn btn-primary btn-block" name="proc" value="Search" onclick="return checkForm1()">
                                </div>
                            </div>
                            <div class="form-group row">
    <label for="name" class="col-md-3 col-form-label text-md-right font-weight-bold">Name</label>
    <div class="col-md-6">
        <input type="text" class="form-control" name="nam" id="cmpname" value="<?php if(isset($name1)){echo $name1;}?>" readonly="readonly">
    </div>
</div>

<div class="form-group row">
    <label for="department" class="col-md-3 col-form-label text-md-right font-weight-bold">Department</label>
    <div class="col-md-6">
        <input type="text" class="form-control" name="det" id="dep" value="<?php if(isset($dep)){echo $dep;}?>" readonly="readonly">
    </div>
</div>
                            <!-- ...similar structure for other fields... -->
<br>
<br>
                            <legend>Attendance Entry</legend>

                            <div class="form-group row">
    <label for="month" class="col-md-3 col-form-label text-md-right font-weight-bold">Select Month</label>
    <div class="col-md-3">
        <select name="StartDate" id="month" class="form-control" readonly="readonly">
            <option value="01"<?php if($noofmonths == '1'){?> selected="selected"<?php }?>>Jan</option>
            <option value="02"<?php if($noofmonths == '2'){?> selected="selected"<?php }?>>Feb</option>
            <option value="03"<?php if($noofmonths == '3'){?> selected="selected"<?php }?>>Mar</option>
            <option value="04"<?php if($noofmonths == '4'){?> selected="selected"<?php }?>>Apr</option>
                <option value="05"<?php if($noofmonths == '5'){?> selected="selected"<?php }?>>May</option>
                <option value="06"<?php if($noofmonths == '6'){?> selected="selected"<?php }?>>Jun</option>
                <option value="07"<?php if($noofmonths == '7'){?> selected="selected"<?php }?>>Jul</option>
                <option value="08"<?php if($noofmonths == '8'){?> selected="selected"<?php }?>>Aug</option>
                <option value="09"<?php if($noofmonths == '9'){?> selected="selected"<?php }?>>Sep</option>
                <option value="10"<?php if($noofmonths == '10'){?> selected="selected"<?php }?>>Oct</option>
                <option value="11"<?php if($noofmonths == '11'){?> selected="selected"<?php }?>>Nov</option>
                <option value="12"<?php if($noofmonths == '12'){?> selected="selected"<?php }?>>Dec</option>
            <!-- Add options for other months here -->
        </select>
    </div>
    <div class="col-md-3">
        <select name="endDate" id="year" class="form-control">
            <option value="2015"<?php if($year=='2015'){?> selected="selected"<?php }?>>2015</option>
            <option value="2014"<?php if($year=='2014'){?> selected="selected"<?php }?>>2014</option>
            <!-- Add options for other years here -->
        </select>
    </div>
</div>

                            <div class="form-group row">
                                <label for="leave" class="col-md-3 col-form-label text-md-right font-weight-bold">No Of Days Leave Taken</label>
                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="leave" id="leave" value="0">
                                </div>
                            </div>

                            <?php if (isset($ec)) { ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo $ec; ?>
                                </div>
                            <?php } ?>
                        </fieldset>
                    </div>

                    <div class="card-footer text-center">
                        <button type="submit" class="btn btn-success">Save</button>
                        <button type="cancel" class="btn btn-primary">cancel</button>
                     
                        <input type="hidden" name="action" id="action" value="<?php echo $action ?>" />
                        <?php if(isset($userid)){ ?>
                            <input type="hidden" name="userid" id="userid" value="<?php echo $userid ?>" />
                        <?php  } ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

                
                <!--/row-->		
    <!-- End Wrapper -->
	<!-- ============================================================== -->
            <!-- footer -->
            <?php include('includes/footer.php');?>
            <!-- End footer -->
            <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    
</body>
</html>