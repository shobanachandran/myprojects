<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save'])) {
    // Database connection settings
    include('includes/config.php');

    // Prepare and execute the INSERT statement for each data entry
    $stmt = mysqli_prepare($zconn, "INSERT INTO stickering_workassign (style_no, order_no, dc_no, to_contractor, `from`, dc_date, size_id, color, qty_val) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

    if ($stmt) {
        // Loop through the form data and insert it into the database
        foreach ($_POST['style_no'] as $key => $style_no) {
            $order_no = $_POST['order_no'][$key];
            $dc_no = $_POST['dc_no'][$key];
            $to_contractor = $_POST['to_contractor'];
            $from = $_POST['from'];
            $dc_date = $_POST['dc_date'];

            // Loop through size and color values
            foreach ($_POST['qty'][$key] as $size_id => $color_qty) {
                $color = $size_id;
                $size_id = $size_id;

                $qty_val = (int)$color_qty;

                mysqli_stmt_bind_param($stmt, 'ssssssssi', $style_no, $order_no, $dc_no, $to_contractor, $from, $dc_date, $size_id, $color, $qty_val);
                mysqli_stmt_execute($stmt);

                if (mysqli_stmt_affected_rows($stmt) == -1) {
                    // Handle the error here and display the error message
                    echo "Error: " . mysqli_error($zconn);
                }
            }
        }

        mysqli_stmt_close($stmt);

        // Close the database connection
        mysqli_close($zconn);
    } else {
        // Handle any error related to preparing the statement
        echo "Error preparing the SQL statement: " . mysqli_error($zconn);
    }
}

// Include your HTML form here
?>


