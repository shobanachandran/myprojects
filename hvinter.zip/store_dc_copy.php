<?php 
include('includes/config.php');

if($_SESSION['userid']==''){
	echo "<script>window.location.href='login.php';</script>";
}

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - Store DC</title>
    <!-- Custom CSS -->
	<!--  datatables CSS -->
    <link href="dist/css/bootstrap.css" rel="stylesheet">
    <link href="dist/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
	

</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
             <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">STORE RECIVED</h4>&nbsp;&nbsp;&nbsp;&nbsp;
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Sales chart -->
                <div class="row">
				
                    <div class="col-md-12">
                        <div class="card">

						<div class="card-body">
						<div class="row">
						<div class="col-md-12">
							<div class="col-md-3" style="float:left;">Order NO&nbsp;<input type="text"></div>
							<div class="col-md-3" style="float:left;">Style NO&nbsp;<input type="text"></div>
							<div class="col-md-4" style="float:left;">Party Name&nbsp;
								<select name="po_status" style="width: 200px;height: 30px;">
									<option value="">--Select--</option>
									<option value="1">Waiting Approval</option>
									<option value="2">Approval</option>
									<option value="3">Cancel PO</option>
								</select>
							</div>
							</div>
							</div>
							<div class="row">
								<div class="col-md-12">
								<div class="col-md-3" style="float:left;">Date&nbsp;<input type="text"></div>
								<div class="col-md-4" style="float:left; valign:top;">Remarks&nbsp;<textarea></textarea></div>
								</div>
							</div>
								<div class="table-responsive">
									<table id="example" class="table table-striped table-bordered">
										<thead style="background-color: #626F80; color: #fff; padding: 0px; font-size: 12px;">
											<tr>
												<th>S.No</th>
												<th>STYLE NO</th>
												<th>NAME</th>
												<th>TOTAL QTY</th>
												<th>RECEIVED</th>
												<th>(PRODUCTION DELEVERED + TRANSFER)</th>
												<th>IN STOCK</th>
											</tr>
										</thead>
										<tbody>
											<tr id="delete_<?php echo $process_id;?>">
												<td><?php echo $sgl;?></td>
												<td><?php echo $process_name;?></td>
												<td><?php echo $sizes;?> </td>
												<td><?php echo $supp_status;?></td>
												<td></td>
												<td><a href='process_group_add.php?colid=<?php echo $process_id; ?>'><i class='fas fa-edit'></i></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href='javascript:;' onclick='DeleteSgId("<?php echo $process_id; ?>");'><i class='fas fa-window-close'></i></a></td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
                        </div>
                    </div>
                </div>
                <!-- Sales chart -->
                <!-- ============================================================== -->                
            </div>
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <?php include('includes/footer.php');?>
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
	<!--datatables JavaScript -->
    <script src="dist/js/jquery.dataTables.min.js"></script>
    <script src="dist/js/dataTables.bootstrap4.min.js"></script>
    <script>
	$(document).ready(function() {
    $('#example').DataTable();
	} );
	function DeleteSgId(ID){
	 var UsrStatus = confirm("Are you sure to delete this details ?");
	  if(UsrStatus){
		$.ajax({
			url : 'ajax/products.php',
			data: {
			   action: 'processgroupdelete',
			   typeid: ID
			},
			success: function( data ) {
				if($.trim(data)=="error"){
					alert("Deleted Failed Kindly. Try again");
				}
				if($.trim(data)=='1'){
					alert("Deleted Successfully");
					document.getElementById("delete_"+ID).style.display = "none";
				}
			},
			error: function (textStatus, errorThrown) {
				//DO NOTHINIG
			}
		});
	  }
	  }
	</script>	

</body>
</html>



<?php
	include('includes/config.php');
	if($_SESSION['userid']==''){
		echo "<script>window.location.href='login.php';</script>";
	}
/*echo "<pre>";
print_r($_POST);
echo "</pre>";*/
	if(isset($_REQUEST['save'])) {
		$select = mysqli_fetch_array(mysqli_query($zconn,"select max(dc_no) as id from store_dcout_master"));
		$id = $select['id']+1;

		$count = count($_REQUEST['delivery_wgt']);
		$sql = mysqli_query($zconn,"INSERT INTO store_dcout_master(order_no,style_no,to_process,dc_no,date,total,from_addr)values('".$_REQUEST['order']."','".$_REQUEST['style']."','".$_REQUEST['to_process']."','".$id."','".$_REQUEST['dc_date']."','".$_REQUEST['total']."','".$_REQUEST['from']."')");

		$chk_flow1 = mysqli_fetch_array(mysqli_query($zconn,"select max(process_no) as MAX_PROCESS from store_dc_out where order_no='".$_REQUEST['order']."' and style_no='".$_REQUEST['style']."'"),MYSQLI_ASSOC);
		$mx_pr_no = $chk_flow1['MAX_PROCESS']+1;
		$sel_dc = mysqli_fetch_array(mysqli_query($zconn,"select max(dc_no) as DCNO from store_dc_out where order_no='".$_REQUEST['order']."' and style_no='".$_REQUEST['style']."' and fabric_name='".$coldata['fabric_name']."' and from_addr='".$_REQUEST['from']."' and to_process='".$_REQUEST['to_process']."' "),MYSQLI_ASSOC);


	for($i=0; $i<$count; $i++) {
	//	if ($_REQUEST['delivery_wgt'][$i]>0) {
		$delivery=$_REQUEST['delivery_wgt'][$i];
		//$balance_wgt = $_REQUEST['wgt'][$i]-$_REQUEST['delivery_wgt'][$i];
		$dweigt =0;
		$chk_wgts = mysqli_fetch_array(mysqli_query($zconn,"select * from store_dc_out where 
		order_no='".$_REQUEST['order']."' and style_no='".$_REQUEST['style']."' and fabric_name='".$_REQUEST['fabric_name'][$i]."' and dc_no='".$sel_dc['DCNO']."' "),MYSQLI_ASSOC);
		$dweigt = $chk_wgts['delivered_wgt']+$_REQUEST['delivery_wgt'][$i];

		$sql = mysqli_query($zconn,"INSERT INTO store_dc_out (order_no,style_no,to_process,dc_no,dc_date,fabric_name,content,color,dia,fdia,gsm,gauge,loop_length,lab_no,planning_wgt,inward_wgt,delivered_wgt,balance_wgt,wgt,process_no,from_addr,inward_id) values('".$_REQUEST['order']."','".$_REQUEST['style']."','".$_REQUEST['to_process']."','".$id."','".$_REQUEST['dc_date']."','".$_REQUEST['fabric_name'][$i]."','".$_REQUEST['content'][$i]."','".$_REQUEST['color'][$i]."','".$_REQUEST['dia'][$i]."','".$_REQUEST['fdia'][$i]."','".$_REQUEST['gsm'][$i]."','".$_REQUEST['gauge'][$i]."','".$_REQUEST['loop_length'][$i]."','".$_REQUEST['lab_no'][$i]."','".$_REQUEST['wgt'][$i]."','".$_REQUEST['inward_wgt'][$i]."','".$dweigt."','".$_REQUEST['balance_wgt'][$i]."','".$_REQUEST['wgt'][$i]."','".$mx_pr_no."','".$_REQUEST['from']."','".$_REQUEST['id'][$i]."')");
	//	}
	}
	if($sql) {
		echo '<script>alert("The Record has been Successfully Added...")</script>';
	} else {
		echo '<script>alert("The Record Not Added Please Fill all The correct Detail...");</script>';
	}

}

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link href="assets/images/favicon.png" rel="icon" type="image/png" sizes="16x16" >
    <title><?php echo SITE_TITLE;?> - STORE - PROCESS DC</title>
    <!-- Custom CSS -->
	<!-- datatables CSS -->
    <link href="dist/css/bootstrap.css" rel="stylesheet">
    <link href="dist/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
	<style>
	th{font-size:12px; font-weight:bold; background-color:#626F80; color: #fff; text-align:center;}
	</style>
</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
		<?php include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
             <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">STORE - PROCESS DC </h4>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <div class="container-fluid">  
				<form name="process_dc_out" method="post">
                <!-- ============================================================== -->
                <!-- Sales chart -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
							<div class="card-body" style="width:100%">
								<div class="card" style="width:50%; float:left; left: 50px; ">
									<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">&nbsp;Order No</label>
			<div class="col-sm-6">
				<select class="select2 form-control custom-select" name="order" id="order" onchange="this.form.submit();">
					<option>Select</option>
					<?php $sel_buyer = mysqli_query($zconn,"select distinct order_no from accessories_inward where 1 group by id");
					while($res_buyer = mysqli_fetch_array($sel_buyer,MYSQLI_ASSOC)){
						$order[]=$res_buyer['order_no'];
						$chk_process = mysqli_query($zconn,"select * from process_dc_out where order_no='".$res_buyer['order_no']."' and style_no='".$res_buyer['style_no']."'");
					 ?>
					<option value="<?php echo $res_buyer['order_no'];?>" <?php if ( $res_buyer['order_no']==$_REQUEST['order']){?> selected="selected" <?php } ?>
					><?php echo $res_buyer['order_no'];?></option>
					<?php } ?>
				</select>
				</div>
			</div>

		<div class="form-group row">
			<label for="fname" class="col-sm-3 text-right control-label col-form-label">&nbsp;Style No</label>
				<div class="col-sm-6">
					<select class="select2 form-control custom-select" name="style" id="style" onchange="this.form.submit();">
					<option>Select</option>
					<?php $sel_buyer = mysqli_query($zconn,"select * from accessories_inward where order_no='".$_REQUEST['order']."'");
					while($res_buyer = mysqli_fetch_array($sel_buyer,MYSQLI_ASSOC)){ $fabrc=$res_buyer['style_no']; ?>
						<option value="<?php echo $res_buyer['style_no'];?>" <?php if ($res_buyer['style_no']==$_REQUEST['style']) {?> selected="selected" <?php } ?> ><?php echo $res_buyer['style_no'];?></option>
					<?php } ?>
					</select>
				</div>
		</div>
	<div class="form-group row">
		<div class="col-sm-6">

										</div>
									</div>
								</div>

								<div class="card" style="width:50%; float:left; right: 50px;">
									<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">&nbsp;Dc No</label>
										<div class="col-sm-6">
											<?php $select = mysqli_fetch_array(mysqli_query($zconn,"select max(dc_no) as id from store_dcout_master")); 

											$id=$select['id']+1;?>
											<input type="text" name="dc_no" class="form-control" value="<?php echo $id;?>">
										</div>
									</div>

									<div class="form-group row">
										<label for="cono1" class="col-sm-3 text-right control-label col-form-label">DC Out Date</label>
										<div class="col-sm-6">
											<input type="date" class="form-control" id="dc_date" name="dc_date" autocomplete="off" required>
										</div>
									</div>

									<div class="form-group row">
										<div class="col-sm-6">
							
				</div>
			</div>
			<div class="form-group row">
				<label for="cono1" class="col-sm-3 text-right control-label col-form-label">To </label>
				<div class="col-sm-6">
					<select name="to_comp" id="to_comp" class="form-control">
						<option>--Select--</option>
						<?php 
						$sel_comp = mysqli_query($zconn,"select * from department_master"); 
						while($res_comp = mysqli_fetch_array($sel_comp)){  ?>
							<option value="<?php echo $res_comp['dept_name'];?>"><?php echo $res_comp['dept_name'];?></option>
						<?php } ?>
					</select>
				</div>
			</div>
		</div>

	<?php 
	//if ($_REQUEST['to_process']!='' && $_REQUEST['to_process']!='0'){
		//	if ($_REQUEST['to_process']=='knitting'){?>
			
			<?// }
	//else if($_REQUEST['to_process']=='dyeing' || $_REQUEST['to_process']=='DYE'){?>
		
		</div>
			</div>
		<?php // } else { ?>
			<div class="table-responsive">
				<div class="col-12 d-flex no-block align-items-center">
					<!-- <h5 class="page-title"  style="margin-left: 390px;"><?php 
					echo strtoupper($_REQUEST['to_process']); ?>&nbsp;.........PROGRAM</h5> -->
				</div>
				<table id="example" class="table table-striped table-bordered text-center">
					<thead>
						<tr>
						<th style="width: 10%">S.NO</th>

							<th style="width: 10%">Style No</th>
							<th style="width: 3%" data-toggle="tooltip" title="Fabric Dia">NAME</th>
							<!-- <th style="width: 3%">DIA</th> -->
							<th style="width: 5%" data-toggle="tooltip" title="PLANNING Weight">TOTAL QTY</th>
							<th style="width: 5%" data-toggle="tooltip" title="PLANNING Weight">RECEIVED</th>
							<th style="width: 5%" data-toggle="tooltip" title="PLANNING Weight">(PRODUCTION DELEVERED + TRANSFER)</th>
							<th style="width: 10%">IN STOCK</th>
						</tr>
					</thead>
					<tbody>
		<?php 
		$sel_orders = mysqli_fetch_array(mysqli_query($zconn,"select * from store_po_details where  style_no='".$_REQUEST['style']."'"),MYSQLI_ASSOC);

		$order_details = mysqli_query($zconn,"select * from store_po_master where po_id='".$sel_orders['po_no']."'");
		$cj=0;
		$balance_wgt=0;
			while($res_orders = mysqli_fetch_array($order_details,MYSQLI_ASSOC)){
				$yarn_sql = mysqli_query($zconn,"select * from accessories_inward where style_no='".$_REQUEST['style']."' ");
				$yarn_det = mysqli_fetch_array($yarn_sql,MYSQLI_ASSOC);	
				$yarn_rows = mysqli_num_rows($yarn_sql);

				$sel_dc = mysqli_fetch_array(mysqli_query($zconn,"select * from store_dc_out where 
				style_no='".$_REQUEST['style']."' and order_no='".$_REQUEST['order']."' 
				"),MYSQLI_ASSOC);

				if($sel_dc['balance_wgt']!=''){
					$balance_wgt = $sel_dc['balance_wgt'];
				} 
				
		?>
						<tr>
							<td style="width:10%"><input type="text" name="fabric_name[]" 
							value="<?php echo $res_orders['fabric_name'];?>" readonly style="border:none;" size="10"></td>
							<td style="width:3%" data-toggle="tooltip" title="Fabric Dia"><input type="text" name="color[]" 
							value="<?php echo $res_orders['style_no'];?>" readonly style="border:none;" size="10"></td>
							<td style="width:3%"><input type="text" name="dia[]" value="<?php echo $res_orders[''];?>" readonly style="border:none;" size="10"></td>
							<td style="width:5%" data-toggle="tooltip" title="PLANNING Weight">
							<input type="text" id="inward_wgt<?php echo $cj;?>" name="inward_wgt[]" 
							value="<?php echo $yarn_det['wgt'];?>" readonly style="border:none;" size="10"></td>
							<td style="width:5%" data-toggle="tooltip" title="PLANNING Weight">
							<input type="text" class="form-control" id="delivery_wgt<?php echo $cj;?>" 
							name="delivery_wgt[]" readonly value="<?php echo $sel_dc['delivered_wgt'];?>"></td>
							<td style="width:5%" data-toggle="tooltip" title="PLANNING Weight">
							<input  id="balance_wgt<?php echo $cj;?>" type="text" class="form-control" name="balance_wgt" readonly 
							value="<?php echo $balance_wgt;?>"></td>
							<td style="width:10%"><input type="text" class="form-control" name="enter_wgt[]" 
							onkeyup="calc_wgt('<?php echo $cj;?>');"></td>
						</tr>
				<?php $cj++;} ?>
						<tr>
							<td colspan="6"><strong>TOTAL WEIGHT</strong></td>
							<td>
								<input type="text" name="total" id="total" class="form-control">
							</td>
						</tr>
					</tbody>
				</table>
				<div class="card" style="width:100%">
			<div class="border-top">
				<div class="card-body" style="margin-left: 400px;">
					<button type="submit" name="save" class="btn btn-success" >Save</button>
					<button type="reset" class="btn btn-primary">Reset</button>
				</div>
			</div>
		</div>
			</div>
				<?php// }
		// }
		 ?>
							</div>
                        </div>
                    </div>
                </div>
                <!-- Sales chart -->
                <!-- ============================================================== -->
            </div>
            <!-- End Container fluid  -->
            <!-- footer -->
           <?php include('includes/footer.php');?>
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
		</form>
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
	<!--datatables JavaScript -->
    <script src="dist/js/jquery.dataTables.min.js"></script>
    <script src="dist/js/dataTables.bootstrap4.min.js"></script>
    <script>
	function cal_tweight1(rw){
		//delwgt_
		//planwgt_
		//balwgt_
		var pw = $('#planwgt_'+rw).val();
		var nw = $('#delwgt_'+rw).val();
		var dl = $('#del_wgt'+rw).val();
		var bw = $('#balwgt1_'+rw).val();
		if(bw=='0' || bw==''){
			 bw = parseFloat(pw)-parseFloat(nw);
		} else {
			 bw = parseFloat(bw)-parseFloat(nw);
		}
		$('#balwgt_'+rw).val(bw);
		
		var sum = 0;
		$('.tweight').each(function() {
			sum += Number($(this).val());
		});
		$('#total_weight1').val(sum);
	}

	$('.delivery_wgt').keyup(function () {
		var sum = 0;
		$('.delivery_wgt').each(function() {
			sum += Number($(this).val());
		});
		$('#total').val(sum);
	});

	$(document).ready(function() {
		$('#example').DataTable();
	});
	function DeleteUsrId(ID){
	  var UsrStatus = confirm("Are you sure to delete this company details ?");
	  if(UsrStatus){
		$('#delete_'+ID).hide();
	  }
	  }
	</script>

</body>
</html>