<?php 
include('includes/config.php');
include('includes/base_functions.php');  

if($_REQUEST['sel_buyer']){
			$buyer=$_REQUEST['sel_buyer'];
			$select=mysqli_query($zconn,"select * from order_entry_master where order_no='".$buyer."'");
			$rowcount=mysqli_num_rows($select);

			$style_list .= '<select class="select2 form-control custom-select chosen-select" name="style_no" id="style" onchange="myFunction();">';

			if($rowcount >0){

			 $style_list .='<option value="Select">Select</option>';
			while ($row=mysqli_fetch_object($select)) {


				 $style_list .='<option value="'.$row->style_no.'">'.$row->style_no.'</option>';


			}
			}


			else {

				   $style_list .='<option value="">Order No not available</option>';
			}
}

$style_list .='</select>';
echo $style_list;
?>
 <script type="text/javascript">
												$(".chosen-select").chosen({
											  	no_results_text: "Oops, nothing found!"
												})
											</script>



