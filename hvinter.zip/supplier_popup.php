<?php 
include('includes/config.php');?>

<link href="dist/css/style.min.css" rel="stylesheet">
<link href="dist/css/bootstrap.css" rel="stylesheet">

<form name="supplier_info" id="supplier_info" method="post">
<div class="row">
                    <div class="col-md-12" style="font-size:14px;" >
						<div class="col-md-4" style="float:left; padding:0px; margin:0px; width:700px;">
						<div class="form-group row">
										<label for="scode" class="col-sm-3 text-right control-label col-form-label" nowrap>Supplier Code</label>
										<?php 
										if($colid==''){
										$sel_code = mysqli_fetch_array(mysqli_query($zconn,"select max(supplier_id) as SID from suppliers"),MYSQLI_ASSOC);
										$scode = $sel_code['SID'];
										if($scode=='' || $scode==NULL){
											$scode_disp='1000';
										} else {
											$scode_disp = $scode+1;
										}
										$supplier_code = SCONFIG.$scode_disp;
										} else {
											$supplier_code = $colData['supplier_code'];
										}
										?>
										<div class="col-sm-6">
											<input type="text" class="form-control" readonly id="scode"  name="scode" required value="<?php echo $supplier_code;?>">
										</div>
									</div>
									
									<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">Supplier Type</label>
										<div class="col-sm-6">
										
                                        <select id="stype" name="stype" class="select2 form-control custom-select" style="width: 100%; height:36px;">
                                            <option>Select</option>
											<?php $stype_sql = mysqli_query($zconn,"select * from supplier_types where status='0'");
										while($res_style = mysqli_fetch_array($stype_sql)){
											if($colData['supplier_type_id']==$res_style['supplier_type_id']){
											?>
											<option selected value="<?php echo $res_style['supplier_type_id']; ?>"><?php echo $res_style['supplier_type']; ?></option>
											<?php } else { ?>
											<option value="<?php echo $res_style['supplier_type_id']; ?>"><?php echo $res_style['supplier_type']; ?></option>
										<?php } ?>
									<?php } ?>
									</select>
								</div>
							</div>
							<div class="form-group row">
										<label for="lname" class="col-sm-3 text-right control-label col-form-label">Supplier Name</label>
										<div class="col-sm-6">
											<input type="text" class="form-control" required id="sname" name="sname" placeholder="Supplier name" value="<?php echo $colData['supplier_name'];?>" autocomplete="off">
										</div>
									</div>
									<div class="form-group row">
										<label for="lname" class="col-sm-3 text-right control-label col-form-label">Address -1</label>
										<div class="col-sm-6">
											<input type="text" class="form-control" required name="txt_add1" id="txt_add1" autocomplete="off" value="<?php echo $colData['supplier_address1'];?>" placeholder="Address">
										</div>
									</div>
									<div class="form-group row">
										<label for="lname" class="col-sm-3 text-right control-label col-form-label">Address -2</label>
										<div class="col-sm-6">
											<input type="text" required id="txt_add2" name="txt_add2" class="form-control" id="lname" autocomplete="off" value="<?php echo $colData['supplier_address2'];?>" placeholder="Address">
										</div>
									</div>
									<div class="form-group row">
										<label for="email1" class="col-sm-3 text-right control-label col-form-label">State</label>
										<div class="col-sm-6">
                                        <select name="state_id" id="state_id" class="select2 form-control custom-select" style="width: 100%; height:36px;" onchange="sel_dist(this.value);">
                                            <option>Select</option>
											<?php $sel_state = mysqli_query($zconn,"select * from states where status='Active'");
											while($res_state = mysqli_fetch_array($sel_state,MYSQLI_ASSOC)){
												if($colData['state_id']==$res_state['state_id']){
											?>
											<option selected value="<?php echo $res_state['state_id'];?>"><?php echo $res_state['state_name'];?></option>
											<?php } else { ?>
											<option value="<?php echo $res_state['state_id'];?>"><?php echo $res_state['state_name'];?></option>
												
												<?php } } ?>
										</select>
										</div>
									</div>
									<div class="form-group row">
										<label for="cono1" class="col-sm-3 text-right control-label col-form-label"> District</label>
										<div class="col-sm-6">
                                        <span id="dist_list">
                                        <select class="form-control" name="dist_id" id="dist_id">
				<option value="">--Select--</option>
				<?php $sel_dist = mysqli_query($zconn,"select * from districts where status='Active' and state_id='".$colData['state_id']."'");
					while($res_dist = mysqli_fetch_array($sel_dist,MYSQLI_ASSOC)){
						if($colData['district_id']==$res_dist['dist_id']){
				?>
				<option selected='selected' value="<?php echo $res_dist['dist_id'];?>"><?php echo $res_dist['dist_name'];?></option>
				<?php } else {?>
				<option value="<?php echo $res_dist['dist_id'];?>"><?php echo $res_dist['dist_name'];?></option>
				<?php } ?>
				<?php } ?>
				</select>
				</span>
			</div>
		</div>
				<div class="form-group row">
				<label for="cono1" class="col-sm-3 text-right control-label col-form-label"> Area</label>
				<div class="col-sm-6">
				<span id="area_list">
				<select class="select2 form-control custom-select" style="width: 100%; height:36px;" name="city" id="city">
					<option>Select</option>
				<?php $sel_area = mysqli_query($zconn,"select * from area where status='Active' and dist_id='".$colData['district_id']."'");
					while($res_area = mysqli_fetch_array($sel_area,MYSQLI_ASSOC)){
						if($colData['area_id']==$res_area['id']){
				?>
				<option selected='selected' value="<?php echo $res_area['id'];?>"><?php echo $res_area['area_name'];?></option>
				<?php } else {?>
				<option value="<?php echo $res_area['id'];?>"><?php echo $res_area['area_name'];?></option>
				<?php } ?>
				<?php } ?>
										</select>
										</span>
										</div>
									</div>
									<div class="form-group row">
										<label for="cono1" class="col-sm-3 text-right control-label col-form-label">Country</label>
										<div class="col-sm-6">
											<input type="text" class="form-control" autocomplete="off" id="scontry" name="scountry" placeholder="Country" value="<?php echo $colData['suplier_country'];?>">
										</div>
									</div>
									<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">Pincode </label>
										<div class="col-sm-6">
											<input type="text" class="form-control" autocomplete="off" id="spincode" name="spincode" placeholder="Pincode" value="<?php echo $colData['supplier_pincode'];?>">
										</div>
									</div>
									
					</div>
						<div class="col-md-4" style="float:left;">
						<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">Mobile number</label>
										<div class="col-sm-6">
											<input type="text" class="form-control" autocomplete="off" id="smobile" value="<?php echo $colData['supplier_mobile'];?>" name="smobile" placeholder="mobile">
										</div>
									</div>
									<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">Telephone</label>
										<div class="col-sm-6">
											<input type="text" class="form-control" autocomplete="off" id="sphone" value="<?php echo $colData['supplier_phone'];?>" name="sphone" placeholder="Telephone">
										</div>
									</div>
									<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">Email Id</label>
										<div class="col-sm-6">
											<input type="text" class="form-control" id="semail" name="semail" autocomplete="off" value="<?php echo $colData['supplier_email'];?>" placeholder="email">
										</div>
									</div>
									<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">Pancard</label>
										<div class="col-sm-6">
											<input type="text" class="form-control" autocomplete="off" name="span_card" value="<?php echo $colData['supplier_pancard'];?>" id="span_card" placeholder="Pancard">
										</div>
									</div>
									<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">GST</label>
										<div class="col-sm-6">
											<input type="text" class="form-control" name="supplier_gst" id="supplier_gst" value="<?php echo $colData['supplier_gst'];?>" autocomplete="off" placeholder="GST">
										</div>
									</div>
									<div class="form-group row">
										<label for="email1" class="col-sm-3 text-right control-label col-form-label">Status</label>
										<div class="col-sm-6" style="margin-top:10px;">

					  <input type="radio" id="stat-act"  value="0" <?php if(isset($colData['status'])){ if($colData['status']=='0'){ ?> checked <?php } }else{ ?> checked <?php } ?>  name="rad_status" class="flat-red" > Active
					  <input type="radio" id="stat-inact"  value="1" <?php if($colData['status']=='1'){ ?> checked <?php } ?> name="rad_status" class="flat-red"> In Active

										</div>
									</div>
						
						</div>
						<div class="col-md-4" style="float:left;"><h4 class="card-title" style="text-align: center;"><b>Bank Details</b></h4>

									<div class="form-group row">
										<label for="cono1" class="col-sm-3 text-right control-label col-form-label">Bank Name </label>
										<div class="col-sm-6">
											<input type="text" class="form-control" name="bank_name" id="bank_name" value="<?php echo $colData['bank_name'];?>" autocomplete="off" placeholder="Bank name">
										</div>
									</div>
									<div class="form-group row">
										<label for="cono1" class="col-sm-3 text-right control-label col-form-label">Branch Name</label>
										<div class="col-sm-6">
											<input type="text" class="form-control" name="branch_name" id="branch_name" autocomplete="off" placeholder="Branch" value="<?php echo $colData['branch_name'];?>">
										</div>
									</div>
									<div class="form-group row">
										<label for="cono1" class="col-sm-3 text-right control-label col-form-label">Account Number</label>
										<div class="col-sm-6">
											<input type="text" class="form-control" name="acc_number" id="acc_number" placeholder="Account number" autocomplete="off" value="<?php echo $colData['account_number'];?>">
										</div>
									</div>
									<div class="form-group row">
										<label for="cono1" class="col-sm-3 text-right control-label col-form-label">IFSC Code</label>
										<div class="col-sm-6">
											<input type="text" class="form-control" name="ifsc_code" id="ifsc_code" autocomplete="off" placeholder="IFSC code" value="<?php echo $colData['ifsc_code'];?>">
										</div>
									</div>
									<div class="form-group row">
										<label for="cono1" class="col-sm-3 text-right control-label col-form-label">Account name</label>
										<div class="col-sm-6">
											<input type="text" class="form-control" id="account_name" name="account_name" autocomplete="off" placeholder="Account name" value="<?php echo $colData['account_name'];?>">
										</div>
									</div></div>
					<div class="border-top">
								<div class="card-body" style="text-align: center;">
									<button type="submit" class="btn btn-success"onclick="">Save</button>
									<button type="reset" class="btn btn-primary">Reset</button>
									<a href="javascript:;" onclick="window.close();"><button type="button" class="btn btn-danger">Close</button></a>
								</div>
							</div>
					</div>
					
					</div>
               
				<input type="hidden" name="action" id="action" value="supplieradd_pop" />
	  <?php if(isset($colid)){ ?>
		<input type="hidden" name="colid" id="colid" value="<?php echo $colid ?>" />
	  <?php  } ?>
				</form>
			    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
	
				<script>
	$(function () {
		$("form#supplier_info").submit(function(e) {
			e.preventDefault();
			var formData = new FormData(this);
			$.ajax({
				url: "ajax/suppliers.php",
				type: 'POST',
				data: formData,
				success: function (data) {
					data =data.split('~~~');
					if($.trim(data[0])=='1'){
					//	alert("Supplier added successfully!!");
						//$('#supp_list').html(data[1]);
				window.opener.document.getElementById("supp_list").innerHTML=data[1];
				window.close();
				window.opener.document.getElementById('supp_msg').innerHTML='Supplier added successfully!!';
 
 				} 
					if($.trim(data[0])=='2'){
						alert("Supplier Name already exists!!");
					} 
					if($.trim(data[0])=='0'){
						alert("Query Failed");
					}
				},
				cache: false,
				contentType: false,
				processData: false
			});
		});
	 });
</script>