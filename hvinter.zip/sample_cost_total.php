<?php 
include('includes/config.php');
include('includes/base_functions.php');
extract($_REQUEST);

if($_SESSION['userid']==''){
	echo "<script>window.location.href='login.php';</script>";
}

				$grant_total=0;
					if($id!=''){ $cost0 = mysqli_fetch_array(mysqli_query($zconn,"select * from process_planning_flow where id='".$id."'"),MYSQLI_ASSOC);
                        $costb = mysqli_fetch_array(mysqli_query($zconn,"select * from order_entry_master WHERE order_no = '" . $cost0['order_no'] . "' AND style_no = '" . $cost0['style_no'] . "'"),MYSQLI_ASSOC);
                        //var_dump($costb);
		
$sn = 1;
$grant_total1 = 0; // Initialize the grant total

$yarn_master_query = mysqli_query($zconn, "SELECT * FROM yarn_entry_master WHERE order_no = '" . $cost0['order_no'] . "' AND style_no = '" . $cost0['style_no'] . "'");

while ($row = mysqli_fetch_assoc($yarn_master_query)) {
    $yarn_details_query = mysqli_query($zconn, "SELECT * FROM yarn_entry_details WHERE yarn_id = '" . $row['id'] . "'");

    while ($rate1 = mysqli_fetch_assoc($yarn_details_query)) {
       

        // Update the grant total
        $grant_total1 += $rate1['yarn_total'];
        
    }
}

$sn = 1;
$kn1_query = mysqli_query($zconn, "SELECT * FROM knitting_planning_master WHERE order_no = '" . $cost0['order_no'] . "' AND style_no = '" . $cost0['style_no'] ."'");

while ($kn1 = mysqli_fetch_assoc($kn1_query)) {
    $knit_query = mysqli_query($zconn, "SELECT * FROM knitting_planning WHERE knitt_id = '" . $kn1['id'] . "'");
    
    while ($knit = mysqli_fetch_assoc($knit_query)) {
   

        $grant_total_knitting +=$knit['wgt'];
        $knit_loss_total +=$knit['knit_loss'];


    }
}

$sn = 1;
$dy1_query = mysqli_query($zconn, "SELECT * FROM dyeing_planning_master WHERE order_no = '" . $cost0['order_no'] . "' AND style_no = '" . $cost0['style_no'] . "'");

while ($dy1 = mysqli_fetch_assoc($dy1_query)) {
    $dye_query = mysqli_query($zconn, "SELECT * FROM dyeing_planning WHERE dye_id = '" . $dy1['id'] . "'");
    
    while ($dye = mysqli_fetch_assoc($dye_query)) {
        


        $grant_total_dyeing += $dye['weight'];
        $dye_loss_total += $dye['dye_loss'];

    }
}


$op1 = mysqli_query($zconn, "SELECT * FROM process_planning_master WHERE order_no = '" . $cost0['order_no'] . "' AND style_no = '" . $cost0['style_no'] . "'");
$sn = 1;

while ($ppo = mysqli_fetch_assoc($op1)) {
    $id = $ppo['id'];

    // Fetch data from process_planning based on the $id
    $opp = mysqli_query($zconn, "SELECT * FROM process_planning WHERE process_id = '$id'");

    // Loop through the rows in process_planning
    while ($opp_data = mysqli_fetch_assoc($opp)) {
     
        $grant_total_other += $opp_data['wgt'];
        $process_loss_total += $opp_data['process_loss'];

    }
}


$fab_tot = $grant_total_knittingr+$grant_total_dyeing+$grant_total_other;

// Output the rounded total with a currency symbol
//echo '₹&nbsp;', round($fab_tot);

        $distinctAccessories = mysqli_query($zconn, "SELECT * FROM accessories_planning_list WHERE order_no = '" . $cost0['order_no'] . "' AND style_no = '" . $cost0['style_no'] . "'");
$sn=1;
while ($acc = mysqli_fetch_assoc($distinctAccessories)) {
    $id = $acc['id'];

    // Fetch data from process_planning based on the $id
    $cca = mysqli_query($zconn, "SELECT * FROM accessories_planning WHERE planning_id = '$id'");

    // Loop through the rows in process_planning
    while ($acc_data = mysqli_fetch_assoc($cca)) {
           

			$grant_total_acc += $acc_data['total_qty'];
            $acc_loss_total += $acc_data['acc_loss'];
        }
    }
      


$ove_tot = $grant_total_knittingr+$grant_total_dyeing+$grant_total_other+$grant_total_acc;

// Output the rounded total with a currency symbol
echo '₹&nbsp;', round($ove_tot);
}
?>
		

						
				 
				