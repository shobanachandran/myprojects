<?php
	error_reporting(0);
	include("includes/config.php");
	extract($_REQUEST);
	$currentFile = $_SERVER["SCRIPT_NAME"];
	$parts = explode('/', $currentFile);
	$currentFile = $parts[count($parts) - 1];


//$rights = check_rights($zconn,$currentFile);

	if($_SESSION['userid'] == '') { ?>
<script>window.location = 'logout.php';</script>
<?php exit();
	}
	$action = 'staffadd';
	$breadcrumb = 'Add';
	$sucessMsg = 'User Added Successfully';
	if(isset($userid)){
		$sucessMsg = 'User Updated Successfully';
		$action = 'staffedit';
		$breadcrumb = 'Edit';
		$edtUsrQry = "SELECT * FROM staffs WHERE staff_id='".$userid."'";
		$edtUsrResource = mysqli_query($zconn,$edtUsrQry);
		$userData = mysqli_fetch_array($edtUsrResource,MYSQLI_ASSOC);
		$userid = $userData['staff_id'];
		$staff_name = $userData['staff_name'];
		$staff_code = $userData['staff_code'];
		 $staff_mobile = $userData['staff_mobile'];
		 $staff_position = $userData['staff_position'];

		$typeid = $userData['TYPEID'];
		$dept_id = $userData['dept_id'];
		$team_id = $userData['team_id'];
		$status = $userData['status'];
		$staff_address = $userData['staff_address'];
		$staff_salary = $userData['staff_salary'];
		$staff_bloodgroup = $userData['staff_bloodgroup'];
		$staff_econtact = $userData['staff_econtact'];
		$staff_relation = $userData['staff_relation'];
	}
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<!-- Tell the browser to be responsive to screen width -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Garments ERP">
	<meta name="author" content="Iorange Innovation">
	<!-- Favicon icon -->
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>CLEVER ERP - Users Add</title>
	<!-- Custom CSS -->
	<!-- Custom CSS -->
	<link href="dist/css/style.min.css" rel="stylesheet">
</head>

<body>
	<div id="main-wrapper">
		<!-- ============================================================== -->
		<!-- Topbar header - style you can find in pages.scss -->
		<!-- ============================================================== -->
		<?php include('includes/header.php');?>
		<!-- End Topbar header -->
		<!-- ============================================================== -->
		<!-- ============================================================== -->
		<!-- Left Sidebar - style you can find in sidebar.scss  -->
		<?php include('includes/sidebar.php');?>

		<!-- End Left Sidebar - style you can find in sidebar.scss  -->
		<!-- ============================================================== -->
		<!-- ============================================================== -->
		<!-- Page wrapper  -->
		<div class="page-wrapper" style="min-height: 100%; height: auto;">
			<!-- ============================================================== -->
			<!-- Bread crumb and right sidebar toggle -->
			<div class="page-breadcrumb">
				<div class="row">
					<div class="col-12 d-flex no-block align-items-center">
						<h4 class="page-title">Staff Add</h4>
						<div class="ml-auto text-right">
							<nav aria-label="breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page"><a href="staffs.php">Users
											Info</a></li>
								</ol>
							</nav>
						</div>
					</div>
				</div>
			</div>
			<!-- End Bread crumb and right sidebar toggle -->
			<!-- ============================================================== -->
			<!-- ============================================================== -->
			<!-- Container fluid  -->
			<div class="container-fluid">
				<!-- ============================================================== -->
				<!-- Sales chart -->
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-body">
							</div>
							<form name="userInfo" id="userInfo" method="post" enctype="multipart/form-data" action="">

								<div class="card-body" style="width:100%">
									<div class="card" style="width:50%; float:left; left: 50px; ">
										<div class="form-group row">
											<label for="fname"
												class="col-sm-3 text-right control-label col-form-label">Staff
												Name</label>
											<div class="col-sm-6">

												<input type="text" value="<?php echo $staff_name; ?>"
													class="form-control" tabindex="1" name="staff_name" id="staff_name"
													placeholder="Enter Name">
											</div>
										</div>
										<!-- /.form-group -->
										<div class="form-group row">
											<label for="lname"
												class="col-sm-3 text-right control-label col-form-label">staff
												Code</label>
											<div class="col-sm-6">
												<input type="text" value="<?php echo $staff_code; ?>"
													class="form-control" tabindex="4" name="staff_code" id="staff_code"
													placeholder="Enter Staff code">
											</div>
											<!-- /.form-group -->
										</div>
										<!-- /.col -->

										<div class="form-group row">
											<label for="cono1" class="col-sm-3 text-right control-label col-form-label">
												Type</label>
											<div class="col-sm-6">
												<select class="form-control select2" tabindex="6" name="typeid"
													id="typeid" style="width: 100%;">
													<option value="">Select</option>
													<?php
						$typQuery = "SELECT typeid,typname FROM users_type WHERE deleted='N' ORDER BY typeid";
						$typResource = mysqli_query($zconn,$typQuery);
						while($typdata=mysqli_fetch_array($typResource,MYSQLI_ASSOC)){
					 ?>
													<option value="<?php echo $typdata['typeid']; ?>" <?php
														if($typeid==$typdata['typeid']){ ?> selected
														<?php } ?>>
														<?php echo $typdata['typname']; ?>
													</option>
													<?php
					   }
					  ?>
												</select>
											</div>
										</div>
										<div class="form-group row">
											<label for="cono1" class="col-sm-3 text-right control-label col-form-label">
												Department</label>
											<div class="col-sm-6">
												<select class="form-control select2" tabindex="6" name="dept_id"
													id="dept_id" style="width: 100%;">
													<option value="">Select</option>
													<?php
						$typQuery = "SELECT dept_id,dept_name FROM user_department  ORDER BY dept_id";
						$typResource = mysqli_query($zconn,$typQuery);
						while($typdata=mysqli_fetch_array($typResource,MYSQLI_ASSOC)){
					 ?>
													<option value="<?php echo $typdata['dept_id']; ?>" <?php
														if($dept_id==$typdata['dept_id']){ ?> selected
														<?php } ?>>
														<?php echo $typdata['dept_name']; ?>
													</option>
													<?php
					   }
					  ?>
												</select>
											</div>
										</div>
										<div class="form-group row">
											<label for="cono1"
												class="col-sm-3 text-right control-label col-form-label">Position</label>
											<div class="col-sm-6">
												<input type="text" value="<?php echo $staff_position; ?>"
													class="form-control" tabindex="5" name="staff_position"
													id="staff_position" placeholder="Enter position">
											</div>
										</div>
										<div class="form-group row">
											<label for="cono1"
												class="col-sm-3 text-right control-label col-form-label">Qualification</label>
											<div class="col-sm-6">
												<input type="text" value="<?php echo $staff_education; ?>"
													class="form-control" tabindex="5" name="staff_education"
													id="staff_education" placeholder="Enter Education">
											</div>
										</div>
										<div class="form-group row">
											<label for="fname"
												class="col-sm-3 text-right control-label col-form-label">Mobile
												Number</label>
											<div class="col-sm-6">
												<input type="text" value="<?php echo $staff_mobile; ?>"
													class="form-control" tabindex="2"
													onkeypress="return isNumberKey(event)" maxlength="15"
													name="staff_mobile" id="staff_mobile"
													placeholder="Enter Mobile number">
											</div>
										</div>
										<div class="form-group row">
											<label for="lname"
												class="col-sm-3 text-right control-label col-form-label">Upload
												Documents</label>
											<div class="col-sm-6">
												<input type="file" class="form-control" tabindex="5" id="con_photo"
													name="con_photo">

												<img align="middle" src="uploads/contractors/<?php echo $con_photo;?>"
													width="100" height="100">
											</div>
										</div>

										<div class="form-group row">
											<label for=""
												class="col-sm-3 text-right control-label col-form-label">Status</label>
											<div class="col-sm-6" style="margin-top:10px;">

												<label>
													<input type="radio" value="Active" <?php if(isset($status)){
														if($status=='Active' ){ ?> checked
													<?php } }else{ ?> checked
													<?php } ?> name="status" class="flat-red" > Active
												</label>
												<?php if($userid!=1){  ?>
												<label>
													<input type="radio" value="In active" <?php if($status=='In active'
														){ ?> checked
													<?php } ?> name="status" class="flat-red"> In Active
												</label>
												<?php } ?>
											</div>
											<!-- /.form-group -->
										</div>
									</div>
									<!-- /.form-group -->
									<div class="card" style="width:50%; float:left; right: 50px;">
										<div class="form-group row">
											<label for="cono1"
												class="col-sm-3 text-right control-label col-form-label">Email</label>
											<div class="col-sm-6">
												<input type="text" value="<?php echo $staff_email; ?>"
													class="form-control" tabindex="5" name="staff_email"
													id="staff_email" placeholder="Enter email">
											</div>
										</div>

										<div class="form-group row">
											<label for="cono1"
												class="col-sm-3 text-right control-label col-form-label">Address</label>
											<div class="col-sm-6">
												<textarea value="<?php echo $staff_address; ?>" class="form-control"
													tabindex="5" name="staff_address" id="staff_address"
													placeholder="Enter Address"></textarea>
											</div>
											<!-- /.form-group -->
										</div>
										<div class="form-group row">
											<label for="cono1"
												class="col-sm-3 text-right control-label col-form-label">Blood
												Group</label>
											<div class="col-sm-6">
												<input type="text" value="<?php echo $staff_bloodgroup; ?>"
													class="form-control" tabindex="3" name="staff_bloodgroup"
													id="staff_bloodgroup" placeholder="Enter Blood Group">
											</div>
											<!-- /.form-group -->
										</div>
										<div class="form-group row">
											<label for="cono1"
												class="col-sm-3 text-right control-label col-form-label">Emergency
												Contact</label>
											<div class="col-sm-6">
												<input type="text" value="<?php echo $staff_econtact; ?>"
													class="form-control" tabindex="3" name="staff_econtact"
													id="staff_econtact" placeholder="Enter Emergency No">
											</div>
											<!-- /.form-group -->
										</div>
										<div class="form-group row">
											<label for="cono1"
												class="col-sm-3 text-right control-label col-form-label">Relationship</label>
											<div class="col-sm-6">
												<input type="text" value="<?php echo $staff_relation; ?>"
													class="form-control" tabindex="3" name="staff_relation"
													id="staff_relation"
													placeholder="Enter Relationship with phone number">
											</div>

										</div>
										<div class="form-group row">
											<label for="cono1"
												class="col-sm-3 text-right control-label col-form-label">Salary</label>
											<div class="col-sm-6">
												<input type="text" value="<?php echo $staff_salary; ?>"
													class="form-control" tabindex="5" name="staff_salary"
													id="staff_salary" placeholder="Enter Salary">
											</div>

										</div>
										<div class="form-group row">
											<label for="cono1"
												class="col-sm-3 text-right control-label col-form-label">Allowance</label>
											<div class="col-sm-6">
												<input type="text" value="<?php echo $staff_allow; ?>"
													class="form-control" tabindex="5" name="staff_allow"
													id="staff_allow" placeholder="Enter Allowance">
											</div>

										</div>
										<div class="form-group row">
											<label for="lname"
												class="col-sm-3 text-right control-label col-form-label">Upload
												Photo</label>
											<div class="col-sm-6">
												<input type="file" class="form-control" id="con_photo" name="con_photo">

												<img align="middle" src="uploads/contractors/<?php echo $con_photo;?>"
													width="100" height="100">
											</div>
										</div>


										<!-- /.row -->
									</div>
								</div>
						</div>
						<div class="border-top">
							<div class="card-body" style="text-align: center;">
								<button type="submit" class="btn btn-success">Save</button>
								<button type="reset" class="btn btn-primary">Reset</button>
								<a href="staffs.php"><button type="button" class="btn btn-danger">Back</button></a>
							</div>
							<input type="hidden" name="action" id="action" value="<?php echo $action ?>" />
							<?php if(isset($userid)){ ?>
							<input type="hidden" name="userid" id="userid" value="<?php echo $userid ?>" />
							<?php  } ?>
							</form>
						</div>
					</div>
				</div>
			</div>
			<!-- Sales chart -->
			<!-- ============================================================== -->
		</div>
		<!-- End Container fluid  -->
		<!-- ============================================================== -->
	</div>
	<!-- End Page wrapper  -->
	<!-- ============================================================== -->

	</div>
	<!-- End Wrapper -->
	<!-- ============================================================== -->
	<!-- footer -->
	<?php include('includes/footer.php');?>
	<!-- End footer -->
	<!-- ============================================================== -->
	<!-- ============================================================== -->
	<!-- All Jquery -->
	<script src="assets/libs/jquery/dist/jquery.min.js"></script>
	<!-- Bootstrap tether Core JavaScript -->
	<script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
	<script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
	<script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
	<script src="assets/extra-libs/sparkline/sparkline.js"></script>
	<!--Wave Effects -->
	<script src="dist/js/waves.js"></script>
	<!--Menu sidebar -->
	<script src="dist/js/sidebarmenu.js"></script>
	<!--Custom JavaScript -->
	<script src="dist/js/custom.min.js"></script>
	<script src="dist/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>

	<script>
		$(function () {
			//Date picker
			$('#dobirth').datepicker({
				format: 'dd/mm/yyyy',
				autoclose: true
			})
			$('#dojoin').datepicker({
				format: 'dd/mm/yyyy',
				autoclose: true
			})
			//Datemask dd/mm/yyyy
			//	$('#dobirth').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
			//Datemask2 mm/dd/yyyy
			//	$('#dojoin').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })

			$("form#userInfo").submit(function (e) {
				//$('.loader').show();
				e.preventDefault();
				var formData = new FormData(this);
				if ($('#staff_name').val() == '') {
					alert("Please enter Name");
					$('#staff_name').focus();
					//	$('.loader').hide();
					return false;
				}
				// if($('#email').val()!=''){
				// 	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
				// 	if (reg.test($('#email').val()) == false) 
				// 	{	//$('#'+emailField.id).focus();
				// 		alert("Please enter Valid Email Address");
				// 		$('#email').val('');
				// 	//	$('.loader').hide();
				// 		return false;
				// 	}
				// }
				if ($('#staff_code').val() == '') {
					alert("Please enter Username");
					$('#staff_code').focus();
					//	$('.loader').hide();
					return false;
				}
				// if($('#usrpwd').val()==''){
				// 	alert("Please enter Password");
				// 	$('#usrpwd').focus();
				// 	//$('.loader').hide();
				// 	return false;
				// }
				if ($('#typeid').val() == '') {
					alert("Please enter User Type");
					$('#typeid').focus();
					//$('.loader').hide();
					return false;
				}

				//	$("#save").hide();
				$.ajax({
					url: "ajax/staffs.php",
					type: 'POST',
					data: formData,
					success: function (data) {
						if ($.trim(data) == "exist") {
							alert("Username Already Exist");
							//	$('.loader').hide();
						}
						if ($.trim(data) == true) {
							alert("<?php echo $sucessMsg; ?>");
						<? php if (!isset($userid)) { ?>
								document.getElementById("userInfo").reset();
					   <? php } ?>
								//	$('.loader').hide();
								window.location.href='staffs.php';
						}
						if ($.trim(data) == "error") {
							alert("Process Failed Kindly. Try again");
							document.getElementById("userInfo").reset();
							//	$('.loader').hide();
						}
					},
					cache: false,
					contentType: false,
					processData: false
				});
			});
		});

	</script>
</body>

</html>