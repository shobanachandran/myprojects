<?php
include('includes/config.php');

session_start();

if (empty($_SESSION['userid'])) {
    echo "<script>window.location.href='login.php';</script>";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle form submission
    // ...

    // Example MySQLi query:
    // Include your database configuration here
    include('includes/config.php');
}
?>

<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE; ?> - Return DC</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
</head>
<body>
    <div id="main-wrapper">
        <!-- Topbar header -->
        <?php include('includes/header.php'); ?>
        <!-- End Topbar header -->

        <!-- Left Sidebar -->
        <?php include('includes/sidebar.php'); ?>
        <!-- End Left Sidebar -->

        <!-- Page wrapper -->
        <div class="page-wrapper" style="min-height: 100%; height: auto;">
            <!-- Bread crumb and right sidebar toggle -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Return DC</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="#">General DC</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->

            <!-- Container fluid -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <form name="debit_entry" id="debit" method="post">
                                <div class="row" style="padding-top:0px;">
                                    <div class="col-md-12">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="card">
                                                        <div class="card-header">
                                                            <h4 class="card-title">General Return DC Entry Form</h4>
                                                        </div>
                                                        <div class="card-body">
                                                            <form name="" action="" method="post">
                                                                <!-- Form fields go here -->
                                                                <div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="dcno">Dc No</label>
            <select name="dcno" id="dcno" class="form-control" onchange="this.form.submit()">
                <option>----Select----</option>
                <?php
                $sql = mysqli_query($connection, "SELECT DISTINCT(`prime_id`) as `prime_id` FROM `general_dc` WHERE `return` = 'yes'");
                while ($res_dc = mysqli_fetch_object($sql)) {
                    $selected = ($res_dc->prime_id == $_REQUEST['dcno']) ? 'selected="selected"' : '';
                    echo '<option value="' . $res_dc->prime_id . '" ' . $selected . '>' . $res_dc->prime_id . '</option>';
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="date">Date</label>
            <input type="text" name="date" class="form-control datepicker" value="<?php echo date("d-m-Y", strtotime($get_from_dc->date)); ?>" />
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label for="receive_date">Receive Date</label>
            <input type="text" name="receive_date" class="form-control datepicker" value="<?php echo date("d-m-Y"); ?>" />
        </div>
        <div class="form-group">
            <label for="party_name">Party Name</label>
            <input type="text" name="party_name" class="form-control" value="<?php echo $to2; ?>" readonly />
        </div>
        <div class="form-group">
            <label for="party_name">Remarks</label>
            <input type="text" name="party_name" class="form-control" value="<?php echo $to2; ?>" readonly />
        </div>
    </div>
</div>
<div class="form-group">
    <label for="notes">Notes</label>
    <textarea name="notes" class="form-control" cols="25" rows="7"></textarea>
</div>

<div class="form-group">
<table class="table table-striped table-bordered" id="tblPets">
    <tr>
        <th ><strong>Particular</strong></th>
        <th ><strong>Qty</strong></th>
    </tr>
    <?php 
    $sql_sql=mysqli_query("SELECT *  FROM `general_dc` WHERE `prime_id` = '".$_REQUEST['dcno']."'");
    while($res_sql=mysqli_fetch_object($sql_sql)){?>
    <tr>
        <td ><?php echo $res_sql->particular;?></td>
        <td ><?php echo $res_sql->qty; ?></td>
    </tr>
    <?php } ?>
</table>
</div>
                                                                <!-- Add more form fields as needed -->

                                                                <div class="form-actions" align="right">
                                                                    <button type="submit" class="btn btn-primary" name="submit123">Make Return</button>
                                                                    <button class="btn">Cancel</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Page wrapper -->

        <!-- Footer -->
        <?php include('includes/footer.php'); ?>
        <!-- End Footer -->
    </div>

    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!-- Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!-- Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
</body>
</html>