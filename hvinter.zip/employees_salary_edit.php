<?php
include('includes/config.php');

// Execute the SQL query to fetch data
$query = "SELECT es.id, es.dept_id, es.emp_id, es.emp_name, es.emp_amt, es.created_at, es.emp1_id,
                emp.emp_name AS emp_name_employee, emp.emp_code, emp.TYPEID, emp.dept_id AS emp_dept_id,
                emp.emp_position, emp.emp_mobile, emp.emp_address, emp.emp_bloodgroup,
                emp.emp_econtact, emp.emp_relation, emp.emp_shiftamt, emp.status AS emp_status, emp.ADDDATE,
                emp.ADDUSER, emp.DELETED, emp.EDTUSER, emp.EDTDATE, emp.DELUSER, emp.DELDATE,
                dm.dept_name, dm.status AS dept_status, dm.created_by, dm.created_date
        FROM emp_salary AS es
        LEFT JOIN employees AS emp ON es.emp_id = emp.emp_id
        LEFT JOIN department_master AS dm ON emp.dept_id = dm.dept_id";

$result = mysqli_query($zconn, $query);
?>

<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Other meta tags, title, and stylesheets go here -->
</head>

<body>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Employee Name (from emp_salary)</th>
                <th>Department Name</th>
                <th>Employee Name (from employees)</th>
                <!-- Add more table headers for other columns as needed -->
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['emp_name'] . "</td>";
                echo "<td>" . $row['dept_name'] . "</td>";
                echo "<td>" . $row['emp_name_employee'] . "</td>";
                // Add more table cells for other columns as needed
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</body>

</html>
