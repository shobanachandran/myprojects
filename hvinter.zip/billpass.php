<?php 
include('includes/config.php');

if($_SESSION['userid']==''){
	echo "<script>window.location.href='login.php';</script>";
}

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - Bill Pass 	</title>
    <!-- Custom CSS -->
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">    
</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <div class="page-wrapper" style="min-height: 100%; height: auto;">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
             <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Bill Pass </h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="#">Bill Pass </a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
			<div class="container-fluid">   
				<div class="row">
                    <div class="col-md-12">
                        <div class="card">            
                <!-- ============================================================== -->
                <!-- Sales chart -->
				
				
			<form name="colInfo" id="colInfo" method="post" enctype="multipart/form-data" action="">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
							<div class="card-body">
							</div>
								<div class="card-body" style="width:100%">
									<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">Bill By</label>
										<div class="col-sm-3">
                                        <select class="form-control" name="state_id" id="state_id" onchange="sel_dist(this.value);">
				<option value="">--Select--</option>
				<option value="volvo">SUPPLIER</option>
				<option value="saab">PROCESS</option>
				<option value="fiat">JOBWORK</option>
				</select>
										</div>
									</div>
									<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">Filter By Department</label>
										<div class="col-sm-3">
                                        <select class="form-control" name="state_id" id="state_id" onchange="sel_dist(this.value);">
				<option value="">--Select--</option>
				<?php $sel_state = mysqli_query($zconn,"select * from states where status='Active'");
					while($res_state = mysqli_fetch_array($sel_state,MYSQLI_ASSOC)){
						if($state_id==$res_state['state_id']){
				?>
				<option selected='selected' value="<?php echo $res_state['state_id'];?>"><?php echo $res_state['state_name'];?></option>
				<?php } else {?>
				<option value="<?php echo $res_state['state_id'];?>"><?php echo $res_state['state_name'];?></option>
				<?php } ?>
				<?php } ?>
				</select>
										</div>
									</div>
									<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">Filter By Supplier</label>
										<div class="col-sm-3">
										<span id="dist_list">
                                        <select class="form-control" name="dist_id" id="dist_id">
				<option value="">--Select--</option>
				<?php $sel_dist = mysqli_query($zconn,"select * from districts where status='Active' and state_id='".$state_id."'");
					while($res_dist = mysqli_fetch_array($sel_dist,MYSQLI_ASSOC)){
						if($dist_id==$res_dist['dist_id']){
				?>
				<option selected='selected' value="<?php echo $res_dist['dist_id'];?>"><?php echo $res_dist['dist_name'];?></option>
				<?php } else {?>
				<option value="<?php echo $res_dist['dist_id'];?>"><?php echo $res_dist['dist_name'];?></option>
				<?php } ?>
				<?php } ?>
				</select>
				</span>
										</div>
									</div>
								<!--	<div class="form-group row">
										<label for="lname" class="col-sm-3 text-right control-label col-form-label">Area</label>
										<div class="col-sm-3">
                <input type="text" value="<?php echo $colname; ?>" class="form-control" tabindex="1" name="colname" id="colname" placeholder="Enter Area name">
										</div>
									</div>-->
								<!--	<div class="form-group row">
										<label for="email1" class="col-sm-3 text-right control-label col-form-label">Status</label>
										<div class="col-sm-6" style="margin-top:10px;">
					  <input type="radio" id="stat-act"  value="Active" <?php if(isset($status)){ if($status=='Active'){ ?> checked <?php } }else{ ?> checked <?php } ?>  name="status" class="flat-red" > Active
					  <input type="radio" id="stat-inact"  value="In active" <?php if($status=='In active'){ ?> checked <?php } ?> name="status" class="flat-red"> In Active
										</div>
									</div>-->
								</div>
									
						<!--	<div class="border-top">
								<div class="card-body" style="margin-left: 250px;">
									<button type="submit" class="btn btn-success">Save</button>
									<button type="reset" class="btn btn-primary">Reset</button>
									<a href="area.php"><button type="button" class="btn btn-danger">Back</button></a>
								</div>
							</div>-->
                        </div>
                    </div>
                </div>
				<input type="hidden" name="action" id="action" value="<?php echo $action ?>" />
	  <?php if(isset($colid)){ ?>
		<input type="hidden" name="colid" id="colid" value="<?php echo $colid ?>" />
	  <?php  } ?>
				</form>
                <!-- Sales chart -->
                <!-- ============================================================== -->           
			<form name="" action="supplier_bill2.php?choose=<?php echo $_SESSION['choose'];?>&supplier=<?php echo $_REQUEST['supplier'];?>" method="post">
                    <?php if(isset($_SESSION['choose']) && $_SESSION['choose'] == 'fabric' ){?>
                            <table width="75%" border="0" align="center" cellpadding="0" cellspacing="0" class="table table-striped table-bordered">
                                  <thead>
                                  <tr>
                                    <td width="2%">&nbsp;</td>
                                    <td width="15%">Date</td>
                                    <td width="15%">Pono</td>
                                    <td width="13%">Style No</td>
                                    <td width="13%">Fabric</td>
                                    <td width="10%">Color</td>
                                    <td width="10%">Kgs</td>
                                    <td width="16%">Rate</td>
                                    <td width="13%">Amount</td>
                                  </tr>
                                  </thead>
                                  <tbody>
                                  <?php
                                /*  $sql_get="SELECT * FROM `fabric_received` WHERE `status` = '' and `date` >= '2014-07-15' and `supplier_id` = '".$_REQUEST['supplier']."' and `kgs` != '0'";
								  //echo $sql_get;
                                  $sql_get=mysqli_query($sql_get)or die(mysqli_error());
                                  while($res_get=mysqli_fetch_object($sql_get)){
                                  ?>
                                  <tr>
                                    <td><input type="checkbox" name="id[]" value="<?php echo $res_get->id;?>" /></td>
                                    <td><?php echo date("d-m-Y",strtotime($res_get->date));?></td>
                                    <td><?php echo $res_get->pono;?></td>
                                    <td><?php echo $res_get->styleno;?></td>
                                    <td><?php echo $name=$res_get->fab_name;?></td>
                                    <td><?php echo $res_get->color;?></td>
                                    <td><?php echo $res_get->kgs;?></td>
                                    <td><?php echo $res_get->price;?></td>
                                    
                      <!--  <td><input type="text" name="price_rate_<?php echo $res_get->i;?>" id="price_rate" class="span8" value="<?php echo $res_get->price_rate;?>"></td>-->
                        
                                   <td><?php echo $res_get->kgs * $res_get->price;?> </td>

                                   
                                  </tr>
                                  <?php }?>
                                  </tbody>
                                  <tfoot>
                                  <tr>
                                    <td colspan="9" class="form-actions">
                                    <input type="submit" name="submit123" value="Save Changes" class="btn btn-primary" />
                                    <input type="reset" name="reset123" value="Cancel" class="btn" />
                                    </td>
                                    </tr>
                                  </tfoot>
                                </table>
                    <?php }elseif($_SESSION['choose'] == 'store'){ */?>
                   			<table width="75%" border="0" align="center" cellpadding="0" cellspacing="0" class="table table-striped table-bordered">
                                  <thead>
                                  <tr>
                                    <td width="2%">&nbsp;</td>
                                    <td width="15%">Date</td>
                                    <td width="15%">Pono</td>
                                    <td width="13%">Style No</td>
                                    <td width="13%">Fabric</td>
                                    <td width="10%">Kgs</td>
                                    <td width="16%">Rate</td>
                                    <td width="13%">Amount</td>
                                  </tr>
                                  </thead>
                                  <tbody>
                                  <?php
                                /*  $sql_get="SELECT * FROM `store_received` WHERE `status` = '' and `date` >= '2015-06-15' and `supplier_id` = '".$_REQUEST['supplier']."' and `kgs` != '0'";
                                  $sql_get=mysqli_query($sql_get)or die(mysqli_error());
                                  while($res_get=mysqli_fetch_object($sql_get)){
                                  ?>
                                  <tr>
                                    <td><input type="checkbox" name="id[]" value="<?php echo $res_get->i;?>" /></td>
                                    <td><?php echo date("d-m-Y",strtotime($res_get->date));?></td>
                                    <td><?php echo $res_get->pono;?></td>
                                    <td><?php echo $res_get->styleno;?></td>
                                    <td><?php echo $name=$res_get->name;?></td>
                                    <td><?php echo $res_get->kgs;?></td>
                                    <td><?php echo $res_get->price;?></td>
                                    <td><?php echo $res_get->kgs*$res_get->price;?></td>
                                  </tr>
                                  <?php }?>
                                  </tbody>
                                  <tfoot>
                                  <tr>
                                    <td colspan="8" class="form-actions">
                                    <input type="submit" name="submit123" value="Save Changes" class="btn btn-primary" />
                                    <input type="reset" name="reset123" value="Cancel" class="btn" />
                                    </td>
                                    </tr>
                                  </tfoot>
                                </table>
							
                    <?php }elseif($_SESSION['choose'] == 'yarn'){*/?>
                    		<table width="75%" border="0" align="center" cellpadding="0" cellspacing="0" class="table table-striped table-bordered">
                                  <thead>
                                  <tr>
                                    <td width="2%">&nbsp;</td>
                                    <td width="15%">Date</td>
                                    <td width="15%">Pono</td>
                                    <td width="13%">Style No</td>
                                    <td width="13%">Fabric</td>
                                    <td width="10%">Kgs</td>
                                    <td width="16%">Rate</td>
                                    <td width="13%">Amount</td>
									
                                  </tr>
                                  </thead>
                                  <tbody>
                                  <?php
                                /*  $sql_get="SELECT * FROM `yarns_received` WHERE `status` = '' and `date` >= '2014-06-15' and `supplier_id` = '".$_REQUEST['supplier']."' and `wgt` != '0'";
                                  $sql_get=mysqli_query($sql_get)or die(mysqli_error());
                                  while($res_get=mysqli_fetch_array($sql_get)){
                                  ?>
								 
                                  <tr>
                                    <td><input type="checkbox" name="id[]" value="<?php echo $res_get['id'];?>" /></td>
                                    <td><?php echo date("d-m-Y",strtotime($res_get['date']));?></td>
                                    <td><?php echo $res_get['pono'];?></td>
                                    <td><?php echo $res_get['styleno'];?></td>
                                    <td><?php echo $res_get['yarn_name'];?></td>
                                    <td><?php echo $res_get['wgt'];?></td>
                                    <td><?php echo $res_get['price'];?></td>
                                    <td><?php echo $res_get['wgt']*$res_get['price'];?></td>
                                  </tr>
                                  <?php }*/?>
                                  </tbody>
                                  <tfoot>
                                  <tr>
                                    <td colspan="8" class="form-actions">
                                    <input type="submit" name="submit123" value="Save Changes" class="btn btn-primary" />
                                    <input type="reset" name="reset123" value="Cancel" class="btn" />
                                    </td>
                                    </tr>
                                  </tfoot>
                                </table>
                    <?php }?>
                    </form>
				
            </div>
			</div>
			</div>
	
	
    <!-- End Wrapper -->
	<!-- ============================================================== -->
            <!-- footer -->
            <?php include('includes/footer.php');?>
            <!-- End footer -->
	</div>
	</div>
            <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    
</body>
</html>