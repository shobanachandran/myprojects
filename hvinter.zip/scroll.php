
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

  <!-- Meta Tags -->
  <meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <meta name="description" content="Government Arts College for Women (Autonomous)- Pudukkottai" />
  <meta name="keywords" content="Government Arts College for Women (Autonomous)- Pudukkottai" />

  <!-- Page Title -->
  <title>Kalaignar Karunanidhi Government Arts College for Women (Autonomous)- Pudukkottai</title>

  <!-- Favicon and Touch Icons -->
  <link href="images/favicon.png" rel="shortcut icon" type="image/png">
  <link href="images/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
  <link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
  <link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

  <!-- Stylesheet -->
  <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/animate.min.css" rel="stylesheet" type="text/css">
  <link href="css/javascript-plugins-bundle.css" rel="stylesheet" />

  <!-- CSS | menuzord megamenu skins -->
  <link href="js/menuzord/css/menuzord.css" rel="stylesheet" />

  <!-- CSS | Main style file -->
  <link href="css/style-main.css" rel="stylesheet" type="text/css">
  <link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet" />

  <!-- CSS | Responsive media queries -->
  <link href="css/responsive.css" rel="stylesheet" type="text/css">
  <!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->

  <!-- CSS | Theme Color -->
  <link href="css/colors/theme-skin-color-set1.css" rel="stylesheet" type="text/css">

  <!-- external javascripts -->
  <script src="js/jquery.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/javascript-plugins-bundle.js"></script>
  <script src="js/menuzord/js/menuzord.js"></script>

  <!-- REVOLUTION STYLE SHEETS -->
  <link rel="stylesheet" type="text/css" href="js/revolution-slider/css/rs6.css">
  <link rel="stylesheet" type="text/css" href="js/revolution-slider/extra-rev-slider1.css">
  <!-- REVOLUTION LAYERS STYLES -->
  <!-- REVOLUTION JS FILES -->
  <script src="js/revolution-slider/js/revolution.tools.min.js"></script>
  <script src="js/revolution-slider/js/rs6.min.js"></script>
  <script src="js/revolution-slider/extra-rev-slider1.js"></script>

  <!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->


  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <script>
    $(document).ready(function() {
      // Open modal on page load
      $("#myModal").modal('show');

      // Close modal on button click
      $(".btn").click(function() {
        $("#myModal").modal('hide');
      });
    });
  </script>
  <style>
    .bs-example {
      margin: 20px;
    }
  </style>

</head>

<body class="tm-container-1300px has-side-panel side-panel-right">
  <!-- Header Start -->
  <div class="side-panel-body-overlay"></div>

<div id="wrapper" class="clearfix">
  <!-- Header -->
  <!-- Header -->

  <header id="header" class="header header-layout-type-header-3rows header-nav-left">
    <div class="header-top">
      <div class="container">
        <div class="row">
          <div class="col-xl-auto header-top-left align-self-center text-center text-xl-start">
            <ul class="element contact-info">
              <li class="contact-phone"><i class="fa fa-phone font-icon sm-display-block"></i>+91 4322 222202</li>
              <li class="contact-email"><i class="fa fa-envelope font-icon sm-display-block"></i> gacwpdkt@yahoo.co.in</li>

            </ul>
          </div>
          <div class="col-xl-auto ms-xl-auto header-top-right align-self-center text-center text-xl-end">
            <div class="element pt-0 pb-0">

            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="header-middle">
      <div class="container">
        <div class="row">
          <div class="col-xl-auto align-self-center header-mid-left text-center text-xl-start">
            <a class="site-brand" href="index.php">
              <img class="logo-default logo-1x" src="images/logo-new1.png" alt="Logo">
            </a>
          </div>

        </div>
      </div>
    </div>
    <div class="header-nav tm-enable-navbar-hide-on-scroll">
      <div class="header-nav-wrapper navbar-scrolltofixed">
        <div class="menuzord-container header-nav-container">
          <div class="container position-relative">
            <div class="row header-nav-col-row">
              <div class="col-sm-auto align-self-center">
                <nav id="top-primary-nav" class="menuzord theme-color2" data-effect="slide" data-animation="none" data-align="right">
                  <ul id="main-nav" class="menuzord-menu">
                    <li class="menu-item"><a href="index.php">Home</a></li>

                    <li class="menu-item"><a href="#">About Us</a>
                      <ul class="dropdown">
                        <li><a href="about-us.php">History of the College</a></li>
                        <li><a href="vision-mission.php">Vision and Mission</a></li>
                        <li><a href="crest-motto.php">Crest & Motto</a></li>
                        <li><a href="index.php#milestone">Milestones</a></li>
                        <li><a href="campus-map.php">Campus Map</a></li>
                        <li><a href="images/about/rollofhouner.jpg">Roll of Honour</a></li>
                        <li><a href="college-song.php">College Song</a></li>
                        <!-- <li><a href="accreditations.php">Accreditations</a></li> -->
                        <li><a href="code-conduct.php">Code of Conduct</a></li>
                        <li><a href="img/Best Practices.pdf" target="_blank">Best Practices</a></li>
                      </ul>
                    </li>

                    <li class="menu-item"><a href="#">Administration</a>
                      <ul class="dropdown">
                        <li><a href="principals-office.php">Administrative Office </a></li>
                        <!-- <li><a href="coe-office.php">COE Office</a></li> -->
                        <li><a href="governing-body.php" target="_blank">Governing Body</a></li>
                        <li><a href="finance-committe.php" target="_blank">Finance Committee</a></li>
                        <li><a href="academic-council.php" target="_blank">Academic Council</a></li>
                        <li><a href="board-of-studies.php">Board of Studies</a></li>
                        <li><a href="img/College Committees.pdf" target="_blank">College Committee</a></li>
                        <li><a href="img/Organogram .pdf" target="_blank">Organogram</a></li>
                      </ul>
                    </li>
                    <li class="menu-item"><a href="#">Admission</a>
                      <ul class="dropdown">
                        <li><a href="images/admission/admission-guideline.pdf">Admission Guidelines</a></li>
                        <li><a target="_blank" href="images/admission-2024-25.pdf">Admission Guidelines 2024-2025</a></li>
                        <li><a href="images/9096%20%20M1%202023%20%2009.05.2023%20-1.PDF">Admission Guidelines 2023-2024</a></li>

                        <li><a href="college-prospectus.php">Prospectus</a></li>
                        <li><a href="fee-structure.php">Fee Structure</a></li>
                        <!-- <li><a href="img/Scholarships.pdf" target="_blank">Scholarships</a></li> -->
                         <li class="menu-item"><a href="#">Scholarships</a>
                      <ul class="dropdown">
                          
                          <li><a href="img/Scholarships.pdf" target="_blank"> Scholarships</a></li>
                          <li><a href="scholarships.php"> Forms </a></li></a></li>
                         </li>
                         </ul>
                      </ul>
                    </li>
                    <li class="menu-item"><a href="#">Academics</a>
                      <ul class="dropdown">
                        <li class="menu-item"><a href="#">Departments</a>
                          <ul class="dropdown">
                            <li><a href="botany.php">Botany</a></li>
                            <li><a href="business-administration.php">BBA</a></li>
                            <li><a href="chemistry.php">Chemistry</a></li>
                            <li><a href="computer-science.php">Computer Science</a></li>
                            <li><a href="commerce.php">Commerce</a></li>
                            <li><a href="economics.php">Economics</a></li>
                            <li><a href="english.php">English</a></li>
                            <li><a href="history.php">History</a></li>
                            <li><a href="mathematics.php">Mathematics</a></li>
                            <li><a href="physics.php">Physics</a></li>
                            <li><a href="tamil.php">Tamil</a></li>
                            <li><a href="tourism.php">Tourism & Travel Management</a></li>
                            <li><a href="zoology.php">Zoology</a></li>
                          </ul>
                        </li>
                        <li><a href="courses-offered.php">Courses Offered</a></li>
                        <li><a href="images/department/PO-PSO/PO,PSO.pdf" target="_blank">POs & PSOs </a></li>
                        <li><a href="images/department/CO/CO.pdf" target="_blank">Course Outcomes </a></li>
                        <li><a href="syllabus.php">Syllabus </a></li>
                        <li><a href="academic-calender.php">Academic Calender </a></li>
                        <li><a href="library.php">Library </a></li>
                      </ul>
                    </li>
                    <li class="menu-item"> <a href="https://Kkgacwpdk.controllerofexamination.com">COE</a>
                      <!-- <ul class="dropdown">
                        <li><a href="about-examination.php">About Examination</a></li>
                        <li><a href="office-of-the-coe.php">Office of The COE</a></li>
                        <li><a href="exam-timetable.php">Exam TimeTable</a></li>
                        <li><a href="cia.php">CIA</a></li>
                        <li><a href="evaluation-process.php">Evaluation Process</a></li>
                        <li><a href="coe-down-the-years.php">COE-Down The Years</a></li>
                        <li><a href="best-practice.php">Best Pratices</a></li>
                      </ul>
                    </li> -->


                    <li class="menu-item"><a href="#">Research</a>
                    
                    <ul class="dropdown">
                        <li><a href="https://www.bdu.ac.in/academics/regulations.php" target="_blank">Regulations</a></li>
                        <li><a href="pdf/Research Promotion Policy.pdf" target="_blank">Research Promotion Policy</a></li>
                        <li><a href="pdf/Research Ethics.pdf" target="_blank">Research Ethics</a></li>
                        <li><a href="pdf/Research Committee.pdf" target="_blank">Research Advisory Committee</a></li>
                        <li><a href="pdf/Research Centre Recognition.pdf" target="_blank">Research Centre Recognition</a></li>
                        <li class="menu-item"><a href="#">Research Programmes</a>
                        <ul class="dropdown">
                            <!--<li><a href="research_programmes.php#economics">Ph.D Economics</a></li>-->
                            <li><a href="research_programmes.php#english">Ph.D English</a></li>
                            <li><a href="research_programmes.php#history">Ph.D History</a></li>
                            <li><a href="research_programmes.php#maths">Ph.D Mathematics</a></li>
                            <li><a href="research_programmes.php#physics">Ph.D Physics</a></li>
                          </ul>
                        </li>
                        
                      </ul>
                    
                    
                    
                    
                    
                    </li>
                    <li class="menu-item"><a href="services.php">Support Services</a>
                      <ul class="dropdown">
                        <li><a href="clubs&forums.php">Clubs and Forums</a></li>
                        <li><a href="club_members.php">Club Members</a></li>
                      </ul>
                    </li>


                    <li class="menu-item"><a href="#">IQAC</a>
                      <ul class="dropdown">
                        <li class="menu-item"><a href="#">Composition</a>
                          <ul class="dropdown">
                            <li><a href="Composition-2018.php">2018-2019</a></li>
                            <li><a href="Composition-2019.php">2019-2021</a></li>
                            <li><a href="Composition-2021.php">2021-2023</a></li>
                          </ul>
                        </li>

                        <li class="menu-item"><a href="#">Minutes</a>
                          <ul class="dropdown">
                            <li><a href="Minutes-2018.php">2018-2019</a></li>
                            <li><a href="Minutes-2019.php">2019-2020</a></li>
                            <li><a href="Minutes-2020.php">2020-2021</a></li>
                            <li><a href="Minutes-2021.php">2021-2022</a></li>
                            <li><a href="Minutes-2022.php">2022-2023</a></li>
                          </ul>
                        </li>

                        <li class="menu-item"><a href="#">AQAR</a>
                          <ul class="dropdown">
                            <li><a href="aqar-2022.php">AQAR 2022-2023</a></li>
                            <li><a href="aqar-2021.php">AQAR 2021-2022</a></li>
                            <li><a href="aqar-2020.php">AQAR 2020-2021</a></li>
                            <li><a href="aqar-2019.php">AQAR 2019-2020</a></li>
                            <li><a href="aqar-2018.php">AQAR 2018-2019</a></li>
                            <li><a href="aqar-2017.php">AQAR 2017-2018 </a></li>

                            <!-- Add more options as needed -->
                          </ul>
                        </li>
                       </ul>
                    </li>


                    <li class="menu-item"><a href="#">NAAC</a>
                      <ul class="dropdown">
                        <li class="menu-item"><a href="#">Accreditations</a>
                          <ul class="dropdown">
                            <li><a href="images/about/accreditations/naac-1stcycle.pdf">I Cycle(2004)</a></li>
                            <li><a href="images/about/accreditations/naac-2nd cycle.pdf">II Cycle(2011)</a></li>
                            <li><a href="images/about/accreditations/naac-3rd cycle.pdf">III Cycle(2017)</a></li>
                          </ul>
                        </li>



                        <li class="menu-item"><a href="#">Mandatory Disclosure</a>
                          <ul class="dropdown">
                            <li><a href="#">IIQA Compliance </a></li>
                            <li><a href="#">RTI Declaration</a></li>

                          </ul>
                        </li>
                        <li><a href="naac-2023/TNCOGN11562.pdf">SSR Report After DVV </a></li>

                        <li><a href="https://gacwpdkt.ac.in/SSR/index.php">SSR </a></li>
                      </ul>
                    </li>

                    <li class="menu-item"><a href="#">NIRF</a>
                      <ul class="dropdown">
                        <li><a href="nirf-2024.php">NIRF 2024</a></li>
                        <li><a href="nirf-2023.php">NIRF 2023</a></li>
                        <li><a href="nirf-2022.php">NIRF 2022</a></li>
                        <li><a href="nirf-2021.php">NIRF 2021</a></li>
                        <li><a href="nirf-2020.php">NIRF 2020</a></li>
                        <li><a href="nirf-2017-2018.php">NIRF 2019</a></li>

                      </ul>
                    </li>

                    <li class="menu-item"><a href="#">Alumni</a>
                      <ul class="dropdown">
                        <li><a href="alumni_application_preview.php">Alumni-Registration</a></li>
                        <li><a href="alumni-signin.php">Alumni-Login</a></li>
                      </ul>
                    </li>

                    <li class="menu-item"><a href="#">Feedback</a>
                    <ul class="dropdown">

                    <li class="menu-item"><a href="#">feedback Analysis</a>
                          <ul class="dropdown">
                        <li><a href="feedback-student-2022.php">2022-2023</a></li>
                        <li><a href="feedback-student-2021.php">2021-2022</a></li>
                        <li><a href="feedback-student-2020.php">2020-2021</a></li>
                        <li><a href="feedback-student-2019.php">2019-2020</a></li>
                        <li><a href="feedback-Alumni-2018.php">2018-2019</a></li>
                        </ul>
                        </li>

                        <li class="menu-item"><a href="#">Action Taken</a>
                          <ul class="dropdown">
                        <li><a href="img/actiontaken/ActionTaken 2022-2023.pdf" target="_blank">2022-2023</a></li>
                        <li><a href="img/actiontaken/ActionTaken 2021-2022.pdf" target="_blank">2021-2022</a></li>
                        <li><a href="img/actiontaken/ActionTaken 2020-2021.pdf" target="_blank">2020-2021</a></li>
                        <li><a href="img/actiontaken/ActionTaken 2019-2020.pdf" target="_blank">2019-2020</a></li>
                        <li><a href="img/actiontaken/ActionTaken 2018-2019.pdf" target="_blank">2018-2019</a></li>
                        </ul>
                        </li>
                    </ul>

                    </li>
                    <li class="menu-item"><a href="#">UG-ADMISSION RANK LIST 2024-2025</a>
                      <ul class="dropdown">
                        <li><a href="ranklist.php">Arts </a></li>
                        <li><a href="ranklist-sci.php">Science</a></li>
                        <li><a href="ranklist_2024/Andaman&Nicobar List.pdf">Andaman & Nicobar </a></li>
                        <li><a href="ranklist_2024/Ex_servicemen List.pdf">Ex service Men</a></li>
                        <li><a href="ranklist_2024/NCC List.pdf">NCC </a></li>
                        <li><a href="ranklist_2024/PC List.pdf">PC</a></li>
                        <li><a href="ranklist_2024/Security Forces List.pdf">Security Forces </a></li>
                        <li><a href="ranklist_2024/Sports List new.pdf">Sports</a></li>
                      </ul>
                    </li>

                    <li class="menu-item"> <a href="news/PUDUMAI PEN 2022.pdf">PUDUMAI PEN 2024 </a></li>
                    <li class="menu-item"> <a href="Gallery.php">Gallery</a></li>

                  </ul>
                </nav>
              </div>

            </div>
            <div class="row d-block d-xl-none">
              <div class="col-12">
                <nav id="top-primary-nav-clone" class="menuzord d-block d-xl-none default menuzord-color-default menuzord-border-boxed menuzord-responsive" data-effect="slide" data-animation="none" data-align="right">
                  <ul id="main-nav-clone" class="menuzord-menu menuzord-right menuzord-indented scrollable">
                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>  <!-- Header End -->

  <!-- Start main-content -->
  <div class="main-content-area">
    <!-- Section: home Start -->
    <section id="home">
      <div class="container-fluid p-0">
        <div class="row">
          <div class="col">
            <!-- START Industrivo Rev Slider 2 REVOLUTION SLIDER 6.1.7 -->
            <p class="rs-p-wp-fix"></p>
            <rs-module-wrap id="rev_slider_1_1_wrapper" data-alias="industrivo-rev-slider-2" data-source="gallery" style="background:transparent;padding:0;margin:0px auto;margin-top:0;margin-bottom:0;">
              <rs-module id="rev_slider_1_1" style="display:none;" data-version="6.1.7">
                <rs-slides>

                <rs-slide data-key="rs-9" data-title="Slide 1" data-thumb="images/bg/new-banner2.jpeg" data-anim="ei:d;eo:d;s:d;r:0;t:slotslide-horizontal;sl:d;">
                    <img src="images/bg/new-banner2.jpeg" title="slide1" data-parallax="off" class="rev-slidebg" data-no-retina>
                  </rs-slide>




                  <rs-slide data-key="rs-9" data-title="Slide 1" data-thumb="images/bg/new-banner.jpeg" data-anim="ei:d;eo:d;s:d;r:0;t:slotslide-horizontal;sl:d;">
                    <img src="images/bg/new-banner.jpeg" title="slide1" data-parallax="off" class="rev-slidebg" data-no-retina>
                  </rs-slide>


                  <rs-slide data-key="rs-9" data-title="Slide 1" data-thumb="images/bg/bgkk1.jpg" data-anim="ei:d;eo:d;s:d;r:0;t:slotslide-horizontal;sl:d;">
                    <img src="images/bg/bgkk1.jpg" title="slide1" data-parallax="off" class="rev-slidebg" data-no-retina>
                  </rs-slide>

                  <rs-slide data-key="rs-9" data-title="Slide 1" data-thumb="images/bg/bgkk2.jpg" data-anim="ei:d;eo:d;s:d;r:0;t:slotslide-horizontal;sl:d;">
                    <img src="images/bg/bgkk2.jpg" title="slide1" data-parallax="off" class="rev-slidebg" data-no-retina>
                  </rs-slide>

                  <rs-slide data-key="rs-9" data-title="Slide 1" data-thumb="images/bg/bgkk3.jpg" data-anim="ei:d;eo:d;s:d;r:0;t:slotslide-horizontal;sl:d;">
                    <img src="images/bg/bgkk3.jpg" title="slide1" data-parallax="off" class="rev-slidebg" data-no-retina>
                  </rs-slide>

                  <rs-slide data-key="rs-9" data-title="Slide 1" data-thumb="images/bg/bgkk4.jpg" data-anim="ei:d;eo:d;s:d;r:0;t:slotslide-horizontal;sl:d;">
                    <img src="images/bg/bgkk4.jpg" title="slide1" data-parallax="off" class="rev-slidebg" data-no-retina>
                  </rs-slide>

                  <rs-slide data-key="rs-9" data-title="Slide 2" data-thumb="images/bg/bgkk5.jpg" data-anim="ei:d;eo:d;s:d;r:0;t:slotslide-horizontal;sl:d;">
                    <img src="images/bg/bgkk5.jpg" title="slide2" data-parallax="off" class="rev-slidebg" data-no-retina>
                  </rs-slide>

                  <rs-slide data-key="rs-9" data-title="Slide 3" data-thumb="images/bg/bgkk6.jpg" data-anim="ei:d;eo:d;s:d;r:0;t:slotslide-horizontal;sl:d;">
                    <img src="images/bg/bgkk6.jpg" title="slide1" data-parallax="off" class="rev-slidebg" data-no-retina>
                  </rs-slide>

                  <rs-slide data-key="rs-9" data-title="Slide 1" data-thumb="images/bg/bgkk7.jpg" data-anim="ei:d;eo:d;s:d;r:0;t:slotslide-horizontal;sl:d;">
                    <img src="images/bg/bgkk7.jpg" title="slide1" data-parallax="off" class="rev-slidebg" data-no-retina>
                  </rs-slide>

                </rs-slides>
                <rs-static-layers>
                  <!--
                    -->
                </rs-static-layers>
                <rs-progress class="rs-bottom" style="height: 5px; background: rgba(199,199,199,0.5);"></rs-progress>
              </rs-module>
              <script>
                if (typeof revslider_showDoubleJqueryError === "undefined") {
                  function revslider_showDoubleJqueryError(sliderID) {
                    var err = "<div class='rs_error_message_box'>";
                    err += "<div class='rs_error_message_oops'>Oops...</div>";
                    err += "<div class='rs_error_message_content'>";
                    err += "You have some jquery.js library include that comes after the Slider Revolution files js inclusion.<br>";
                    err += "To fix this, you can:<br>&nbsp;&nbsp;&nbsp; 1. Set 'Module General Options' -> 'Advanced' -> 'jQuery & OutPut Filters' -> 'Put JS to Body' to on";
                    err += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jQuery.js inclusion and remove it";
                    err += "</div>";
                    err += "</div>";
                    jQuery(sliderID).show().html(err);
                  }
                }
              </script>
            </rs-module-wrap>
            <!-- END REVOLUTION SLIDER -->
          </div>
        </div>
      </div>
    </section>
    <!-- Section: home End -->

    <!-- Section: why Chose Us-->
    <section data-tm-bg-img="images/bg/bg5.jpg">
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-xl-8">
              <div class="row">
                <div class="col-lg-12">
                  <div class="tm-whychose-box pr-40 mb-40 mt-20 pr-md-0">
                    <h2 class="title font-weight-300">Kalaignar Karunanidhi Government Arts College for Women (Autonomous)</h2>
                  </div>
                </div>
                <div class="col-md-7 col-lg-12 mb-md-30">
                  <div class="tm-whychose-box">
                    <p class="tm-whychs-paragh mb-0 blktxt" align="justify">Kalaignar Karunanidhi Government Arts College for Women (Autonomous), Pudukkottai, was established in the year 1969. The college was started with Pre-University Course and has grown gradually in strength and stature in every sphere of activity. At present 13 Under Graduate Courses, 10 Post Graduate Courses, 6 M.Phil. and 6 Ph.D Courses are being offered by the college. Shift System was introduced in the year 2007 by the State Government Policy of Education with the available infrastructure. Four Under Graduate Courses have been introduced in Shift II. The institution aims to uplift women students from Pudukkottai district and also from nearby districts like Thiruchirappalli, Perambalur and Sivagangai. <br><br> The college was affiliated to the University of Madras till 1982. Since then, the College has been affiliated to Bharathidasan University, Thiruchirappalli. The year 2004 was a milestone in the history of the College during which the College was accredited with B++ by NAAC and Autonomous status was conferred.</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12 col-lg-12 col-xl-4">
              <div class="tm-whychose-box mt-lg-40">
                <div class="tm-get-quote bg-theme-colored1 p-50 p-sm-20">
                  <h3 class="title font-weight-600 text-white">News & Events</h3>
                  <marquee direction="up" height="200" scrollamount="4" onmouseover="stop();" onmouseout="start();">


                  <p ><b style="font-size: 18px;">
                  Financial Hackathon
                      </b> </p> <p align="right"> <a href="news/financial hackathon card.pdf" target="blank">>>> Details<<<</a> </p>



                    <p ><b style="font-size: 18px;">
                        NAAC Peer Team Visit - 22.08.2024, 23.08.2024
                      </b> </p> <!--<p align="right"> <a href="/news/news-ind.jpeg" target="blank">>>> Details<<<</a> </p>-->

                    <p ><b style="font-size: 18px;">
                        புதுமை பெண் திட்டம் - 2024
                      </b> </p><!--<p align="left" class="text-white">Audio</p> <p align="right"> <a href="/news/pudhumai.ogg" target="blank">>>> Details<<<</a> </p>-->




                    <!-- 
 <p class="text-white"><b style="font-size: 18px;">
   UG-ADMISSION RANK LIST 2022
</b> </p> <p align="right"> <a href="ranklist.php" target="blank">>>> Details<<<</a> </p>
 -->

                    <!-- <p class="text-white"><b style="font-size: 18px;">
    <span class="far fa-clock mr-1" style="color: #e8ac2a;"></span>29.04.2022<br>Tourism  Students Association Meeting
</b> </p> <p align="right"> <a href="news/news15.pdf" target="blank">>>> Details<<<</a> </p>


  
  <p class="text-white"><b style="font-size: 18px;">
    <span class="far fa-clock mr-1" style="color: #e8ac2a;"></span>28.04.2022<br>Career Counselling Guidance Cell Organising  SWAYAM(Online Courses)-Ar Exposure</b> </p> <p align="right"> <a href="news/news14.jpg" target="blank">>>> Details<<<</a> </p>

  <p class="text-white"><b style="font-size: 18px;">
    <span class="far fa-clock mr-1" style="color: #e8ac2a;"></span>25.04.2022<br>ASSOCIATION MEETING of Commerce department on 25.04.2022 Monday </p>

    <p class="text-white"><b style="font-size: 18px;">
    <span class="far fa-clock mr-1" style="color: #e8ac2a;"></span>23.04.2022<br>Commerce Department Organising career Councelling on 23.04.2022 Saturday @ 2.00 P.M</b> </p> <p align="right"> <a href="images/career counselling commerce.jpg" target="blank">>>> Details<<<</a> </p>

    <p class="text-white"><b style="font-size: 18px;">
    <span class="far fa-clock mr-1" style="color: #e8ac2a;"></span>23.04.2022<br>TNPSC Examination Guidelines on 23.04.2022 Saturday @ 11.00 A.M</b> </p> <p align="right"> <a href="images/TNPSC Exam guideline.jpg" target="blank">>>> Details<<<</a> </p>

  <p class="text-white"><b style="font-size: 18px;">
    <span class="far fa-clock mr-1" style="color: #e8ac2a;"></span>22.04.2022<br>PG & RESEARCH DEPARTMENT OF HISTORY ASSOCIATION MEETING on 22.04.2022 Friday @ 11.00 A.M All are cordially invited</b> </p> <p align="right"> <a href="news/PG HISTORY ASSOCIATION MEETING (2).pdf" target="blank">>>> Details<<<</a> </p>

    <p class="text-white"><b style="font-size: 18px;">
      <span class="far fa-clock mr-1" style="color: #e8ac2a;"></span>23.04.2022<br>PG & RESEARCH DEPARTMENT OF HISTORY ALUMINI MEETING on 23.04.2022 Saturday @ 4.00 P.M through Google meet. All are cordially Invited 
    </b></p><p align="right"> <a href="news/HISTORY DEPARTMENT ALUMINI MEETING 2022.pdf" target="blank">>>> Details<<<</a></p>   

    <p class="text-white"><b style="font-size: 18px;">
      <span class="far fa-clock mr-1" style="color: #e8ac2a;"></span>22.04.2022<br>PG & Rescarch Department of English Organizes Career Counselling for final Year Students on 22.04.2022 Friday @ 11.30 P.M 
    </b></p><p align="right"> <a href="news/Adobe Scan 21-Apr-2022.pdf" target="blank">>>> Details<<<</a></p>      

 <p class="text-white"><b style="font-size: 18px;">
<span class="far fa-clock mr-1" style="color: #e8ac2a;"></span>12.04.2022<br>We are happy to invite you to the Virtual Alumnae meet of our department on 12.04.2022 Tuesday @ 3.00 P.M to 4.00 P.M through Google meet. Join us and revive your memories. Your presence means a lot.</b> </p> <p align="right"> <a href="news/news13.jpg" target="blank">>>> Details <<<</a> </p>

 <p class="text-white"><b style="font-size: 18px;">
<span class="far fa-clock mr-1" style="color: #e8ac2a;"></span>06.04.2022<br>PG & Research Department Of History  Association Meeting</b> </p> <p align="right"> <a href="news/news12.pdf" target="blank">>>> Details <<<</a> </p>

 <p class="text-white"><b style="font-size: 18px;">
<span class="far fa-clock mr-1" style="color: #e8ac2a;"></span>04.04.2022<br>Career Counseling for UG Botany Students on Mushroom Cultivation</b> </p> <p align="right"> <a href="news/news11.jpg" target="blank">>>> Details <<<</a> </p>

 <p class="text-white"><b style="font-size: 18px;">
<span class="far fa-clock mr-1" style="color: #e8ac2a;"></span><br>Department of Computer Science &
 Internal Quality Assurance Cell of Organizes Career Counselling for Outgoing Students Gateway to Government Jobs</b> </p> <p align="right"> <a href="news/news10.jpg" target="blank">>>> Details <<<</a> </p>
                    <p class="text-white"><b style="font-size: 18px;">
<span class="far fa-clock mr-1" style="color: #e8ac2a;"></span> 19.03.2022<br>Curriculum Design Using Mapping</b> </p> <p align="right"> <a href="news/news6.pdf" target="blank">>>> Details <<<</a> </p>


                    <p class="text-white"><b style="font-size: 18px;">
<span class="far fa-clock mr-1" style="color: #e8ac2a;"></span> 11.03.2022-12.03.2022<br>Career Counselling for PG Students</b> </p> <p align="right"> <a href="news/news5.jpeg" target="blank">>>> Details <<<</a> </p>

                    <p class="text-white"><b style="font-size: 18px;">
<span class="far fa-clock mr-1" style="color: #e8ac2a;"></span> 01.03.2022 <br>Hon'ble CM - Career Counseling Launched
 Programne Telecasted - 1st March 9.30 am till 1 P M.<br><br>

மார்ச் 1 ஆம் தேதி 9:30 மணி முதல் மதியம் ஒரு மணிவரை மாண்புமிகு தமிழக முதல்வர் அவர்கள் "CARREER COUNSELLING"  திட்டம் தொடங்கி வைக்கப்பட்டது !!!.</b>
                    </p>
                     <p align="right"> <a href="#" target="blank">>>> Details <<<</a> </p>

                     <p class="text-white"><b style="font-size: 18px;">
<span class="far fa-clock mr-1" style="color: #e8ac2a;"></span> 26.01.2022 <br>Government Arts College for Women(Autonomous),PUDUKKOTTAI-73rd Republic Day celebration</b>
                    </p>
                  <p align="right"> <a href="news/news3.jpg" target="blank">>>> Details <<<</a> </p>
                   <p class="text-white"><b style="font-size: 18px;">
<span class="far fa-clock mr-1" style="color: #e8ac2a;"></span> 26TH JANUARY-2022<br>Government Arts College for Women(Autonomous),PUDUKKOTTAI PRIVILEGE TO INVITE YOU FOR 73 INDIA REPUBLIC DAY
INVITATION</b>
                    </p>
                  <p align="right"> <a href="news/news4.jpg" target="blank">>>> Details <<<</a> </p>
                   <p class="text-white"><b style="font-size: 18px;">
<span class="far fa-clock mr-1" style="color: #e8ac2a;"></span>  08.01.2022 <br>
              PG & RESEARCH DEPARTMENT OF PHYSICS Invites ALUMNI MEET 2022</b>
                    </p>
                  <p align="right"> <a href="news/news2.jpg" target="blank">>>> Details <<<</a> </p>
                  </b>  </p>
                    <p class="text-white"><b style="font-size: 18px;">
<span class="far fa-clock mr-1" style="color: #e8ac2a;"></span>  04.01.2022 <br>
                HANDS ON WORKSHOP Servicing techniques of electric and electronic instruments for new Entrepreneur By PG & RESEARCH DEPARTMENT OF PHYSICS </b>
                    </p>
                  <p align="right"> <a href="news/news1.jpg" target="blank">>>> Details <<<</a> </p>
                  </b>  </p>
                 <p class="text-white"><b style="font-size: 18px;">
<span class="far fa-clock mr-1" style="color: #e8ac2a;"></span>  27-09-2021 <br>
                World Tourism Day 2021 conducted by Department of Tourism and Travel Management </b>
                    </p>
                  <p align="right"> <a href="news/World-Tourism-Day-2021.pdf" target="blank">>>> Details <<<</a> </p>
                  </b>  </p>
 <!--  -->
                    <!-- 
                   <p class="text-white"><b style="font-size: 16px;"> <a href="#">Admission 2021-2022 Rank List</a></p>
                    <p class="text-white"><b style="font-size: 16px;"> <a href="special-category.php">Special Category</a></p>
                      <p class="text-white"><b style="font-size: 16px;"> <a href="arts-rank-list.php">Arts Rank List</a></p>
                        <p class="text-white"><b style="font-size: 16px;"> <a href="science-rank-list.php">Science Rank List</a></p>
                          <p class="text-white"><b style="font-size: 16px;"> <a href="commerce-bba.php">Commerce and BBA</a></p>

<hr style="color: #e8ac2a;"><p class="text-white"> <span style="color:#ffcd42"> 10:30 AM to 12 PM  </b></span> -->

                  </marquee>
                </div>
                <div class="tm-thumb">
                  <img class="img-fullwidth" src="assets/images/iorangelogo.jpg" alt="4.jpg">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Divider -->

    <!-- Section: About -->
    <section class="bg-img-right-top bg-img-no-repeat" data-tm-bg-img="images/bg/bg4.jpg">
      <div class="container pt-120 pb-90 pt-lg-90">

        <div class="section-content">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-5">
              <div class="about-us-box mb-30 mb-lg-60">
                <div class="widget about_check_list">
                  <h2 class="title mt-0 pr-50 font-weight-300 tm-item-appear-clip-path"><span class="font-weight-800 text-theme-colored1">Why </span> KKGACW…!</h2>
                  <ul style="color:#000;">
                    <li>Only Government College in Pudukkottai district offering quality education for women.</li>
                    <li>Golden Jubilee Institution in prime locality with high academic reputation.</li>
                    <li>Harmonious ambiance with lush green campus.</li>
                    <li>Transparent admission process.</li>
                    <li>Best Curriculum offering Choice Based Credit System enriched with extra credits.</li>
                    <li>Offering financial assistance through scholarships and welfare schemes.</li>
                    <li>Qualified and Committed faculty.</li>
                    <li>Excellent Laboratory facility.</li>
                    <li>Holistic development of students with strong moral values.</li>
                  </ul>
                </div>

              </div>
            </div>


            <div class="col-sm-12 col-md-6 col-lg-6 col-xl-7">
              <h2 class=" font-weight-300 tm-item-appear-clip-path"><span class="text-theme-colored1 font-weight-800">Principal's </span>Message</h2><br>
              <div class="tm-testimonials-box mt-100 mt-lg-130">
                <div class="tm-tst-wrapper first-wrapper mb-90 mb-lg-120 mb-sm-30">
                  <div class="tm-tst-thumb">
                    <img src="" alt="">
                    <!-- <div class="tm_tst_icon bg-theme-colored2"><span class="fas fa-quote-left text-white"></span></div>
                  </div>
                  <div class="tm-tst-details ml-100 ml-sm-0 p-sm-30 mt-sm-20">
                  <h4 class="title" style="font-size: 11px;">Dr. J. Suganthi M.P.Ed., M.Phil., Ph.D.,</h4>
                    <p></p>
                  </div> -->
                  </div>
                  <p class="icon-box-paragh mb-40" align="justify" style="margin-top: -30px; color: #000;">I thank all the surfers on behalf of our faculty, staff and students for visiting our website. We are privileged in providing educational opportunities to women students from rural background across the district. The college has reached greater heights over the period of years in all aspects like academic, research, intra-personal and social growth of students.Since its inception, the college has grown remarkably offering many post-graduate and research programmes.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
    </section>

    <hr>
    <span id="milestone"></span>
    <!-- Section: About -->
    <section class="bg-img-right-top bg-img-no-repeat" data-tm-bg-img="images/bg/bg4.jpg">
      <div class="container pt-120 pb-90 pt-lg-90">

        <div class="section-content">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-5">
              <div class="about-us-box mb-30 mb-lg-60">
                <div class="widget about_check_list">
                  <h2 class="title mt-0 pr-50 font-weight-300 tm-item-appear-clip-path"><span class="font-weight-800 text-theme-colored1">Milestones</h2>
                  <ul style="color:#000;">
                    <li>Year of Establishment : 1969</li>
                    <li>NAAC Accredited Since : 2004</li>
                    <li>Conferred Autonomy in : 2004</li>
                    <li>Golden Jubilee of the College : 2019</li>
                  </ul>
                </div>

              </div>
            </div>


            <div class="col-sm-12 col-md-6 col-lg-6 col-xl-7">
              <h2 class=" font-weight-300 tm-item-appear-clip-path"><span class="text-theme-colored1 font-weight-800">Programmes Offered</h2><br>
              <div class="widget about_check_list">
                <ul style="color:#000;">
                  <li>UG : 13</li>
                  <li>PG : 10</li>
                  <li>M.Phil : 06</li>
                  <li>Ph.D : 06</li>
                  <li>Certificate Course(CLP) : 01</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
    </section>



    <!-- Section: Service 
    <section class="our-services bg-theme-colored3" data-tm-bg-img="images/pattern/p17.png" style="height: 700px;">
      <div class="container pt-120 pb-0 pt-lg-90">
        <div class="tm-sc-section-title">
          <div class="row justify-content-md-center">
            <div class="col-lg-9">
              <div class="title-wrapper text-center" style="margin-top: -50px;">
                <h2 class="title mt-0 pr-50 pr-lg-0 text-white font-weight-300 tm-item-appear-clip-path"><span class="font-weight-800 text-theme-colored1">PROGRAMMES </span> OFFERED</h2>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="container style2 pt-0 pb-120">
        <div class="section-content">
          <div class="row mb-120">
            <div class="col-lg-12">
              <div class="services-slider">
                <div class="tm-owl-carousel-5col" data-dots="true" data-nav="false" data-autoplay="true" data-margin="10" data-loop="true">
                  <div class="item">
                    <div class="img-icon-service-box">
                      <div class="tm-thumb">
                        <img class="img-fullwidth" src="images/courses/1.jpg" alt="1.jpg">
                      </div>
                      <div class="tm-details text-center">
                        <h5 class="title text-white mt-0"><a href="#">Botany</a></h5>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="img-icon-service-box">
                      <div class="tm-thumb">
                        <img class="img-fullwidth" src="images/courses/2.jpg" alt="1.jpg">
                      </div>
                      <div class="tm-details text-center">
                        <h5 class="title text-white mt-0"><a href="#">Chemistry</a></h5>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="img-icon-service-box">
                      <div class="tm-thumb">
                        <img class="img-fullwidth" src="images/courses/3.jpg" alt="1.jpg">
                      </div>
                      <div class="tm-details text-center">
                        <h5 class="title text-white mt-0"><a href="#">Computer Science</a></h5>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="img-icon-service-box">
                      <div class="tm-thumb">
                        <img class="img-fullwidth" src="images/courses/4.jpg" alt="1.jpg">
                      </div>
                      <div class="tm-details text-center">
                        <h5 class="title text-white mt-0"><a href="#">Mathematics</a></h5>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="img-icon-service-box">
                      <div class="tm-thumb">
                        <img class="img-fullwidth" src="images/courses/5.jpg" alt="1.jpg">
                      </div>
                      <div class="tm-details text-center">
                        <h5 class="title text-white mt-0"><a href="#">Physics</a></h5>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="img-icon-service-box">
                      <div class="tm-thumb">
                        <img class="img-fullwidth" src="images/courses/6.jpg" alt="1.jpg">
                      </div>
                      <div class="tm-details text-center">
                        <h5 class="title text-white mt-0"><a href="#">Zoology</a></h5>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="img-icon-service-box">
                      <div class="tm-thumb">
                        <img class="img-fullwidth" src="images/courses/7.jpg" alt="1.jpg">
                      </div>
                      <div class="tm-details text-center">
                        <h5 class="title text-white mt-0"><a href="#">Business Administration-BBA</a></h5>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="img-icon-service-box">
                      <div class="tm-thumb">
                        <img class="img-fullwidth" src="images/courses/8.jpg" alt="1.jpg">
                      </div>
                      <div class="tm-details text-center">
                        <h5 class="title text-white mt-0"><a href="#">Commerce</a></h5>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="img-icon-service-box">
                      <div class="tm-thumb">
                        <img class="img-fullwidth" src="images/courses/9.jpg" alt="1.jpg">
                      </div>
                      <div class="tm-details text-center">
                        <h5 class="title text-white mt-0"><a href="#">Economics</a></h5>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="img-icon-service-box">
                      <div class="tm-thumb">
                        <img class="img-fullwidth" src="images/courses/10.jpg" alt="1.jpg">
                      </div>
                      <div class="tm-details text-center">
                        <h5 class="title text-white mt-0"><a href="#">English</a></h5>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="img-icon-service-box">
                      <div class="tm-thumb">
                        <img class="img-fullwidth" src="images/courses/11.jpg" alt="1.jpg">
                      </div>
                      <div class="tm-details text-center">
                        <h5 class="title text-white mt-0"><a href="#">History</a></h5>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="img-icon-service-box">
                      <div class="tm-thumb">
                        <img class="img-fullwidth" src="images/courses/12.jpg" alt="1.jpg">
                      </div>
                      <div class="tm-details text-center">
                        <h5 class="title text-white mt-0"><a href="#">Tamil</a></h5>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="img-icon-service-box">
                      <div class="tm-thumb">
                        <img class="img-fullwidth" src="images/courses/13.jpg" alt="1.jpg">
                      </div>
                      <div class="tm-details text-center">
                        <h5 class="title text-white mt-0"><a href="#">Tourism & Travel Management</a></h5>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>
         
        </div>
      </div>
    </section>
    <!-- End Divider -->

    <!-- Section: About
    <section class="bg-img-right-top bg-img-no-repeat" data-tm-bg-img="images/bg/bg4.jpg">
      <div class="container pt-120 pb-90 pt-lg-90">
        <!--
       <div class="col-sm-12 col-lg-12">
              <div class="title-wrapper">
                <h2 class="title mt-0 pr-50 font-weight-300 tm-item-appear-clip-path" align="center"><span class="font-weight-800 text-theme-colored1">Infocus</span></h2>
              </div>
            </div> 
        <div class="section-content">
          <div class="row">

            <div class="col-sm-12 col-md-6 col-lg-6 col-xl-4">
              <div class="about-us-box mb-30">
                <div class="tm-sc-funfact funfact mb-30 text-md-center text-lg-end">
                  
                  <h2 class="counter text-theme-colored3 mt-0"> <span class="animate-number" data-animation-duration="1500"></span>1969</h2>
                  <p class="title blktxt">Establishment</p>
                </div>
                
                <hr class="mt-5">
                <div class="tm-sc-funfact funfact mt-30 text-md-center text-lg-end">
                  
                  <h2 class="counter text-theme-colored3 mt-0"> <span class="animate-number" data-animation-duration="1500"></span>2004</h2>
                  <p class="title blktxt">Autonomy</p>
                </div>
                <hr class="mt-5">
                <div class="tm-sc-funfact funfact mt-30 mb-30 text-md-center text-lg-end">
                  
                  <h2 class="counter text-theme-colored3 mt-0"> <span class="animate-number" data-animation-duration="1500"></span>2017</h2>
                  <p class="title blktxt">NAAC B++(Third)</p>
                </div>
                <hr class="mt-5">
                <div class="tm-sc-funfact funfact mt-30 text-md-center text-lg-end">
                  
                  <h2 class="counter text-theme-colored3 mt-0"> <span class="animate-number" data-animation-duration="1500"></span>2019</h2>
                  <p class="title blktxt">Golden Jubilee</p>
                </div>
              </div>
            </div>

            <div class="col-sm-12 col-md-6 col-lg-6 col-xl-4 pr-0">
              <div class="about-us-box mb-30">
                
                <hr class="mt-5">
                <div class="tm-sc-funfact funfact mt-30 text-md-center text-lg-end">
                  
                  <h2 class="counter text-theme-colored3 mt-0"> <span class="animate-number" data-value="127" data-animation-duration="1500">0</span></h2>
                  <p class="title blktxt">Staff Members</p>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-6 col-lg-6 col-xl-4">
              <div class="about-us-box mb-30">
                <div class="tm-sc-funfact funfact mb-30 text-md-center text-lg-end">
                  
                  <h2 class="counter text-theme-colored3 mt-0"> <span class="animate-number" data-value="13" data-animation-duration="1500">0</span></h2>
                  <p class="title blktxt">UG Programmes</p>
                </div>
                <hr class="mt-5">
                <div class="tm-sc-funfact funfact mt-30 mb-30 text-md-center text-lg-end">
                 
                  <h2 class="counter text-theme-colored3 mt-0"> <span class="animate-number" data-value="10" data-animation-duration="1500">0</span></h2>
                  <p class="title blktxt">PG Programmes</p>
                </div>
                <hr class="mt-7">
                <div class="tm-sc-funfact funfact mt-30 text-md-center text-lg-end">
                  
                  <h2 class="counter text-theme-colored3 mt-0"> <span class="animate-number" data-value="12" data-animation-duration="1500">0</span></h2>
                  <p class="title blktxt">Research Programmes </p> <p align="left" style="padding-left: 40px;"> (M.Phil - 6, Ph.D - 6)</p>
                </Div>
                <hr class="mt-5">
                <div class="tm-sc-funfact funfact mt-30 text-md-center text-lg-end">
                  
                  <h2 class="counter text-theme-colored3 mt-0"> <span class="animate-number" data-value="3584" data-animation-duration="1500">0</span></h2>
                  <p class="title blktxt">Students</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Divider -->

    <!-- Section: Divide
    <section class="bg-img-center layer-overlay" data-tm-bg-img="images/bg/bg6.jpg">
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-md-8 col-lg-8 col-xl-8">
              <div class="tm-divider-box">
                <h2 class="title font-weight-800 text-white divider-font-style">Take A Short Tour of Our Campus</h2>
              </div>
            </div>
            <div class="col-md-4 col-lg-4 col-xl-4 text-center">
              <div class="box-hover-effect tm-sc-video-popup tm-sc-video-popup-css-button mt-30">
                <div class="effect-wrapper d-flex align-items-center">
                  <div class="animated-css-play-button"><span class="play-icon"><i class="fa fa-play"></i></span></div>
                  <a class="hover-link" data-lightbox-gallery="youtube-video" href="#" title=""></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Divider

    

    <!-- Section: Testimonials 
    <section style="background-color: #ccc;">
      <div class="container pb-120">
        <div class="section-content pt-120" style="margin-top: -130px;">
          <div class="row">
            <div class="col-xl-5">
              <div class="tm-testimonials-box pr-40 pr-sm-0">
                <h2 class=" font-weight-300 tm-item-appear-clip-path"><span class="text-theme-colored1 font-weight-800">What our</span> happy student's are talking</h2>
                <p class="icon-box-paragh mb-40 blktxt">This is your adventurous pathway. Government Arts College for Women (Autonomous), Pudukkottai student's testimonial. It's much different than any college I've been to. You actually can talk to your teachers.</p>
                <div class="icon-box icon-left iconbox-theme-colored2">
                  <a class="icon icon-dark icon-circled icon-border-effect effect-circled icon-sm float-start flip mt-2" href="tel:+914322222202">
                    <i class="fas fa-phone-alt"></i>
                  </a>
                  <h5 class="icon-box-title font-weight-500 text-theme-colored2 mt-0">Have any question? Give us a</h5>
                  <p class="icon-box-paragh2 text-theme-colored3 font-weight-800 mb-0">Call: +91 4322 222202</p>
                </div>
              </div>
            </div>
            <div class="col-xl-7">
              <div class="tm-testimonials-box mt-100 mt-lg-130">
                <div class="tm-tst-wrapper first-wrapper mb-90 mb-lg-120 mb-sm-30">
                  <div class="tm-tst-thumb">
                    <img src="images/about/student1.png" alt="1.png">
                    <div class="tm_tst_icon bg-theme-colored2"><span class="fas fa-quote-left text-white"></span></div>
                  </div>
                  <div class="tm-tst-details ml-100 ml-sm-0 p-sm-30 mt-sm-20">
                    <h4 class="title">Uma</h4>
                    <p>Great experience from Government Arts College for Women, Pudukkottai. You get a lot of opportunities. Work hard to get it. </p>
                  </div>
                </div>
                <div class="tm-tst-wrapper">
                  <div class="tm-tst-thumb">
                    <img src="images/about/student2.png" alt="1.png">
                    <div class="tm_tst_icon bg-theme-colored2"><span class="fas fa-quote-left text-white"></span></div>
                  </div>
                  <div class="tm-tst-details ml-100 ml-sm-0 p-sm-30 mt-sm-20">
                    <h4 class="title">Priya</h4>
                    <p>SET faculties have put in all the efforts to groom us and make us corporate professionals. It was a wonderful experience.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Testimonials -->

  </div>
  <!-- end main-content -->

  <!-- Footer -->
  <footer id="footer" class="footer" data-tm-bg-img="images/bg/bg7.jpg">
    <div class="footer-widget-area">
      <div class="container">
        <div class="row tm-row-border-bottom">
          <div class="col-md-4 col-lg-4 col-xl-6 pl-0 pl-sm-15 text-center text-xl-start text-lg-start text-md-start">
            <div class="p-30 d-inline-block">
              
            </div>
          </div>
          <div class="col-md-8 col-lg-8 col-xl-6 pr-0 pr-sm-15">
            <div class="tm-fsiw-insolan">
             
            </div>
          </div>
        </div>
      </div>
      <div class="container pt-80 pb-30">
        <div class="row">
          <div class="col-md-6 col-lg-6 col-xl-3">
            <div class="widget tm-widget-contact-info contact-info-style1">
              <h4 class="widget-title text-white widget-title-line-bottom line-bottom-theme-colored1">Address</h4>
              <div class="description mb-20">The Principal,<br>
Kalaignar Karunanidhi Government Arts College for Women (Autonomous) Pudukkottai.<br>
Sathyamoorthy Road,<br>
Pudukkottai- 622 001.<br>
Tamil Nadu, India.<br>
<br>
</div>
            </div>
          </div>
          <div class="col-md-6 col-lg-6 col-xl-3">
            <div class="split-nav-menu clearfix widget widget_nav_menu">
              <h4 class="widget-title widget-title-line-bottom line-bottom-theme-colored1">Useful Links</h4>
              <div class="menu-footer-page-list">
                <ul id="footer-page-list" class="menu">
                  <li><a href="https://www.tndce.tn.gov.in/" target="_blank">DCE</a></li>
                  <li><a href="https://dst.gov.in/" target="_blank">DST</a></li>
                  <li><a href="http://www.naac.gov.in/" target="_blank">NAAC</a></li>
                  <li><a href="https://www.nirfindia.org/Home" target="_blank">NIRF</a></li>
                  <li><a href="https://swayam.gov.in/" target="_blank">SWAYAM</a></li>
                  <li><a href="https://www.ugc.ac.in/" target="_blank">UGC</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-6 col-xl-3">
            <div class="widget widget_nav_menu">
              <h4 class="widget-title widget-title-line-bottom line-bottom-theme-colored1">Quick Contact</h4>
              <ul class="list list-border">
                <li><a href="#">+91 4322 222202</a></li>
                <li><a href="#">gacwpdkt@yahoo.co.in</a></li>
              </ul>
            </div>
          </div>
          
        </div>
      </div>
      <div class="footer-bottom" data-tm-bg-color="#4e3299">
        <div class="container">
          <div class="row pt-20 pb-20">
            <div class="col-sm-12">
              <div class="footer-paragraph text-center">
                © Copyright 2021. Kalaignar Karunanidhi Government Arts College for Women (Autonomous) Pudukkottai. <a target="_blank" href="http://infotrackin.com/"  style="font-weight: 600;">Powered By Infotrack Technologies</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->
  <!-- Footer Scripts -->


  <!-- JS | Custom script for all pages -->
  <script src="js/custom.js"></script>
</body>

</html>