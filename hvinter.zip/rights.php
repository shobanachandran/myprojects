<?php 
    error_reporting(0);
	include("includes/config.php");
	extract($_REQUEST);
	$action = 'useradd';
	$breadcrumb = 'Add';
	$sucessMsg = 'User Rights Added Successfully';

	/*echo "<pre>";
	print_r($_POST);
	echo "</pre>";*/

	if($_POST['action']=='useradd'){

	    $sel_main   = mysqli_query($zconn,"select * from main_menu where status='0' order by menu_order");
	    $del_rights = mysqli_query($zconn,"delete from menu_rights where user_type_id='".$_POST['typeid']."'");

	    while($res_main = mysqli_fetch_array($sel_main,MYSQLI_ASSOC)){
	        $menu_id = $res_main['id'];

			$rights_add = mysqli_query($zconn,"insert into menu_rights(user_type_id,main_menu,sub_menu,add_option,edit_option,del_option,view_option,print_option) values('".$_POST['typeid']."','".$_POST['menu_'.$menu_id]."','','".$_POST['add_'.$menu_id]."','".$_POST['edit_'.$menu_id]."','".$_POST['del_'.$menu_id]."','".$_POST['view_'.$menu_id]."','".$_POST['print_'.$menu_id]."')");

			$sel_sub = mysqli_query($zconn,"select * from sub_menu1 where main_id='".$menu_id."' order by menu_order");
			while($res_sub = mysqli_fetch_array($sel_sub,MYSQLI_ASSOC)){
				$sub_id = $res_sub['sub_id'];
				$rights_add = mysqli_query($zconn,"insert into menu_rights(user_type_id,main_menu,sub_menu,add_option,edit_option,del_option,view_option,print_option) values('".$_POST['typeid']."','".$_POST['menu_'.$menu_id]."','".$_POST['submenu_'.$sub_id]."','".$_POST['addsub_'.$sub_id]."','".$_POST['editsub_'.$sub_id]."','".$_POST['delsub_'.$sub_id]."','".$_POST['viewsub_'.$sub_id]."','".$_POST['printsub_'.$sub_id]."')");
			}
	    }
	}

	if(isset($userid)){
		$sucessMsg = 'User Updated Successfully';
		$action = 'useredit';
		$breadcrumb = 'Edit';
		$edtUsrQry = "SELECT * FROM users WHERE USERID='".$userid."'";
		$edtUsrResource = mysqli_query($zconn,$edtUsrQry);
		$userData = mysqli_fetch_array($edtUsrResource,MYSQLI_ASSOC);
		$userid   = $userData['USERID'];
		$uname 	  = $userData['UNAME'];
		$usrname  = $userData['USRNAME'];
		$usrpwd   = $userData['USRPWD'];
		$email    = $userData['EMAIL'];
		$mobno    = $userData['MOBNO'];
		$typeid   = $userData['TYPEID'];
		$status   = $userData['STATUS'];
		$addrs    = $userData['ADDRS'];
		$dojoin   = $userData['DOJOIN'];
		$dobirth  = $userData['DOBIRTH'];
	}

	?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - User</title>
    <!-- Custom CSS -->
	<!--  datatables CSS -->
    <link href="dist/css/bootstrap.css" rel="stylesheet">    
    <link href="dist/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet"> 

</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
		<?php  include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
		<?php  include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
             <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Users List</h4> &nbsp;&nbsp;&nbsp;&nbsp;
						<a href="admin_master.php"> <button type="button" class="btn btn-info">Admin Master</button></a>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">							
                                <ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="users_add.php"><button type="button" class="btn btn-success">Add</button></a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Sales chart -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
							<!-- accoridan part -->
                        <form name="userInfo" id="userInfo" method="post" enctype="multipart/form-data" action="">
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">User Rights</h3>
          <div class="box-tools pull-right">
          </div>
        </div>
        <div class="box-body">
		<div class="row">
			<div class="col-md-4">
			  <div class="form-group">
					<label>User Type<span class="red">*</span></label>
					<select class="form-control select2"  tabindex="6"  name="typeid" id="typeid" style="width: 100%;" onchange="sel_usertype(this.value);">
					 <option value="">Select</option>
					 <?php
						$typQuery = "SELECT typeid,typname FROM users_type WHERE deleted='N' ORDER BY typeid";
						$typResource = mysqli_query($zconn,$typQuery);
						while($typdata = mysqli_fetch_array($typResource,MYSQLI_ASSOC)){
					 ?>
						<option value="<?php echo $typdata['typeid']; ?>" <?php if($_GET['id']==$typdata['typeid']){ ?> selected<?php } ?>><?php echo $typdata['typname']; ?></option>
					  <?php } ?>
					</select>
				  </div>
			</div>
		</div>
		<?php if($_GET['id']!=''){
		  $usert_type = $_GET['id'];
		?>
		<div class="row">
        <table class="table">
            <tr>
                <th>Menu Name</th>
                <th><input type="checkbox" name="addAll"   id="addAll">Add</th>
                <th><input type="checkbox" name="editAll"  id="editAll">Edit</th>
                <th><input type="checkbox" name="delAll"   id="delAll">Delete</th>
                <th><input type="checkbox" name="viewAll"  id="viewAll">View</th>
				<th><input type="checkbox" name="printAll" id="printAll">Print</th>
            </tr>
        <?php   $menu_sql = mysqli_query($zconn,"select * from main_menu where status='0'");
               while($res_menu = mysqli_fetch_array($menu_sql,MYSQLI_ASSOC)){

					$add_select = '';
					$edit_select = '';
					$del_select = '';
					$view_select = '';
					$print_select = '';
					$add_sub_select = '';
					$edit_sub_select = '';
					$del_sub_select = '';
					$view_sub_select = '';
					$print_sub_select = '';

                    $sel_rights = mysqli_fetch_array(mysqli_query($zconn,"select * from menu_rights where user_type_id='".$usert_type."' and main_menu='".$res_menu['id']."' and sub_menu='0'"),MYSQLI_ASSOC);
                    if($sel_rights['add_option']=='1'){$add_select = 'checked';} else {$add_select = '';}
                    if($sel_rights['edit_option']=='1'){$edit_select = 'checked';} else {$edit_select = '';}
                    if($sel_rights['del_option']=='1'){$del_select = 'checked';} else {$del_select = '';}
                    if($sel_rights['view_option']=='1'){$view_select = 'checked';} else {$view_select = '';}
					if($sel_rights['print_option']=='1'){$print_select = 'checked';} else {$print_select = '';}
            ?>
            <tr>
                <th><?php echo $res_menu['menu_name'];?><input type="hidden" name="menu_<?php echo $res_menu['id'];?>" value="<?php echo $res_menu['id'];?>"></th>
                <th><input type="checkbox" <?php echo $add_select;?> value="1" class="add_rows" name="add_<?php echo $res_menu['id']; ?>" id="add_<?php echo $res_menu['id']; ?>"></th>
                <th><input type="checkbox" <?php echo $edit_select;?> value="1" class="edit_rows" name="edit_<?php echo $res_menu['id']; ?>" id="edit_<?php echo $res_menu['id']; ?>"></th>
                <th><input type="checkbox" <?php echo $del_select;?> value="1" class="del_rows" name="del_<?php echo $res_menu['id']; ?>" id="del_<?php echo $res_menu['id']; ?>"></th>
                <th><input type="checkbox" <?php echo $view_select;?> value="1" class="view_rows" name="view_<?php echo $res_menu['id']; ?>" id="view_<?php echo $res_menu['id']; ?>"></th>
                <th><input type="checkbox" <?php echo $print_select;?> value="1" class="print_rows" name="print_<?php echo $res_menu['id']; ?>" id="print_<?php echo $res_menu['id']; ?>"></th>
            </tr>
			<?php 
			$sel_sub = mysqli_query($zconn,"select * from sub_menu1 where main_id='".$res_menu['id']."'");
				while($res_sub = mysqli_fetch_array($sel_sub,MYSQLI_ASSOC)){

					$sel_sub_rights = mysqli_fetch_array(mysqli_query($zconn,"select * from menu_rights where user_type_id='".$usert_type."' and main_menu='".$res_menu['id']."' and sub_menu='".$res_sub['sub_id']."'"),MYSQLI_ASSOC);
                    if($sel_sub_rights['add_option']=='1'){$add_sub_select = 'checked';} else {$add_sub_select = '';}
                    if($sel_sub_rights['edit_option']=='1'){$edit_sub_select = 'checked';} else {$edit_sub_select = '';}
                    if($sel_sub_rights['del_option']=='1'){$del_sub_select = 'checked';} else {$del_sub_select = '';}
                    if($sel_sub_rights['view_option']=='1'){$view_sub_select = 'checked';} else {$view_sub_select = '';}
					if($sel_sub_rights['print_option']=='1'){$print_sub_select = 'checked';} else {$print_sub_select = '';}
			?>
			<tr>
				<td align="right"><?php echo $res_sub['sub_menu'];?><input type="hidden" name="submenu_<?php echo $res_sub['sub_id'];?>" value="<?php echo $res_sub['sub_id'];?>"></td>
                <td><input type="checkbox" <?php echo $add_sub_select;?> value="1" class="add_rows" name="addsub_<?php echo $res_sub['sub_id']; ?>" id="add_<?php echo $res_sub['sub_id']; ?>"></td>
                <td><input type="checkbox" <?php echo $edit_sub_select;?> value="1" class="edit_rows" name="editsub_<?php echo $res_sub['sub_id']; ?>" id="edit_<?php echo $res_sub['sub_id']; ?>"></td>
                <td><input type="checkbox" <?php echo $del_sub_select;?> value="1" class="del_rows" name="delsub_<?php echo $res_sub['sub_id']; ?>" id="del_<?php echo $res_sub['sub_id']; ?>"></td>
                <td><input type="checkbox" <?php echo $view_sub_select;?> value="1" class="view_rows" name="viewsub_<?php echo $res_sub['sub_id']; ?>" id="view_<?php echo $res_sub['sub_id']; ?>"></td>
                <td><input type="checkbox" <?php echo $print_sub_select;?> value="1" class="print_rows" name="printsub_<?php echo $res_sub['sub_id']; ?>" id="printsub_<?php echo $res_sub['sub_id']; ?>"></td>
			</tr>
				<?php } ?>
            <?php } ?>
        </table>
        </div>
        </div>
      </div>
        <?php } ?>
	   <div class="row">
			<div class="col-md-12">
				<div class="btn-group-vertical">
				  <button type="submit" tabindex="12" class="btn btn-success">Save</button>
				</div>
				<div class="btn-group-vertical">
				  <button type="reset" tabindex="13" class="btn btn-danger">Reset</button>
				</div>
			</div>
        </div>
      </div>
	  <input type="hidden" name="action" id="action" value="<?php echo $action ?>" />
	  <?php if(isset($userid)){ ?>
		<input type="hidden" name="userid" id="userid" value="<?php echo $userid ?>" />
	  <?php  } ?>
	  </form>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
                <!-- Sales chart -->
                <!-- ============================================================== -->     </div>
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <?php  include('includes/footer.php');?>
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- End Wrapper -->
    <!-- ============================================================== -->
   <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
	<!--datatables JavaScript -->
    <script src="dist/js/jquery.dataTables.min.js"></script>
    <script src="dist/js/dataTables.bootstrap4.min.js"></script>
 <script>
    function sel_usertype(user_type_id){
        window.location.href='rights.php?id='+user_type_id;
    }

    $("#addAll").click(function(){
         $('.add_rows').not(this).prop('checked', this.checked);
    });

    $("#editAll").click(function(){
         $('.edit_rows').not(this).prop('checked', this.checked);
    });

     $("#delAll").click(function(){
         $('.del_rows').not(this).prop('checked', this.checked);
    });

     $("#viewAll").click(function(){
         $('.view_rows').not(this).prop('checked', this.checked);
    });
    $("#printAll").click(function(){
         $('.print_rows').not(this).prop('checked', this.checked);
    });

</script>

</body>
</html>