<?php
	include('includes/config.php');
	if($_SESSION['userid']==''){
		echo "<script>window.location.href='login.php';</script>";
	}
/*echo "<pre>";
print_r($_POST);
echo "</pre>";*/
	if(isset($_REQUEST['save'])) {
		$select = mysqli_fetch_array(mysqli_query($zconn,"select max(dc_no) as id from store_dcout_master"));
		$id = $select['id']+1;

		// $count = count($_REQUEST['delivery_wgt']);
		$sql = mysqli_query($zconn,"INSERT INTO store_dcout_master(order_no,style_no,to_process,dc_no,date,total,from_addr)values('".$_REQUEST['order']."',
		'".$_REQUEST['style']."','".$_REQUEST['to_process']."','".$id."','".$_REQUEST['dc_date']."','".$_REQUEST['total']."','".$_REQUEST['from']."')");

		$chk_flow1 = mysqli_fetch_array(mysqli_query($zconn,"select max(process_no) as MAX_PROCESS from accessories_dc_out where order_no='".$_REQUEST['order']."' and style_no='".$_REQUEST['style']."'"),MYSQLI_ASSOC);
		$mx_pr_no = $chk_flow1['MAX_PROCESS']+1;
		$sel_dc = mysqli_fetch_array(mysqli_query($zconn,"select max(dc_no) as DCNO from accessories_dc_out where order_no='".$_REQUEST['order']."' and style_no='".$_REQUEST['style']."' and fabric_name='".$coldata['fabric_name']."' and from_addr='".$_REQUEST['from']."' and to_process='".$_REQUEST['to_process']."' "),MYSQLI_ASSOC);


	// for($i=0; $i<$count; $i++) {
	//	if ($_REQUEST['delivery_wgt'][$i]>0) {
		// $delivery=$_REQUEST['delivery_wgt'][$i];
		//$balance_wgt = $_REQUEST['wgt'][$i]-$_REQUEST['delivery_wgt'][$i];
		// $dweigt =0;
		// $chk_wgts = mysqli_fetch_array(mysqli_query($zconn,"select * from accessories_dc_out where 
		// order_no='".$_REQUEST['order']."' and style_no='".$_REQUEST['style']."' and fabric_name='".$_REQUEST['fabric_name'][$i]."' and 
		// dc_no='".$sel_dc['DCNO']."' "),MYSQLI_ASSOC);
		// $dweigt = $chk_wgts['delivered_wgt']+$_REQUEST['delivery_wgt'][$i];

		// $sql = mysqli_query($zconn,"INSERT INTO accessories_dc_out (order_no,style_no,to_process,dc_no,dc_date,
		// fabric_name,content,color,dia,fdia,gsm,gauge,loop_length,lab_no,planning_wgt,inward_wgt,delivered_wgt,balance_wgt,wgt,process_no,from_addr,inward_id) 
		// values('".$_REQUEST['order']."','".$_REQUEST['style']."','".$_REQUEST['to_process']."','".$id."','".$_REQUEST['dc_date']."',
		// '".$_REQUEST['fabric_name'][$i]."','".$_REQUEST['content'][$i]."','".$_REQUEST['color'][$i]."','".$_REQUEST['dia'][$i]."','".$_REQUEST['fdia'][$i]."','".$_REQUEST['gsm'][$i]."','".$_REQUEST['gauge'][$i]."','".$_REQUEST['loop_length'][$i]."','".$_REQUEST['lab_no'][$i]."','".$_REQUEST['wgt'][$i]."','".$_REQUEST['inward_wgt'][$i]."','".$dweigt."','".$_REQUEST['balance_wgt'][$i]."',
		// '".$_REQUEST['wgt'][$i]."','".$mx_pr_no."','".$_REQUEST['from']."','".$_REQUEST['id'][$i]."')");

	
	
	//}
	// }

	// if($sql1) {
	// 	echo '<script>alert("The Record has been Successfully Added...")</script>';
	// } 
	// else {
	// 	echo '<script>alert("The Record Not Added Please Fill all The correct Detail...");</script>';
	// }


	$count = count($_REQUEST['wgt']);

for($i=0;$i<$count;$i++)
	{ 
	if ($_REQUEST['wgt'][$i]>0) {
			$wgt=$_REQUEST['wgt'][$i];
			$fabrics0=mysqli_fetch_object(mysqli_query($zconn,"select 
            sum(weight) 
            as weight from  store_po_details where
             `po_id`='".$_REQUEST['po_no']."' 
            and id='".$_REQUEST['id'][$i]."' 
            and order_no= '".$_REQUEST['order_no'][$i]."'"));
			 $fwgt=$fabrics0->weight;
			$fabrics=mysqli_fetch_object(mysqli_query($zconn,"select 
            sum(wgt) 
            as wgt from  store_d_out where `po_no`='".$_REQUEST['po_no']."' 
            and old_id='".$_REQUEST['id'][$i]."' and 
            order_no= '".$_REQUEST['order_no'][$i]."'"));
			$new=$_REQUEST['wgt'][$i];
			$fwgt2=$fabrics->wgt+$new;
			$tcom=$fwgt-$fwgt2;

			$sql = mysqli_query($zconn,"INSERT INTO `store_d_out` ( `po_no`,`style_no`,`order_no`,`wgt`, `roll`,`date`,old_id,fabric_name) VALUES ('".$_REQUEST['po_no']."','".$_REQUEST['style_no'][$i]."','".$_REQUEST['order_no'][$i]."','".$_REQUEST['wgt'][$i]."','".$_REQUEST['roll'][$i]."',Now(),'".$_REQUEST['id'][$i]."','".$_REQUEST['fabric_name'][$i]."')")or die(mysqli_error());
		}
	}
	
}

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - ACCESSORIES PO INWARD</title>
    <!-- Custom CSS -->
    <!--  datatables CSS -->
    <link href="dist/css/bootstrap.css" rel="stylesheet">
    <link href="dist/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
    <link href="dist/css/bootstrap-datepicker.css" rel="stylesheet">

    <link href="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.min.css" rel="stylesheet" />
    <script src="dist/js/jquery.min.js"></script>
    <script src="dist/js/chosen.jquery.min.js"></script>
    <style>
    th {
        font-size: 12px;
        font-weight: bold;
        background-color: #626F80;
        color: #fff;
        text-align: center;
    }
    </style>
</head>

<body>
    <div id="main-wrapper">
        <!-- Topbar header - style you can find in pages.scss -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <!-- Bread crumb and right sidebar toggle -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Store DC</h4>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <form name="accessories_inward" id="accessories_inward" method="post">
                    <!-- Sales chart -->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="card" style="width:50%; float:left; left: 50px; ">


                                        <div class="form-group row">
                                            <label for="fname"
                                                class="col-sm-3 text-right control-label col-form-label">&nbsp;Po
                                                No</label>
                                            <div class="col-sm-6">
                                                <select class="select2 form-control custom-select chosen-select"
                                                    name="po_no" id="po_no"
                                                    onchange="$('#accessories_inward').submit();">
                                                    <option>Select</option>
                                                    <?php $sel_po = mysqli_query($zconn,"select distinct po_id,styleno  from  store_po_details where status!='complete'");
									while($res_po = mysqli_fetch_array($sel_po,MYSQLI_ASSOC)){ 
										if($_REQUEST['po_no']==$res_po['po_id']){ ?>
                                                    <option selected value="<?php echo $res_po['po_id'];?>">
                                                        <?php echo $res_po['po_id'];?></option>
                                                    <?php } else { ?>
                                                    <option value="<?php echo $res_po['po_id'];?>">
                                                        <?php echo $res_po['po_id'];?> -
                                                        (<?php echo $res_po['styleno'];?>)</option>
                                                    <?php } ?>
                                                    <?php } ?>
                                                </select>
                                                <script type="text/javascript">
                                                $(".chosen-select").chosen({
                                                    no_results_text: "Oops, nothing found!"
                                                })
                                                </script>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="form-group row">

                                            <label for="fname"
                                                class="col-sm-3 text-right control-label col-form-label">&nbsp;Indent
                                                No</label>

                                            <div class="col-sm-6">
                                                <select class="select2 form-control custom-select" name="order"
                                                    id="order" >
                                                    <option value="0">Select</option>
                                                    <?php $sel_buyer = mysqli_query($zconn,"select * from store_po_details where po_id='".$_REQUEST['po_no']."' group by order_no");
								while($res_buyer = mysqli_fetch_array($sel_buyer,MYSQLI_ASSOC)){ ?>
                                                    <option value="<?php echo $res_buyer['order_no'];?>"
                                                        <?php if ($res_buyer['order_no']==$_REQUEST['order']) {?>
                                                        selected="selected" <?php
								} ?>><?php echo $res_buyer['order_no'];?></option>
                                                    <?php } ?>
                                                </select>
                                                <!-- <?php
				$sel_buyer = mysqli_fetch_object(mysqli_query($zconn,"select * from store_po_master where po_no='".$_REQUEST['po_no']."'"));
				$buyer=$sel_buyer->buyer;
				$date=$sel_buyer->date;
			     ?>
				<input type="text" name="party" readonly class="form-control" value="<?php echo $buyer;?>"> -->
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="fname"
                                                class="col-sm-3 text-right control-label col-form-label">&nbsp;Style
                                                Code</label>
                                            <div class="col-sm-6">
                                                <select class="select2 form-control custom-select" name="style"
                                                    id="style" >
                                                    <option value="0">Select</option>
                                                    <?php $sel_buyer = mysqli_query($zconn,"select * from store_po_details where po_id='".$_REQUEST['po_no']."' and order_no='".$_REQUEST['order']."' group by order_no,styleno");
								while($res_buyer = mysqli_fetch_array($sel_buyer,MYSQLI_ASSOC)){ ?>
                                                    <option value="<?php echo $res_buyer['styleno'];?>"
                                                        <?php if ($res_buyer['styleno']==$_REQUEST['style']) {?>
                                                        selected="selected" <?php

								} ?>><?php echo $res_buyer['styleno'];?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-6">

                                            </div>
                                        </div>
                                    </div>

                                    <div class="card" style="width:50%; float:left; right: 50px;">
                                        <div class="form-group row">
                                            <label for="fname"
                                                class="col-sm-3 text-right control-label col-form-label">&nbsp;Dc
                                                No</label>
                                            <div class="col-sm-6">
                                                <?php $select = mysqli_fetch_array(mysqli_query($zconn,"select max(dc_no) as id from store_dcout_master")); 

											$id=$select['id']+1;?>
                                                <input type="text" name="dc_no" class="form-control"
                                                    value="<?php echo $id;?>">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="cono1"
                                                class="col-sm-3 text-right control-label col-form-label">DC Out
                                                Date</label>
                                            <div class="col-sm-6">
                                                <input type="date" class="form-control" id="dc_date" name="dc_date"
                                                    autocomplete="off" required>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <div class="col-sm-6">

                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="cono1"
                                                class="col-sm-3 text-right control-label col-form-label">To </label>
                                            <div class="col-sm-6">
                                                <select name="to_process" id="to_comp" class="form-control">
                                                    <option>--Select--</option>
                                                    <?php 
						$sel_comp = mysqli_query($zconn,"select * from department_master"); 
						while($res_comp = mysqli_fetch_array($sel_comp)){  ?>
                                                    <option value="<?php echo $res_comp['dept_name'];?>">
                                                        <?php echo $res_comp['dept_name'];?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <div class="col-12 d-flex no-block align-items-center">
                                            <h5 class="page-title" style="margin-left: 390px;">STORE DETAILS</h5>
                                        </div>

                                        <br>
                                        <table id="example" class="table table-striped table-bordered"
                                            style="width:100%">
                                            <thead style="background-color: #626F80; color: #fff; font-size: 16px;">
                                                <tr>
                                                    <th style="width: 10%">S.NO</th>

                                                    <th style="width: 10%">Style code</th>
                                                    <th style="width: 10%">Indent No</th>

                                                    <th style="width: 3%" data-toggle="tooltip" title="Fabric Dia">NAME
                                                    </th>
                                                    <!-- <th style="width: 3%">DIA</th> -->
                                                    <th style="width: 5%" data-toggle="tooltip" title="PLANNING Weight">
                                                        TOTAL QTY</th>
                                                    <th style="width: 5%" data-toggle="tooltip" title="PLANNING Weight">
                                                        RECEIVED</th>
                                                    <th style="width: 5%" data-toggle="tooltip" title="PLANNING Weight">
                                                        BALANCE </th>
                                                    <th style="width: 10%">NOW WANTED</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
						$query = "SELECT * FROM accessories_inward WHERE (po_no, order_no, style_no, fabric_name)  IN 
						(SELECT po_no, order_no, style_no, fabric_name FROM accessories_inward WHERE po_no = '".$_REQUEST['po_no']."' ) group by fabric_name";

						if (isset($_REQUEST['order']) && $_REQUEST['order']!='0') {
							$query.="and order_no in('".$_REQUEST['order']."')";
						}

						if (isset($_REQUEST['style'])&& $_REQUEST['style']!='0') {
							$query.="and styleno in('".$_REQUEST['style']."')";
						}

						// echo $query;
						$secBrnResource = mysqli_query($zconn,$query);
						$sno=1;
						while($coldata = mysqli_fetch_array($secBrnResource,MYSQLI_ASSOC)){
							$id=$coldata['id'];
							$fetch=mysqli_fetch_object(mysqli_query($zconn,"select sum(wgt) as wgt,sum(roll) as roll from  accessories_inward where po_no='".$_REQUEST['po_no']."' and old_id=$id"));
							$fetch1=mysqli_fetch_object(mysqli_query($zconn,"select sum(wgt) as wgt,sum(roll) as roll from  store_d_out where po_no='".$_REQUEST['po_no']."' and old_id=$id"));

							// $fetch1=mysqli_fetch_object(mysqli_query($zconn,"select * from  store_po_details
							// where  po_id='".$_REQUEST['po_no']."'  "));
							// var_dump($fetch1);
// Assuming $zconn is your database connection
$orderId = $_REQUEST['order']; // Ensure to sanitize and validate user input

// Sanitize the input (example for mysqli)
$po_no = mysqli_real_escape_string($zconn, $_REQUEST['po_no']);

// Perform the query
$query = "SELECT * FROM `store_po_details` WHERE po_id='$po_no' and order_no='$orderId'";
$result = mysqli_query($zconn, $query);

while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
    $yarn_name = $row['yarn_name'];
	echo $yarn_name . '<br>'; 
}
?>
	
                                                <tr>
                                                    <td style="width:2%"><?php echo $sno;?><input type="hidden"
                                                            name="id[]" value="<?php echo $coldata['id'];?>"></td>
                                                    <td style="width:10%"><?php echo $coldata['order_no'];?><input
                                                            type="hidden" name="order_no[]"
                                                            value="<?php echo $coldata['order_no'];?>"></td>
                                                    <td style="width:10%"><?php echo $coldata['style_no'];?><input
                                                            type="hidden" name="style_no[]"
                                                            value="<?php echo $coldata['style_no'];?>"></td>
                                                    <td style="width:7%"><?php echo $coldata['fabric_name'];?><input
                                                            type="hidden" name="fabric_name[]"
                                                            value="<?php echo $coldata['fabric_name'];?>"></td>
                                                    <td style="width:7%"><?php echo $fetch->wgt;?></td>
                                                    <td style="width:7%"><?php echo $fetch1->wgt;?></td>
                                                    <td style="width:3%">
                                                        <?php echo $fetch->wgt-$fetch1->wgt;?></td>
                                                    <!-- <td style="width:6%"><div class="col-sm-12">
		<input type="text" class="rolls form-control" id="roll<?php echo $sno;?>" name="roll" autocomplete="off" onkeyup="cal_bags();">
		</div>
	</td> -->
                                                    <td style="width: 8%">
                                                        <div class="col-sm-12">
                                                            <input type="number" class="wgt form-control" id="wgt"
                                                                name="wgt[]" autocomplete="off" onkeyup="cal_wgt();">
                                                        </div>
                                                    </td>
                                                </tr>

                                                <?php
		$sno++;}
	?>

                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <td style="width:2%"></td>
                                                    <td style="width:10%"></td>
                                                    <td style="width:10%"></td>
                                                    <td style="width:7%"></td>
                                                    <td style="width:7%"></td>
                                                    <td style="width:7%"></td>
                                                    <td style="width:3%"><b>Total</b></td>
                                                    <!-- <td style="width:6%"><div class="col-sm-12">
			<input type="text" class="form-control" name="tot_bags" id="tot_bags" autocomplete="off" required value="0">
			</div>
		</td> -->
                                                    <td style="width: 8%">
                                                        <div class="col-sm-12">
                                                            <input type="text" class="form-control" id="tot_weight"
                                                                name="total" autocomplete="off" required value="0">
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card" style="width:100%">
                        <div class="border-top">
                            <div class="card-body" style="margin-left: 400px;">
                                <button type="submit" name="save" class="btn btn-success">Save</button>
                                <button type="reset" class="btn btn-primary">Reset</button>
                            </div>
                        </div>
                    </div>
                    <!-- Sales chart -->
            </div>
            </form>
            <!-- End Container fluid  -->
            <!-- footer -->
            <?php include('includes/footer.php');?>
            <!-- End footer -->
        </div>
        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->
    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="dist/js/bootstrap-datepicker.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
    <!--datatables JavaScript -->
    <script src="dist/js/jquery.dataTables.min.js"></script>
    <script src="dist/js/dataTables.bootstrap4.min.js"></script>
    <script>
    function cal_bags() {
        var sum = 0;
        $('.rolls').each(function(index, element) {
            if ($(element).val() != "")
                sum += parseFloat($(element).val());
        });
        $('#tot_bags').val(sum);
    }

    function cal_wgt() {
        var sum = 0;
        $('.wgt').each(function(index, element) {
            if ($(element).val() != "")
                sum += parseFloat($(element).val());
        });
        $('#tot_weight').val(sum);
    }

    $(document).ready(function() {
        $('#example').DataTable();
    });

    function DeleteUsrId(ID) {
        var UsrStatus = confirm("Are you sure to delete this company details ?");
        if (UsrStatus) {
            $('#delete_' + ID).hide();
        }
    }

    $('#bill_date').datepicker({
        format: 'dd-mm-yyyy',
        autoclose: true
    })
    </script>

    <script>
    function cal_tweight1(rw) {
        //delwgt_
        //planwgt_
        //balwgt_
        var pw = $('#planwgt_' + rw).val();
        var nw = $('#delwgt_' + rw).val();
        var dl = $('#del_wgt' + rw).val();
        var bw = $('#balwgt1_' + rw).val();
        if (bw == '0' || bw == '') {
            bw = parseFloat(pw) - parseFloat(nw);
        } else {
            bw = parseFloat(bw) - parseFloat(nw);
        }
        $('#balwgt_' + rw).val(bw);

        var sum = 0;
        $('.tweight').each(function() {
            sum += Number($(this).val());
        });
        $('#total_weight1').val(sum);
    }

    $('.delivery_wgt').keyup(function() {
        var sum = 0;
        $('.delivery_wgt').each(function() {
            sum += Number($(this).val());
        });
        $('#total').val(sum);
    });

    $(document).ready(function() {
        $('#example').DataTable();
    });

    function DeleteUsrId(ID) {
        var UsrStatus = confirm("Are you sure to delete this company details ?");
        if (UsrStatus) {
            $('#delete_' + ID).hide();
        }
    }
    </script>

</body>

</html>