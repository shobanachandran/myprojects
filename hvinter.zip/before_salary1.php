<?php
include('includes/config.php');

if($_SESSION['userid']==''){
	echo "<script>window.location.href='login.php';</script>";
}

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - Labour Report</title>
    <!-- Custom CSS -->
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
</head>
<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
       <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
       <?php include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <div class="page-wrapper" style="min-height: 100%; height: auto;">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Labour Report</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="#">Labour Report</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
		
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
		<div class="container-fluid">
			<div class="row">
                <div class="col-md-12">
                        <div class="card">
							<div class="col-md-12">
							<div class="card-body">
							<div class="card-body" style="width:100%">
			<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
	<tr>
    	<td height="52" align="center" valign="middle">
        <form id="non-printable" name="form1" method="post" action="">
        	<div>Filter Department&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        	  <select name="dept" onchange="this.form.submit()" >
              					  <option value="All" selected="selected">All</option>
                                  <option value="Cutting" <?php if($dept=='Cutting'){?> selected="selected"<?php }?>>Cutting</option>
                                  <option value="Power" <?php if($dept=='Power'){?> selected="selected"<?php }?>>Power Table</option>
                                  <option value="Singer" <?php if($dept=='Singer'){?> selected="selected"<?php }?>>Singer </option>
                                  <option value="Ironing" <?php if($dept=='Ironing'){?> selected="selected"<?php }else{}?>>Ironing & packing</option>
                                  <option value="Checking" <?php if($dept=='Checking'){?> selected="selected"<?php }?>>Checking</option>
                                  <option value="Printing" <?php if($dept=='Printing'){?> selected="selected"<?php }?>>Printing</option>
                                  <option value="Embroidery" <?php if($dept=='Embroidery'){?> selected="selected"<?php }?>>Embroidery</option>
                                  <option value="Sticker" <?php if($dept=='Sticker'){?> selected="selected"<?php }?>>Sticker</option>
                                  <option value="Fusing" <?php if($dept=='Fusing'){?> selected="selected"<?php }?>>Fusing</option>
                                  <option value="Stone" <?php if($dept=='Stone'){?> selected="selected"<?php }?>>Stone</option>
                                  <option value="Sequence" <?php if($dept=='Sequence'){?> selected="selected"<?php }?>>Sequence</option>
                                  <option value="Kaja_button"<?php if($dept=='Kaja_button'){?> selected="selected"<?php }?>>Kaja Button</option>
                                  <option value="rope"<?php if($dept=='rope'){?> selected="selected"<?php }?>>Rope</option>
                                  <option value="dye_and_dye"<?php if($dept=='dye_and_dye'){?> selected="selected"<?php }?>>Dye and Dye</option>
                                  <option value="shaping"<?php if($dept=='shaping'){?> selected="selected"<?php }?>>Shaping</option>
                                  <option value="cutting_sticker"<?php if($dept=='cutting_sticker'){?> selected="selected"<?php }?>>Cutting Sticker</option>
                                  <option value="embroidery_applique"<?php if($dept=='embroidery_applique'){?> selected="selected"<?php }?>>Embroidery Applique</option>
                                  <option value="sublimation_printing"<?php if($dept=='sublimation_printing'){?> selected="selected"<?php }?>>Sublimation Printing</option>
                                  <option value="bow"<?php if($dept=='bow'){?> selected="selected"<?php }?>>Bow</option>
                                  <option value="others"<?php if($dept=='others'){?> selected="selected"<?php }?>>Others</option>
                                  <option value="final_checking"<?php if($dept=='final_checking'){?> selected="selected"<?php }?>>Final Checking</option>
								   <option value="panel_checking"<?php if($dept=='panel_checking'){?> selected="selected"<?php }?>>Panel Checking</option>
								   
								   <option value="washing"<?php if($dept=='washing'){?> selected="selected"<?php }?>>Washing</option>
                </select>
        	</div>
        </form>    	</td>
     </tr>
     <tr>
    <td align="center" valign="middle"><table width="100%" border="1" cellspacing="0" cellpadding="0">
   <!-- <!--?php $total_cutting=''; $advance_cutting=''; $tota='';$conta='';
        $select=mysqli_query("SELECT * FROM `cutting_workdone` WHERE `status`='unpaid'");
		if(mysqli_num_rows($select)!==0)
		{
		?> -->
      <tr>
       <td width="75%"  align="center" valign="middle"><!--?php if($dept=='All' or $dept=='Cutting'){?>--><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Cutting</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
         <!--?php {
		  $person_detaklss=mysqli_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'Cutting'");
		while($person_detaklss_row=mysqli_fetch_object($person_detaklss)){
			$sqll=mysqli_query("SELECT DISTINCT(id)FROM  `cutting_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysqli_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysqli_query("SELECT DISTINCT(styleno),(color_name) FROM  `cutting_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysqli_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysqli_query("select SUM(total)as total from `cutting_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color' and `status`='unpaid' and `total` != '0'");
					while($sqlaa=mysqli_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>-->
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><?php $nam=mysqli_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysqli_fetch_object($nam)){$n=$name->name;} ?>
                         <?php echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><?php $sqaa=mysqli_query("select * from `cutting_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysqli_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><?php $rate=mysqli_query("select cuttingrs as ra, buyername from product where `styleno`='$style'"); 
                        while($rates=mysqli_fetch_array($rate))
                        {
                             $r=$rates['ra']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><?php $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						
	          	 <!--?php
				$advance1=mysqli_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysqli_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysqli_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>-->
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                 <?php
                $dummy_cont_mysql_num=mysqli_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysqli_num_rows($dummy_cont_mysql_num) == '0'){
				  ?>
                  <a href='contractorsalary_accounts.php?dept=cutting&contid=<?php echo $id;?>&go='>Send To Approval</a>
                <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?php echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?php=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?php=$totaladvacen;$cutting_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<!--?php	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table></td>
	  </tr>
       ?php
		}
        $select=mysqli_query("SELECT * FROM `power_workdone` WHERE  `status`='unpaid'");
		if(mysqli_num_rows($select)!=0)
		{
		?> -->
        <!--  -->
			
			
			
			
			
			
			
            <tr>
              <td height="35" align="right">&nbsp;</td>
              <td align="center">&nbsp;</td>
              <td colspan="2" align="left" valign="middle"><h2>Grand Total</h2></td>
              <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle"><?php=$final_grand;?></td>
            </tr>
          </table></td>
        </tr>
		 <!--?php
          }
          ?>-->
    </table></td>
  </tr>
  <tr>
    <td align="right" valign="middle">&nbsp;</td>
  </tr>
</table>
</div>
</div>
</div>
 </div>
	</div>
	</div>  
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    <!-- End Wrapper -->
	<!-- ============================================================== -->
            <!-- footer -->
          <?php include('includes/footer.php');?>
            <!-- End footer -->
			</div>
	</div>
            <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
	<script>
    </script>
</body>
</html>