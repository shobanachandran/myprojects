<?php 
include('includes/config.php');
extract($_REQUEST);
if($_SESSION['userid']==''){
	echo "<script>window.location.href='login.php';</script>";
}

	$action = 'supplieradd';
	$breadcrumb = 'Add';
	$sucessMsg = 'Supplier Information Added Successfully';
	if(isset($colid)){
		$sucessMsg = 'Area Information Updated Successfully';
		$action = 'supplieredit';
		$breadcrumb = 'Edit';
		$edtColQry = "SELECT * FROM suppliers WHERE supplier_id='".$colid."'";
		$edtColResource = mysqli_query($zconn,$edtColQry);
		$colData = mysqli_fetch_array($edtColResource,MYSQLI_ASSOC);
		$colid = $colData['supplier_id'];
		$status = $colData['status'];
	}

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - Supplier Add</title>
    <!-- Custom CSS -->
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">  
<link rel="stylesheet" type="text/css" id="app-css" href="http://support.iorange.in/assets/css/style.min.css?v=2.4.0">
	
</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <div class="page-wrapper" style="min-height: 100%; height: auto;">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
             <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Supplier Add</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="supplier.php">Users Info</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Sales chart -->
			<form name="supplier_info" id="supplier_info" method="post">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
							<div class="card-body" style="width:100%">
								
								<link rel="stylesheet" type="text/css" id="app-css" href="http://support.iorange.in/assets/css/style.min.css?v=2.4.0">
<div class="content">
      <div class="row">
         <div class="col-md-12">
                                 </div>
                  <div class="btn-bottom-toolbar btn-toolbar-container-out text-right">
            <button class="btn btn-info only-save customer-form-submiter">
            Save            </button>
                     </div>
                           <div class="col-md-3">
            <div class="panel_s mbot5">
               <div class="panel-body padding-10">
                  <h4 class="bold">
                     #1812 AIM EXPORTERS                                          <div class="btn-group">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-right">
                                                      <li>
                              <a href="http://support.iorange.in/admin/clients/login_as_client/1812" target="_blank">
                              <i class="fa fa-share-square-o"></i> Login as client                              </a>
                           </li>
                                                                                 <li>
                              <a href="http://support.iorange.in/admin/clients/delete/1812" class="text-danger delete-text _delete"><i class="fa fa-remove"></i> Delete                               </a>
                           </li>
                                                   </ul>
                     </div>
                                                            </h4>
               </div>
            </div>
            <ul class="nav navbar-pills navbar-pills-flat nav-tabs nav-stacked customer-tabs" role="tablist">
      <li class="active customer_tab_profile">
      <a data-group="profile" href="http://support.iorange.in/admin/clients/client/1812?group=profile">
                    <i class="fa fa-user-circle menu-icon" aria-hidden="true"></i>
                Profile      </a>
    </li>
      <li class="customer_tab_contacts">
      <a data-group="contacts" href="http://support.iorange.in/admin/clients/client/1812?group=contacts">
                    <i class="fa fa-users menu-icon" aria-hidden="true"></i>
                Contacts      </a>
    </li>
      <li class="customer_tab_notes">
      <a data-group="notes" href="http://support.iorange.in/admin/clients/client/1812?group=notes">
                    <i class="fa fa-sticky-note-o menu-icon" aria-hidden="true"></i>
                Notes      </a>
    </li>
      <li class="customer_tab_statement">
      <a data-group="statement" href="http://support.iorange.in/admin/clients/client/1812?group=statement">
                    <i class="fa fa-area-chart menu-icon" aria-hidden="true"></i>
                Statement      </a>
    </li>
      <li class="customer_tab_invoices">
      <a data-group="invoices" href="http://support.iorange.in/admin/clients/client/1812?group=invoices">
                    <i class="fa fa-file-text menu-icon" aria-hidden="true"></i>
                Invoices      </a>
    </li>
      <li class="customer_tab_payments">
      <a data-group="payments" href="http://support.iorange.in/admin/clients/client/1812?group=payments">
                    <i class="fa fa-line-chart menu-icon" aria-hidden="true"></i>
                Payments      </a>
    </li>
      <li class="customer_tab_proposals">
      <a data-group="proposals" href="http://support.iorange.in/admin/clients/client/1812?group=proposals">
                    <i class="fa fa-file-powerpoint-o menu-icon" aria-hidden="true"></i>
                Proposals      </a>
    </li>
      <li class="customer_tab_credit_notes">
      <a data-group="credit_notes" href="http://support.iorange.in/admin/clients/client/1812?group=credit_notes">
                    <i class="fa fa-sticky-note-o menu-icon" aria-hidden="true"></i>
                Credit Notes      </a>
    </li>
      <li class="customer_tab_estimates">
      <a data-group="estimates" href="http://support.iorange.in/admin/clients/client/1812?group=estimates">
                    <i class="fa fa-clipboard menu-icon" aria-hidden="true"></i>
                Estimates      </a>
    </li>
      <li class="customer_tab_subscriptions">
      <a data-group="subscriptions" href="http://support.iorange.in/admin/clients/client/1812?group=subscriptions">
                    <i class="fa fa-repeat menu-icon" aria-hidden="true"></i>
                Subscriptions      </a>
    </li>
      <li class="customer_tab_expenses">
      <a data-group="expenses" href="http://support.iorange.in/admin/clients/client/1812?group=expenses">
                    <i class="fa fa-file-text-o menu-icon" aria-hidden="true"></i>
                Expenses      </a>
    </li>
      <li class="customer_tab_contracts">
      <a data-group="contracts" href="http://support.iorange.in/admin/clients/client/1812?group=contracts">
                    <i class="fa fa-file menu-icon" aria-hidden="true"></i>
                Contracts      </a>
    </li>
      <li class="customer_tab_projects">
      <a data-group="projects" href="http://support.iorange.in/admin/clients/client/1812?group=projects">
                    <i class="fa fa-bars menu-icon" aria-hidden="true"></i>
                Projects      </a>
    </li>
      <li class="customer_tab_tasks">
      <a data-group="tasks" href="http://support.iorange.in/admin/clients/client/1812?group=tasks">
                    <i class="fa fa-tasks menu-icon" aria-hidden="true"></i>
                Tasks      </a>
    </li>
      <li class="customer_tab_tickets">
      <a data-group="tickets" href="http://support.iorange.in/admin/clients/client/1812?group=tickets">
                    <i class="fa fa-ticket menu-icon" aria-hidden="true"></i>
                Tickets      </a>
    </li>
      <li class="customer_tab_attachments">
      <a data-group="attachments" href="http://support.iorange.in/admin/clients/client/1812?group=attachments">
                    <i class="fa fa-paperclip menu-icon" aria-hidden="true"></i>
                Files      </a>
    </li>
      <li class="customer_tab_vault">
      <a data-group="vault" href="http://support.iorange.in/admin/clients/client/1812?group=vault">
                    <i class="fa fa-lock menu-icon" aria-hidden="true"></i>
                Vault      </a>
    </li>
      <li class="customer_tab_reminders">
      <a data-group="reminders" href="http://support.iorange.in/admin/clients/client/1812?group=reminders">
                    <i class="fa fa-clock-o menu-icon" aria-hidden="true"></i>
                Reminders      </a>
    </li>
      <li class="customer_tab_map">
      <a data-group="map" href="http://support.iorange.in/admin/clients/client/1812?group=map">
                    <i class="fa fa-map-marker menu-icon" aria-hidden="true"></i>
                Map      </a>
    </li>
  </ul>
         </div>
                  <div class="col-md-9">
            <div class="panel_s">
               <div class="panel-body">
                                    
<input type="hidden" name="isedit" value="">
                  
<input type="hidden" name="userid" value="1812">
                  <div class="clearfix"></div>
                                    <div>
                     <div class="tab-content">
                           <h4 class="customer-profile-group-heading">Profile</h4>
<div class="row">
   <form action="http://support.iorange.in/admin/clients/client/1812" class="client-form" autocomplete="off" method="post" accept-charset="utf-8" novalidate="novalidate">
<input type="hidden" name="csrf_token_name" value="3931f759c5874c0be5012e05bf4ac24b">               
   <div class="additional"></div>
   <div class="col-md-12">
      <div class="horizontal-scrollable-tabs">
         <div class="scroller arrow-left" style="display: none;"><i class="fa fa-angle-left"></i></div>
         <div class="scroller arrow-right" style="display: none;"><i class="fa fa-angle-right"></i></div>
         <div class="horizontal-tabs">
            <ul class="nav nav-tabs profile-tabs row customer-profile-tabs nav-tabs-horizontal" role="tablist">
               <li role="presentation" class="active">
                  <a href="#contact_info" aria-controls="contact_info" role="tab" data-toggle="tab">
                  Customer Details                  </a>
               </li>
                              <li role="presentation">
                  <a href="#billing_and_shipping" aria-controls="billing_and_shipping" role="tab" data-toggle="tab">
                  Billing &amp; Shipping                  </a>
               </li>
                                             <li role="presentation">
                  <a href="#customer_admins" aria-controls="customer_admins" role="tab" data-toggle="tab">
                  Customer Admins                  </a>
               </li>
                                          </ul>
         </div>
      </div>
      <div class="tab-content">
                           <div role="tabpanel" class="tab-pane active" id="contact_info">
            <div class="row">
               <div class="col-md-12 mtop15  hide" id="client-show-primary-contact-wrapper">
                  <div class="checkbox checkbox-info mbot20 no-mtop">
                     <input type="checkbox" name="show_primary_contact" value="1" id="show_primary_contact">
                     <label for="show_primary_contact">Show primary contact full name on Invoices, Estimates, Payments, Credit Notes</label>
                  </div>
               </div>
               <div class="col-md-6">
                                                      <div class="form-group" app-field-wrapper="company"><label for="company" class="control-label"> <small class="req text-danger">* </small>Company</label><input type="text" id="company" name="company" class="form-control" value="AIM EXPORTERS"></div>                  <div id="company_exists_info" class="hide"></div>
                  <div class="form-group" app-field-wrapper="vat"><label for="vat" class="control-label">GSTIN</label><input type="text" id="vat" name="vat" class="form-control" value="33AKBPR4805R1ZR"></div>                                    <div class="form-group" app-field-wrapper="phonenumber"><label for="phonenumber" class="control-label">Phone</label><input type="text" id="phonenumber" name="phonenumber" class="form-control" value="7010630918"></div>                                    <div class="form-group">
                     <label for="website">Website</label>
                     <div class="input-group">
                        <input type="text" name="website" id="website" value="www.aimmexporters.com" class="form-control">
                        <div class="input-group-addon">
                           <span><a href="http://www.aimmexporters.com" target="_blank" tabindex="-1"><i class="fa fa-globe"></i></a></span>
                        </div>
                     </div>
                  </div>
                  <div class="form-group form-group-select-input-groups_in[] input-group-select"><label for="groups_in[]" class="control-label">Groups</label><div class="input-group input-group-select select-groups_in[]" app-field-wrapper="groups_in[]"><div class="dropdown bootstrap-select show-tick input-group-btn _select_input_group bs3 bs3-has-addon" style="width: 100%;"><select id="groups_in[]" name="groups_in[]" class="selectpicker _select_input_group" multiple="1" data-actions-box="1" data-width="100%" data-none-selected-text="Nothing selected" data-live-search="true" tabindex="-98"><option value="1" selected="">WEBSITE &amp; HOSTING</option></select><button type="button" class="btn dropdown-toggle btn-default" data-toggle="dropdown" role="combobox" aria-owns="bs-select-1" aria-haspopup="listbox" aria-expanded="false" data-id="groups_in[]" title="WEBSITE &amp; HOSTING"><div class="filter-option"><div class="filter-option-inner"><div class="filter-option-inner-inner">WEBSITE &amp; HOSTING</div></div> </div><span class="bs-caret"><span class="caret"></span></span><div class="filter-expand">WEBSITE &amp; HOSTING</div></button><div class="dropdown-menu open"><div class="bs-searchbox"><input type="text" class="form-control" autocomplete="off" role="combobox" aria-label="Search" aria-controls="bs-select-1" aria-autocomplete="list"></div><div class="bs-actionsbox"><div class="btn-group btn-group-sm btn-block"><button type="button" class="actions-btn bs-select-all btn btn-default">Select All</button><button type="button" class="actions-btn bs-deselect-all btn btn-default">Deselect All</button></div></div><div class="inner open" role="listbox" id="bs-select-1" tabindex="-1" aria-multiselectable="true"><ul class="dropdown-menu inner " role="presentation"></ul></div></div></div><div class="input-group-addon" style="opacity: 1;"><a href="#" data-toggle="modal" data-target="#customer_group_modal"><i class="fa fa-plus"></i></a></div></div></div>                  <div class="form-group" app-field-wrapper="default_currency"><label for="default_currency" class="control-label">Currency</label><div class="dropdown bootstrap-select bs3" style="width: 100%;"><select id="default_currency" name="default_currency" class="selectpicker" data-none-selected-text="System Default" data-width="100%" data-live-search="true" tabindex="-98"><option value=""></option><option value="2" selected="" data-subtext="₹">RS</option></select><button type="button" class="btn dropdown-toggle btn-default" data-toggle="dropdown" role="combobox" aria-owns="bs-select-2" aria-haspopup="listbox" aria-expanded="false" data-id="default_currency" title="RS ₹"><div class="filter-option"><div class="filter-option-inner"><div class="filter-option-inner-inner">RS<small class="text-muted"> ₹</small></div></div> </div><span class="bs-caret"><span class="caret"></span></span></button><div class="dropdown-menu open"><div class="bs-searchbox"><input type="text" class="form-control" autocomplete="off" role="combobox" aria-label="Search" aria-controls="bs-select-2" aria-autocomplete="list"></div><div class="inner open" role="listbox" id="bs-select-2" tabindex="-1"><ul class="dropdown-menu inner " role="presentation"></ul></div></div></div></div>                                 </div>
               <div class="col-md-6">
                                    <div class="form-group" app-field-wrapper="address"><label for="address" class="control-label">Address</label><textarea id="address" name="address" class="form-control" rows="4">6 / 204 Bangala Thottam,
Post Office Road,</textarea></div>                                    <div class="form-group" app-field-wrapper="city"><label for="city" class="control-label">City</label><input type="text" id="city" name="city" class="form-control" value="Avinashi"></div>                                    <div class="form-group" app-field-wrapper="state"><label for="state" class="control-label">State</label><input type="text" id="state" name="state" class="form-control" value="Tamilnadu"></div>                                    <div class="form-group" app-field-wrapper="zip"><label for="zip" class="control-label">Zip Code</label><input type="text" id="zip" name="zip" class="form-control" value="641 654"></div>                  <div class="form-group" app-field-wrapper="country"><label for="country" class="control-label">Country</label><div class="dropdown bootstrap-select bs3" style="width: 100%;"><select id="country" name="country" class="selectpicker" data-none-selected-text="Nothing selected" data-width="100%" data-live-search="true" tabindex="-98"><option value=""></option><option value="1">Afghanistan</option><option value="2">Aland Islands</option><option value="3">Albania</option><option value="4">Algeria</option><option value="5">American Samoa</option><option value="6">Andorra</option><option value="7">Angola</option><option value="8">Anguilla</option><option value="9">Antarctica</option><option value="10">Antigua and Barbuda</option><option value="11">Argentina</option><option value="12">Armenia</option><option value="13">Aruba</option><option value="14">Australia</option><option value="15">Austria</option><option value="16">Azerbaijan</option><option value="17">Bahamas</option><option value="18">Bahrain</option><option value="19">Bangladesh</option><option value="20">Barbados</option><option value="21">Belarus</option><option value="22">Belgium</option><option value="23">Belize</option><option value="24">Benin</option><option value="25">Bermuda</option><option value="26">Bhutan</option><option value="27">Bolivia</option><option value="28">Bonaire, Sint Eustatius and Saba</option><option value="29">Bosnia and Herzegovina</option><option value="30">Botswana</option><option value="31">Bouvet Island</option><option value="32">Brazil</option><option value="33">British Indian Ocean Territory</option><option value="34">Brunei</option><option value="35">Bulgaria</option><option value="36">Burkina Faso</option><option value="37">Burundi</option><option value="38">Cambodia</option><option value="39">Cameroon</option><option value="40">Canada</option><option value="41">Cape Verde</option><option value="42">Cayman Islands</option><option value="43">Central African Republic</option><option value="44">Chad</option><option value="45">Chile</option><option value="46">China</option><option value="47">Christmas Island</option><option value="48">Cocos (Keeling) Islands</option><option value="49">Colombia</option><option value="50">Comoros</option><option value="51">Congo</option><option value="52">Cook Islands</option><option value="53">Costa Rica</option><option value="54">Cote d'ivoire (Ivory Coast)</option><option value="55">Croatia</option><option value="56">Cuba</option><option value="57">Curacao</option><option value="58">Cyprus</option><option value="59">Czech Republic</option><option value="60">Democratic Republic of the Congo</option><option value="61">Denmark</option><option value="62">Djibouti</option><option value="63">Dominica</option><option value="64">Dominican Republic</option><option value="65">Ecuador</option><option value="66">Egypt</option><option value="67">El Salvador</option><option value="68">Equatorial Guinea</option><option value="69">Eritrea</option><option value="70">Estonia</option><option value="71">Ethiopia</option><option value="72">Falkland Islands (Malvinas)</option><option value="73">Faroe Islands</option><option value="74">Fiji</option><option value="75">Finland</option><option value="76">France</option><option value="77">French Guiana</option><option value="78">French Polynesia</option><option value="79">French Southern Territories</option><option value="80">Gabon</option><option value="81">Gambia</option><option value="82">Georgia</option><option value="83">Germany</option><option value="84">Ghana</option><option value="85">Gibraltar</option><option value="86">Greece</option><option value="87">Greenland</option><option value="88">Grenada</option><option value="89">Guadaloupe</option><option value="90">Guam</option><option value="91">Guatemala</option><option value="92">Guernsey</option><option value="93">Guinea</option><option value="94">Guinea-Bissau</option><option value="95">Guyana</option><option value="96">Haiti</option><option value="97">Heard Island and McDonald Islands</option><option value="98">Honduras</option><option value="99">Hong Kong</option><option value="100">Hungary</option><option value="101">Iceland</option><option value="102" selected="">India</option><option value="103">Indonesia</option><option value="104">Iran</option><option value="105">Iraq</option><option value="106">Ireland</option><option value="107">Isle of Man</option><option value="108">Israel</option><option value="109">Italy</option><option value="110">Jamaica</option><option value="111">Japan</option><option value="112">Jersey</option><option value="113">Jordan</option><option value="114">Kazakhstan</option><option value="115">Kenya</option><option value="116">Kiribati</option><option value="117">Kosovo</option><option value="118">Kuwait</option><option value="119">Kyrgyzstan</option><option value="120">Laos</option><option value="121">Latvia</option><option value="122">Lebanon</option><option value="123">Lesotho</option><option value="124">Liberia</option><option value="125">Libya</option><option value="126">Liechtenstein</option><option value="127">Lithuania</option><option value="128">Luxembourg</option><option value="129">Macao</option><option value="131">Madagascar</option><option value="132">Malawi</option><option value="133">Malaysia</option><option value="134">Maldives</option><option value="135">Mali</option><option value="136">Malta</option><option value="137">Marshall Islands</option><option value="138">Martinique</option><option value="139">Mauritania</option><option value="140">Mauritius</option><option value="141">Mayotte</option><option value="142">Mexico</option><option value="143">Micronesia</option><option value="144">Moldava</option><option value="145">Monaco</option><option value="146">Mongolia</option><option value="147">Montenegro</option><option value="148">Montserrat</option><option value="149">Morocco</option><option value="150">Mozambique</option><option value="151">Myanmar (Burma)</option><option value="152">Namibia</option><option value="153">Nauru</option><option value="154">Nepal</option><option value="155">Netherlands</option><option value="156">New Caledonia</option><option value="157">New Zealand</option><option value="158">Nicaragua</option><option value="159">Niger</option><option value="160">Nigeria</option><option value="161">Niue</option><option value="162">Norfolk Island</option><option value="163">North Korea</option><option value="130">North Macedonia</option><option value="164">Northern Mariana Islands</option><option value="165">Norway</option><option value="166">Oman</option><option value="167">Pakistan</option><option value="168">Palau</option><option value="169">Palestine</option><option value="170">Panama</option><option value="171">Papua New Guinea</option><option value="172">Paraguay</option><option value="173">Peru</option><option value="174">Phillipines</option><option value="175">Pitcairn</option><option value="176">Poland</option><option value="177">Portugal</option><option value="178">Puerto Rico</option><option value="179">Qatar</option><option value="180">Reunion</option><option value="181">Romania</option><option value="182">Russia</option><option value="183">Rwanda</option><option value="184">Saint Barthelemy</option><option value="185">Saint Helena</option><option value="186">Saint Kitts and Nevis</option><option value="187">Saint Lucia</option><option value="188">Saint Martin</option><option value="189">Saint Pierre and Miquelon</option><option value="190">Saint Vincent and the Grenadines</option><option value="191">Samoa</option><option value="192">San Marino</option><option value="193">Sao Tome and Principe</option><option value="194">Saudi Arabia</option><option value="195">Senegal</option><option value="196">Serbia</option><option value="197">Seychelles</option><option value="198">Sierra Leone</option><option value="199">Singapore</option><option value="200">Sint Maarten</option><option value="201">Slovakia</option><option value="202">Slovenia</option><option value="203">Solomon Islands</option><option value="204">Somalia</option><option value="205">South Africa</option><option value="206">South Georgia and the South Sandwich Islands</option><option value="207">South Korea</option><option value="208">South Sudan</option><option value="209">Spain</option><option value="210">Sri Lanka</option><option value="211">Sudan</option><option value="212">Suriname</option><option value="213">Svalbard and Jan Mayen</option><option value="214">Swaziland</option><option value="215">Sweden</option><option value="216">Switzerland</option><option value="217">Syria</option><option value="218">Taiwan</option><option value="219">Tajikistan</option><option value="220">Tanzania</option><option value="221">Thailand</option><option value="222">Timor-Leste (East Timor)</option><option value="223">Togo</option><option value="224">Tokelau</option><option value="225">Tonga</option><option value="226">Trinidad and Tobago</option><option value="227">Tunisia</option><option value="228">Turkey</option><option value="229">Turkmenistan</option><option value="230">Turks and Caicos Islands</option><option value="231">Tuvalu</option><option value="232">Uganda</option><option value="233">Ukraine</option><option value="234">United Arab Emirates</option><option value="235">United Kingdom</option><option value="236">United States</option><option value="237">United States Minor Outlying Islands</option><option value="238">Uruguay</option><option value="239">Uzbekistan</option><option value="240">Vanuatu</option><option value="241">Vatican City</option><option value="242">Venezuela</option><option value="243">Vietnam</option><option value="244">Virgin Islands, British</option><option value="245">Virgin Islands, US</option><option value="246">Wallis and Futuna</option><option value="247">Western Sahara</option><option value="248">Yemen</option><option value="249">Zambia</option><option value="250">Zimbabwe</option></select><button type="button" class="btn dropdown-toggle btn-default" data-toggle="dropdown" role="combobox" aria-owns="bs-select-3" aria-haspopup="listbox" aria-expanded="false" data-id="country" title="India"><div class="filter-option"><div class="filter-option-inner"><div class="filter-option-inner-inner">India</div></div> </div><span class="bs-caret"><span class="caret"></span></span></button><div class="dropdown-menu open"><div class="bs-searchbox"><input type="text" class="form-control" autocomplete="off" role="combobox" aria-label="Search" aria-controls="bs-select-3" aria-autocomplete="list"></div><div class="inner open" role="listbox" id="bs-select-3" tabindex="-1"><ul class="dropdown-menu inner " role="presentation"></ul></div></div></div></div>               </div>
            </div>
         </div>
                  <div role="tabpanel" class="tab-pane" id="customer_admins">
                        <a href="#" data-toggle="modal" data-target="#customer_admins_assign" class="btn btn-info mbot30">Assign admin</a>
                        <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer app_dt_empty"><div class="row"></div><div class="row"><div class="col-md-6"><div class="dataTables_length" id="DataTables_Table_0_length"><label><select name="DataTables_Table_0_length" aria-controls="DataTables_Table_0" class="form-control input-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option><option value="-1">All</option></select></label></div><div class="dt-buttons btn-group"><button class="btn btn-default buttons-collection btn-default-dt-options" tabindex="0" aria-controls="DataTables_Table_0" type="button" aria-haspopup="true" aria-expanded="false"><span>Export</span></button> </div></div><div class="col-md-6"><div id="DataTables_Table_0_filter" class="dataTables_filter"><label><div class="input-group"><span class="input-group-addon"><span class="fa fa-search"></span></span><input type="search" class="form-control input-sm" placeholder="Search..." aria-controls="DataTables_Table_0"></div></label></div></div><div id="DataTables_Table_0_processing" class="dataTables_processing panel panel-default" style="display: none;"><div class="dt-loader"></div></div></div><table class="table dt-table dt-inline dataTable no-footer" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info">
               <thead>
                  <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Staff Member activate to sort column descending">Staff Member</th><th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Date Assigned activate to sort column ascending">Date Assigned</th><th class="sorting not-export" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Options activate to sort column ascending">Options</th></tr>
               </thead>
               <tbody>
                                 <tr class="odd"><td valign="top" colspan="3" class="dataTables_empty">No entries found</td></tr></tbody>
            </table><div class="row"><div class="col-md-4"><div class="dataTables_info" id="DataTables_Table_0_info" role="status" aria-live="polite">Showing 0 to 0 of 0 entries</div></div></div><div class="row"><div id="colvis"></div><div id="" class="dt-page-jump"></div><div class="dataTables_paginate paging_simple_numbers" id="DataTables_Table_0_paginate"><ul class="pagination"><li class="paginate_button previous disabled" id="DataTables_Table_0_previous"><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="0" tabindex="0">Previous</a></li><li class="paginate_button next disabled" id="DataTables_Table_0_next"><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="1" tabindex="0">Next</a></li></ul></div></div></div>
         </div>
                  <div role="tabpanel" class="tab-pane" id="billing_and_shipping">
            <div class="row">
               <div class="col-md-12">
                  <div class="row">
                     <div class="col-md-6">
                        <h4 class="no-mtop">Billing Address <a href="#" class="pull-right billing-same-as-customer"><small class="font-medium-xs">Same as Customer Info</small></a></h4>
                        <hr>
                                                <div class="form-group" app-field-wrapper="billing_street"><label for="billing_street" class="control-label">Street</label><textarea id="billing_street" name="billing_street" class="form-control" rows="4">6 / 204 Bangala Thottam,
Post Office Road,</textarea></div>                                                <div class="form-group" app-field-wrapper="billing_city"><label for="billing_city" class="control-label">City</label><input type="text" id="billing_city" name="billing_city" class="form-control" value="Avinashi"></div>                                                <div class="form-group" app-field-wrapper="billing_state"><label for="billing_state" class="control-label">State</label><input type="text" id="billing_state" name="billing_state" class="form-control" value="Tamilnadu"></div>                                                <div class="form-group" app-field-wrapper="billing_zip"><label for="billing_zip" class="control-label">Zip Code</label><input type="text" id="billing_zip" name="billing_zip" class="form-control" value="641 654"></div>                                                <div class="form-group" app-field-wrapper="billing_country"><label for="billing_country" class="control-label">Country</label><div class="dropdown bootstrap-select bs3" style="width: 100%;"><select id="billing_country" name="billing_country" class="selectpicker" data-none-selected-text="Nothing selected" data-width="100%" data-live-search="true" tabindex="-98"><option value=""></option><option value="1">Afghanistan</option><option value="2">Aland Islands</option><option value="3">Albania</option><option value="4">Algeria</option><option value="5">American Samoa</option><option value="6">Andorra</option><option value="7">Angola</option><option value="8">Anguilla</option><option value="9">Antarctica</option><option value="10">Antigua and Barbuda</option><option value="11">Argentina</option><option value="12">Armenia</option><option value="13">Aruba</option><option value="14">Australia</option><option value="15">Austria</option><option value="16">Azerbaijan</option><option value="17">Bahamas</option><option value="18">Bahrain</option><option value="19">Bangladesh</option><option value="20">Barbados</option><option value="21">Belarus</option><option value="22">Belgium</option><option value="23">Belize</option><option value="24">Benin</option><option value="25">Bermuda</option><option value="26">Bhutan</option><option value="27">Bolivia</option><option value="28">Bonaire, Sint Eustatius and Saba</option><option value="29">Bosnia and Herzegovina</option><option value="30">Botswana</option><option value="31">Bouvet Island</option><option value="32">Brazil</option><option value="33">British Indian Ocean Territory</option><option value="34">Brunei</option><option value="35">Bulgaria</option><option value="36">Burkina Faso</option><option value="37">Burundi</option><option value="38">Cambodia</option><option value="39">Cameroon</option><option value="40">Canada</option><option value="41">Cape Verde</option><option value="42">Cayman Islands</option><option value="43">Central African Republic</option><option value="44">Chad</option><option value="45">Chile</option><option value="46">China</option><option value="47">Christmas Island</option><option value="48">Cocos (Keeling) Islands</option><option value="49">Colombia</option><option value="50">Comoros</option><option value="51">Congo</option><option value="52">Cook Islands</option><option value="53">Costa Rica</option><option value="54">Cote d'ivoire (Ivory Coast)</option><option value="55">Croatia</option><option value="56">Cuba</option><option value="57">Curacao</option><option value="58">Cyprus</option><option value="59">Czech Republic</option><option value="60">Democratic Republic of the Congo</option><option value="61">Denmark</option><option value="62">Djibouti</option><option value="63">Dominica</option><option value="64">Dominican Republic</option><option value="65">Ecuador</option><option value="66">Egypt</option><option value="67">El Salvador</option><option value="68">Equatorial Guinea</option><option value="69">Eritrea</option><option value="70">Estonia</option><option value="71">Ethiopia</option><option value="72">Falkland Islands (Malvinas)</option><option value="73">Faroe Islands</option><option value="74">Fiji</option><option value="75">Finland</option><option value="76">France</option><option value="77">French Guiana</option><option value="78">French Polynesia</option><option value="79">French Southern Territories</option><option value="80">Gabon</option><option value="81">Gambia</option><option value="82">Georgia</option><option value="83">Germany</option><option value="84">Ghana</option><option value="85">Gibraltar</option><option value="86">Greece</option><option value="87">Greenland</option><option value="88">Grenada</option><option value="89">Guadaloupe</option><option value="90">Guam</option><option value="91">Guatemala</option><option value="92">Guernsey</option><option value="93">Guinea</option><option value="94">Guinea-Bissau</option><option value="95">Guyana</option><option value="96">Haiti</option><option value="97">Heard Island and McDonald Islands</option><option value="98">Honduras</option><option value="99">Hong Kong</option><option value="100">Hungary</option><option value="101">Iceland</option><option value="102" selected="">India</option><option value="103">Indonesia</option><option value="104">Iran</option><option value="105">Iraq</option><option value="106">Ireland</option><option value="107">Isle of Man</option><option value="108">Israel</option><option value="109">Italy</option><option value="110">Jamaica</option><option value="111">Japan</option><option value="112">Jersey</option><option value="113">Jordan</option><option value="114">Kazakhstan</option><option value="115">Kenya</option><option value="116">Kiribati</option><option value="117">Kosovo</option><option value="118">Kuwait</option><option value="119">Kyrgyzstan</option><option value="120">Laos</option><option value="121">Latvia</option><option value="122">Lebanon</option><option value="123">Lesotho</option><option value="124">Liberia</option><option value="125">Libya</option><option value="126">Liechtenstein</option><option value="127">Lithuania</option><option value="128">Luxembourg</option><option value="129">Macao</option><option value="131">Madagascar</option><option value="132">Malawi</option><option value="133">Malaysia</option><option value="134">Maldives</option><option value="135">Mali</option><option value="136">Malta</option><option value="137">Marshall Islands</option><option value="138">Martinique</option><option value="139">Mauritania</option><option value="140">Mauritius</option><option value="141">Mayotte</option><option value="142">Mexico</option><option value="143">Micronesia</option><option value="144">Moldava</option><option value="145">Monaco</option><option value="146">Mongolia</option><option value="147">Montenegro</option><option value="148">Montserrat</option><option value="149">Morocco</option><option value="150">Mozambique</option><option value="151">Myanmar (Burma)</option><option value="152">Namibia</option><option value="153">Nauru</option><option value="154">Nepal</option><option value="155">Netherlands</option><option value="156">New Caledonia</option><option value="157">New Zealand</option><option value="158">Nicaragua</option><option value="159">Niger</option><option value="160">Nigeria</option><option value="161">Niue</option><option value="162">Norfolk Island</option><option value="163">North Korea</option><option value="130">North Macedonia</option><option value="164">Northern Mariana Islands</option><option value="165">Norway</option><option value="166">Oman</option><option value="167">Pakistan</option><option value="168">Palau</option><option value="169">Palestine</option><option value="170">Panama</option><option value="171">Papua New Guinea</option><option value="172">Paraguay</option><option value="173">Peru</option><option value="174">Phillipines</option><option value="175">Pitcairn</option><option value="176">Poland</option><option value="177">Portugal</option><option value="178">Puerto Rico</option><option value="179">Qatar</option><option value="180">Reunion</option><option value="181">Romania</option><option value="182">Russia</option><option value="183">Rwanda</option><option value="184">Saint Barthelemy</option><option value="185">Saint Helena</option><option value="186">Saint Kitts and Nevis</option><option value="187">Saint Lucia</option><option value="188">Saint Martin</option><option value="189">Saint Pierre and Miquelon</option><option value="190">Saint Vincent and the Grenadines</option><option value="191">Samoa</option><option value="192">San Marino</option><option value="193">Sao Tome and Principe</option><option value="194">Saudi Arabia</option><option value="195">Senegal</option><option value="196">Serbia</option><option value="197">Seychelles</option><option value="198">Sierra Leone</option><option value="199">Singapore</option><option value="200">Sint Maarten</option><option value="201">Slovakia</option><option value="202">Slovenia</option><option value="203">Solomon Islands</option><option value="204">Somalia</option><option value="205">South Africa</option><option value="206">South Georgia and the South Sandwich Islands</option><option value="207">South Korea</option><option value="208">South Sudan</option><option value="209">Spain</option><option value="210">Sri Lanka</option><option value="211">Sudan</option><option value="212">Suriname</option><option value="213">Svalbard and Jan Mayen</option><option value="214">Swaziland</option><option value="215">Sweden</option><option value="216">Switzerland</option><option value="217">Syria</option><option value="218">Taiwan</option><option value="219">Tajikistan</option><option value="220">Tanzania</option><option value="221">Thailand</option><option value="222">Timor-Leste (East Timor)</option><option value="223">Togo</option><option value="224">Tokelau</option><option value="225">Tonga</option><option value="226">Trinidad and Tobago</option><option value="227">Tunisia</option><option value="228">Turkey</option><option value="229">Turkmenistan</option><option value="230">Turks and Caicos Islands</option><option value="231">Tuvalu</option><option value="232">Uganda</option><option value="233">Ukraine</option><option value="234">United Arab Emirates</option><option value="235">United Kingdom</option><option value="236">United States</option><option value="237">United States Minor Outlying Islands</option><option value="238">Uruguay</option><option value="239">Uzbekistan</option><option value="240">Vanuatu</option><option value="241">Vatican City</option><option value="242">Venezuela</option><option value="243">Vietnam</option><option value="244">Virgin Islands, British</option><option value="245">Virgin Islands, US</option><option value="246">Wallis and Futuna</option><option value="247">Western Sahara</option><option value="248">Yemen</option><option value="249">Zambia</option><option value="250">Zimbabwe</option></select><button type="button" class="btn dropdown-toggle btn-default" data-toggle="dropdown" role="combobox" aria-owns="bs-select-4" aria-haspopup="listbox" aria-expanded="false" data-id="billing_country" title="India"><div class="filter-option"><div class="filter-option-inner"><div class="filter-option-inner-inner">India</div></div> </div><span class="bs-caret"><span class="caret"></span></span></button><div class="dropdown-menu open"><div class="bs-searchbox"><input type="text" class="form-control" autocomplete="off" role="combobox" aria-label="Search" aria-controls="bs-select-4" aria-autocomplete="list"></div><div class="inner open" role="listbox" id="bs-select-4" tabindex="-1"><ul class="dropdown-menu inner " role="presentation"></ul></div></div></div></div>                     </div>
                     <div class="col-md-6">
                        <h4 class="no-mtop">
                           <i class="fa fa-question-circle" data-toggle="tooltip" data-title="Do not fill shipping address information if you won't use shipping address on customer invoices"></i>
                           Shipping Address <a href="#" class="pull-right customer-copy-billing-address"><small class="font-medium-xs">Copy Billing Address</small></a>
                        </h4>
                        <hr>
                                                <div class="form-group" app-field-wrapper="shipping_street"><label for="shipping_street" class="control-label">Street</label><textarea id="shipping_street" name="shipping_street" class="form-control" rows="4"></textarea></div>                                                <div class="form-group" app-field-wrapper="shipping_city"><label for="shipping_city" class="control-label">City</label><input type="text" id="shipping_city" name="shipping_city" class="form-control" value=""></div>                                                <div class="form-group" app-field-wrapper="shipping_state"><label for="shipping_state" class="control-label">State</label><input type="text" id="shipping_state" name="shipping_state" class="form-control" value=""></div>                                                <div class="form-group" app-field-wrapper="shipping_zip"><label for="shipping_zip" class="control-label">Zip Code</label><input type="text" id="shipping_zip" name="shipping_zip" class="form-control" value=""></div>                                                <div class="form-group" app-field-wrapper="shipping_country"><label for="shipping_country" class="control-label">Country</label><div class="dropdown bootstrap-select bs3" style="width: 100%;"><select id="shipping_country" name="shipping_country" class="selectpicker" data-none-selected-text="Nothing selected" data-width="100%" data-live-search="true" tabindex="-98"><option value=""></option><option value="1">Afghanistan</option><option value="2">Aland Islands</option><option value="3">Albania</option><option value="4">Algeria</option><option value="5">American Samoa</option><option value="6">Andorra</option><option value="7">Angola</option><option value="8">Anguilla</option><option value="9">Antarctica</option><option value="10">Antigua and Barbuda</option><option value="11">Argentina</option><option value="12">Armenia</option><option value="13">Aruba</option><option value="14">Australia</option><option value="15">Austria</option><option value="16">Azerbaijan</option><option value="17">Bahamas</option><option value="18">Bahrain</option><option value="19">Bangladesh</option><option value="20">Barbados</option><option value="21">Belarus</option><option value="22">Belgium</option><option value="23">Belize</option><option value="24">Benin</option><option value="25">Bermuda</option><option value="26">Bhutan</option><option value="27">Bolivia</option><option value="28">Bonaire, Sint Eustatius and Saba</option><option value="29">Bosnia and Herzegovina</option><option value="30">Botswana</option><option value="31">Bouvet Island</option><option value="32">Brazil</option><option value="33">British Indian Ocean Territory</option><option value="34">Brunei</option><option value="35">Bulgaria</option><option value="36">Burkina Faso</option><option value="37">Burundi</option><option value="38">Cambodia</option><option value="39">Cameroon</option><option value="40">Canada</option><option value="41">Cape Verde</option><option value="42">Cayman Islands</option><option value="43">Central African Republic</option><option value="44">Chad</option><option value="45">Chile</option><option value="46">China</option><option value="47">Christmas Island</option><option value="48">Cocos (Keeling) Islands</option><option value="49">Colombia</option><option value="50">Comoros</option><option value="51">Congo</option><option value="52">Cook Islands</option><option value="53">Costa Rica</option><option value="54">Cote d'ivoire (Ivory Coast)</option><option value="55">Croatia</option><option value="56">Cuba</option><option value="57">Curacao</option><option value="58">Cyprus</option><option value="59">Czech Republic</option><option value="60">Democratic Republic of the Congo</option><option value="61">Denmark</option><option value="62">Djibouti</option><option value="63">Dominica</option><option value="64">Dominican Republic</option><option value="65">Ecuador</option><option value="66">Egypt</option><option value="67">El Salvador</option><option value="68">Equatorial Guinea</option><option value="69">Eritrea</option><option value="70">Estonia</option><option value="71">Ethiopia</option><option value="72">Falkland Islands (Malvinas)</option><option value="73">Faroe Islands</option><option value="74">Fiji</option><option value="75">Finland</option><option value="76">France</option><option value="77">French Guiana</option><option value="78">French Polynesia</option><option value="79">French Southern Territories</option><option value="80">Gabon</option><option value="81">Gambia</option><option value="82">Georgia</option><option value="83">Germany</option><option value="84">Ghana</option><option value="85">Gibraltar</option><option value="86">Greece</option><option value="87">Greenland</option><option value="88">Grenada</option><option value="89">Guadaloupe</option><option value="90">Guam</option><option value="91">Guatemala</option><option value="92">Guernsey</option><option value="93">Guinea</option><option value="94">Guinea-Bissau</option><option value="95">Guyana</option><option value="96">Haiti</option><option value="97">Heard Island and McDonald Islands</option><option value="98">Honduras</option><option value="99">Hong Kong</option><option value="100">Hungary</option><option value="101">Iceland</option><option value="102">India</option><option value="103">Indonesia</option><option value="104">Iran</option><option value="105">Iraq</option><option value="106">Ireland</option><option value="107">Isle of Man</option><option value="108">Israel</option><option value="109">Italy</option><option value="110">Jamaica</option><option value="111">Japan</option><option value="112">Jersey</option><option value="113">Jordan</option><option value="114">Kazakhstan</option><option value="115">Kenya</option><option value="116">Kiribati</option><option value="117">Kosovo</option><option value="118">Kuwait</option><option value="119">Kyrgyzstan</option><option value="120">Laos</option><option value="121">Latvia</option><option value="122">Lebanon</option><option value="123">Lesotho</option><option value="124">Liberia</option><option value="125">Libya</option><option value="126">Liechtenstein</option><option value="127">Lithuania</option><option value="128">Luxembourg</option><option value="129">Macao</option><option value="131">Madagascar</option><option value="132">Malawi</option><option value="133">Malaysia</option><option value="134">Maldives</option><option value="135">Mali</option><option value="136">Malta</option><option value="137">Marshall Islands</option><option value="138">Martinique</option><option value="139">Mauritania</option><option value="140">Mauritius</option><option value="141">Mayotte</option><option value="142">Mexico</option><option value="143">Micronesia</option><option value="144">Moldava</option><option value="145">Monaco</option><option value="146">Mongolia</option><option value="147">Montenegro</option><option value="148">Montserrat</option><option value="149">Morocco</option><option value="150">Mozambique</option><option value="151">Myanmar (Burma)</option><option value="152">Namibia</option><option value="153">Nauru</option><option value="154">Nepal</option><option value="155">Netherlands</option><option value="156">New Caledonia</option><option value="157">New Zealand</option><option value="158">Nicaragua</option><option value="159">Niger</option><option value="160">Nigeria</option><option value="161">Niue</option><option value="162">Norfolk Island</option><option value="163">North Korea</option><option value="130">North Macedonia</option><option value="164">Northern Mariana Islands</option><option value="165">Norway</option><option value="166">Oman</option><option value="167">Pakistan</option><option value="168">Palau</option><option value="169">Palestine</option><option value="170">Panama</option><option value="171">Papua New Guinea</option><option value="172">Paraguay</option><option value="173">Peru</option><option value="174">Phillipines</option><option value="175">Pitcairn</option><option value="176">Poland</option><option value="177">Portugal</option><option value="178">Puerto Rico</option><option value="179">Qatar</option><option value="180">Reunion</option><option value="181">Romania</option><option value="182">Russia</option><option value="183">Rwanda</option><option value="184">Saint Barthelemy</option><option value="185">Saint Helena</option><option value="186">Saint Kitts and Nevis</option><option value="187">Saint Lucia</option><option value="188">Saint Martin</option><option value="189">Saint Pierre and Miquelon</option><option value="190">Saint Vincent and the Grenadines</option><option value="191">Samoa</option><option value="192">San Marino</option><option value="193">Sao Tome and Principe</option><option value="194">Saudi Arabia</option><option value="195">Senegal</option><option value="196">Serbia</option><option value="197">Seychelles</option><option value="198">Sierra Leone</option><option value="199">Singapore</option><option value="200">Sint Maarten</option><option value="201">Slovakia</option><option value="202">Slovenia</option><option value="203">Solomon Islands</option><option value="204">Somalia</option><option value="205">South Africa</option><option value="206">South Georgia and the South Sandwich Islands</option><option value="207">South Korea</option><option value="208">South Sudan</option><option value="209">Spain</option><option value="210">Sri Lanka</option><option value="211">Sudan</option><option value="212">Suriname</option><option value="213">Svalbard and Jan Mayen</option><option value="214">Swaziland</option><option value="215">Sweden</option><option value="216">Switzerland</option><option value="217">Syria</option><option value="218">Taiwan</option><option value="219">Tajikistan</option><option value="220">Tanzania</option><option value="221">Thailand</option><option value="222">Timor-Leste (East Timor)</option><option value="223">Togo</option><option value="224">Tokelau</option><option value="225">Tonga</option><option value="226">Trinidad and Tobago</option><option value="227">Tunisia</option><option value="228">Turkey</option><option value="229">Turkmenistan</option><option value="230">Turks and Caicos Islands</option><option value="231">Tuvalu</option><option value="232">Uganda</option><option value="233">Ukraine</option><option value="234">United Arab Emirates</option><option value="235">United Kingdom</option><option value="236">United States</option><option value="237">United States Minor Outlying Islands</option><option value="238">Uruguay</option><option value="239">Uzbekistan</option><option value="240">Vanuatu</option><option value="241">Vatican City</option><option value="242">Venezuela</option><option value="243">Vietnam</option><option value="244">Virgin Islands, British</option><option value="245">Virgin Islands, US</option><option value="246">Wallis and Futuna</option><option value="247">Western Sahara</option><option value="248">Yemen</option><option value="249">Zambia</option><option value="250">Zimbabwe</option></select><button type="button" class="btn dropdown-toggle btn-default bs-placeholder" data-toggle="dropdown" role="combobox" aria-owns="bs-select-5" aria-haspopup="listbox" aria-expanded="false" data-id="shipping_country" title="Nothing selected"><div class="filter-option"><div class="filter-option-inner"><div class="filter-option-inner-inner">Nothing selected</div></div> </div><span class="bs-caret"><span class="caret"></span></span></button><div class="dropdown-menu open"><div class="bs-searchbox"><input type="text" class="form-control" autocomplete="off" role="combobox" aria-label="Search" aria-controls="bs-select-5" aria-autocomplete="list"></div><div class="inner open" role="listbox" id="bs-select-5" tabindex="-1"><ul class="dropdown-menu inner " role="presentation"></ul></div></div></div></div>                     </div>
                                       </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   </form></div>
<div class="modal fade" id="customer_admins_assign" tabindex="-1" role="dialog">
   <div class="modal-dialog">
      <form action="http://support.iorange.in/admin/clients/assign_admins/1812" method="post" accept-charset="utf-8">
                                                                                                                        <input type="hidden" name="csrf_token_name" value="3931f759c5874c0be5012e05bf4ac24b">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            <h4 class="modal-title">Assign admin</h4>
         </div>
         <div class="modal-body">
            <div class="form-group" app-field-wrapper="customer_admins[]"><div class="dropdown bootstrap-select show-tick bs3" style="width: 100%;"><select id="customer_admins[]" name="customer_admins[]" class="selectpicker" multiple="1" data-width="100%" data-none-selected-text="Nothing selected" data-live-search="true" tabindex="-98"><option value="7">Vignesh S</option><option value="3">Tamil  Selvi</option><option value="4">Sujith S</option><option value="6">Selvam P</option><option value="1">iOrange Innovation</option><option value="5">Harshini .</option></select><button type="button" class="btn dropdown-toggle btn-default bs-placeholder" data-toggle="dropdown" role="combobox" aria-owns="bs-select-6" aria-haspopup="listbox" aria-expanded="false" data-id="customer_admins[]" title="Nothing selected"><div class="filter-option"><div class="filter-option-inner"><div class="filter-option-inner-inner">Nothing selected</div></div> </div><span class="bs-caret"><span class="caret"></span></span></button><div class="dropdown-menu open"><div class="bs-searchbox"><input type="text" class="form-control" autocomplete="off" role="combobox" aria-label="Search" aria-controls="bs-select-6" aria-autocomplete="list"></div><div class="inner open" role="listbox" id="bs-select-6" tabindex="-1" aria-multiselectable="true"><ul class="dropdown-menu inner " role="presentation"></ul></div></div></div></div>         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-info">Save</button>
         </div>
      </div>
      <!-- /.modal-content -->
      </form>   </div>
   <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<div class="modal fade" id="customer_group_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button group="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title" id="myModalLabel">
                    <span class="edit-title">Edit Customer Group</span>
                    <span class="add-title">Add New Customer Group</span>
                </h4>
            </div>
            <form action="http://support.iorange.in/admin/clients/group" id="customer-group-modal" method="post" accept-charset="utf-8" novalidate="novalidate">
                                                                                                                    <input type="hidden" name="csrf_token_name" value="3931f759c5874c0be5012e05bf4ac24b">
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group" app-field-wrapper="name"><label for="name" class="control-label"> <small class="req text-danger">* </small>Name</label><input type="text" id="name" name="name" class="form-control" value=""></div>                        
<input type="hidden" name="id" value="">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button group="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button group="submit" class="btn btn-info">Save</button>
                            </div></form>
        </div>
    </div>
</div>
<script>
    window.addEventListener('load',function(){
       appValidateForm($('#customer-group-modal'), {
        name: 'required'
    }, manage_customer_groups);

       $('#customer_group_modal').on('show.bs.modal', function(e) {
        var invoker = $(e.relatedTarget);
        var group_id = $(invoker).data('id');
        $('#customer_group_modal .add-title').removeClass('hide');
        $('#customer_group_modal .edit-title').addClass('hide');
        $('#customer_group_modal input[name="id"]').val('');
        $('#customer_group_modal input[name="name"]').val('');
        // is from the edit button
        if (typeof(group_id) !== 'undefined') {
            $('#customer_group_modal input[name="id"]').val(group_id);
            $('#customer_group_modal .add-title').addClass('hide');
            $('#customer_group_modal .edit-title').removeClass('hide');
            $('#customer_group_modal input[name="name"]').val($(invoker).parents('tr').find('td').eq(0).text());
        }
    });
   });
    function manage_customer_groups(form) {
        var data = $(form).serialize();
        var url = form.action;
        $.post(url, data).done(function(response) {
            response = JSON.parse(response);
            if (response.success == true) {
                if($.fn.DataTable.isDataTable('.table-customer-groups')){
                    $('.table-customer-groups').DataTable().ajax.reload();
                }
                if($('body').hasClass('dynamic-create-groups') && typeof(response.id) != 'undefined') {
                    var groups = $('select[name="groups_in[]"]');
                    groups.prepend('<option value="'+response.id+'">'+response.name+'</option>');
                    groups.selectpicker('refresh');
                }
                alert_float('success', response.message);
            }
            $('#customer_group_modal').modal('hide');
        });
        return false;
    }

</script>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
               <div class="btn-bottom-pusher"></div>
         </div>
								
								
                        </div>
                    </div>
                </div>
				<input type="hidden" name="action" id="action" value="<?php echo $action ?>" />
	  <?php if(isset($colid)){ ?>
		<input type="hidden" name="colid" id="colid" value="<?php echo $colid ?>" />
	  <?php  } ?>
				</form>
                <!-- Sales chart -->
            </div>
            <!-- End Container fluid  -->
        </div>
        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->
            <!-- footer -->
            <?php include('includes/footer.php');?>
            <!-- End footer -->
    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
	<script>
	$(function () {
		$("form#supplier_info").submit(function(e) {
			e.preventDefault();
			var formData = new FormData(this);

			$.ajax({
				url: "ajax/suppliers.php",
				type: 'POST',
				data: formData,
				success: function (data) {
				//alert(data);
					if($.trim(data)=='1'){
						alert("<?php echo $sucessMsg; ?>");
						window.location.href="supplier.php";
					} 
					if($.trim(data)=='2'){
						alert("Supplier Name already exists!!");
					} 
					if($.trim(data)=='0'){
						alert("Query Failed");
					}
				},
				cache: false,
				contentType: false,
				processData: false
			});
		});
	 });
	 
	 function sel_dist(st_id){
		$.ajax({
				url: "ajax/area.php?action=display_dist&state_id="+st_id,
				type: 'POST',
				data: "action=disp_dist&state_id="+st_id,
				success: function (data) {
				//	alert(data);
					$("#dist_list").html(data);
				},
				cache: false,
				contentType: false,
				processData: false
			});
	}
	
	
	function disp_area(dist_id){
		//alert(dist_id);
		$.ajax({
				url: "ajax/area.php?action=disp_area&dist_id="+dist_id,
				type: 'POST',
				data: "action=disp_area&dist_id="+dist_id,
				success: function (data) {
				//	alert(data);
					$("#area_list").html(data);
				},
				cache: false,
				contentType: false,
				processData: false
			});
	}
	</script>
</body>
</html>