<?php 
include('includes/config.php');

if($_SESSION['userid']==''){
	echo "<script>window.location.href='login.php';</script>";
}
/*echo "<pre>";
print_r($_POST);
echo "</pre>";*/
extract($_REQUEST);

if(isset($_POST['submit'])){

	
	$insert_exp_costing = mysqli_query($zconn,"insert into expenses_costing
	(costing_id,descr,compo,process_loss,rejection,overhead,farwarding_charges,
	process_profit,commission,conversion,currency,created_by,created_date) values('".$costing_no."','".$descr."',
	'".$compos."','".$process_loss."','".$rejection."','".$over_head."','".$forwarding."','".$profit."',
	'".$commission."','".$Convertion."','".$currency."','".$_SESSION['userid']."',now())");
	if($insert_exp_costing){
		echo "<script>alert('Added successfully!!');</script>";
		echo "<script>window.location.href='expense_costing.php';</script>";
	}
}
$sel_entry1 = mysqli_fetch_array(mysqli_query($zconn,"select * from expenses_costing where costing_no='".$_GET['id']."'"),MYSQLI_ASSOC);
if(isset($_POST['costing_no'])){
	$sel_costing1= mysqli_fetch_array(mysqli_query($zconn,"select * from costing_entry_master where id='".$_REQUEST['costing_no']."'"),MYSQLI_ASSOC);
$sel_buyer = mysqli_fetch_array(mysqli_query($zconn,"select expenses_costing from buyer_master where buyer_id='".$sel_costing1['buyer_id']."'"),MYSQLI_ASSOC);
	}
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - Expenses Costing Entry</title>
    <!-- Custom CSS -->
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">    
</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <div class="page-wrapper" style="min-height: 100%; height: auto;">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
             <div class="page-breadcrumb">
			 
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Expenses Costing Entry</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="#">Expenses Costing Info</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Sales chart -->
				<form method="post" name="expense_costing">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
							<div class="card-body">
							</div>
								<div class="card-body" style="width:100%">
									<div class="card-body" style="width:100%">
										<div class="card" style="width:50%; float:left; left: 50px; ">
											<div class="form-group row">
												<label for="fname" class="col-sm-3 text-right control-label col-form-label">Costing No</label>
												<div class="col-sm-6">
													
													<select class="select2 form-control custom-select" onchange="sel_details(this.value);" name="costing_no" id="costing_no">
													<option value="<?php echo $id;?>"><?php echo $id;?></option>

										<option value="">Select</option>
										<?php $sel_costing = mysqli_query($zconn,"select * from costing_entry_master");
										while($res_costing = mysqli_fetch_array($sel_costing,MYSQLI_ASSOC)){
											if($res_costing['id']==$_REQUEST['costing_no']){
										?>
										<option selected value="<?php echo $res_costing['id'];?>"><?php echo $res_costing['costing_no'];?></option>
										<?php } else  { ?>
										<option value="<?php echo $res_costing['id'];?>"><?php echo $res_costing['costing_no'];?></option>
										<?php } ?>
										<?php } ?>
											</select>
												</div>
											</div>
											<div class="form-group row">
												<label for="lname" class="col-sm-3 text-right control-label col-form-label">Order No</label>
												<div class="col-sm-6">
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control" readonly id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['order_no'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['order_no'];?>" readonly id="order_no" name="order_no" placeholder="">
											<?php } ?> 	

												</div>
											</div>

											<div class="form-group row">
												<label for="lname" class="col-sm-3 text-right control-label col-form-label">Description</label>
												<div class="col-sm-6">
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control"  id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['descr'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['descr'];?>"  id="order_no" name="order_no" placeholder="">
											<?php } ?> 	

												</div>
											</div>

											<div class="form-group row">
												<label for="lname" class="col-sm-3 text-right control-label col-form-label">Composition</label>
												<div class="col-sm-6">
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control"  id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['compo'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['compo'];?>"  id="order_no" name="order_no" placeholder="">
											<?php } ?> 	
												</div>
											</div>

											<div class="form-group row">
												<label for="lname" class="col-sm-3 text-right control-label col-form-label">Proces loss (%)</label>
												<div class="col-sm-6">
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control"  id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['process_loss'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['process_loss'];?>"  id="order_no" name="order_no" placeholder="">
											<?php } ?> 
												</div>
											</div>

											<div class="form-group row">
											</div>	

											<div class="form-group row">
												<h4 class="page-title"><b>Material Details</b></h4>
											</div>

										</div>
										<div class="card" style="width:50%; float:left; right: 50px;">
											<div class="form-group row">
												<label for="fname" class="col-sm-3 text-right control-label col-form-label">Buyer name</label>
												<div class="col-sm-6">
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control" readonly id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['buyer'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['buyer'];?>" readonly id="order_no" name="order_no" placeholder="">
											<?php } ?>
												</div>
											</div>
											<div class="form-group row">
												<label for="cono1" class="col-sm-3 text-right control-label col-form-label">Style No</label>
												<div class="col-sm-6">
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control" readonly id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['style_no'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['style_no'];?>" readonly id="order_no" name="order_no" placeholder="">
											<?php } ?>
												</div>
											</div>
											<div class="form-group row">
												<label for="cono1" class="col-sm-3 text-right control-label col-form-label">Order Date</label>
												<div class="col-sm-6">
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control" readonly id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['created_date'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['created_date'];?>" readonly id="order_no" name="order_no" placeholder="">
											<?php } ?>
												</div>
											</div>
										</div>
									</div>
									<table id="example" class="table table-striped table-bordered">

										<thead style="background-color: #626F80; color: #fff; padding: 0px; font-size: 12px;">
											<tr>
												<th>Description</th>
												<th>Composition</th>
												<th>Proces loss (%)</th>
												<th>Rejection (%)</th>
												<th>Over Head (%)</th>
												<th>Courier & Forwarding</th>
												<th>Profit (%)</th>
												<th>Commission</th>
												<th>Convertion (Rs)</th>
												<th>Currency</th>
											</tr>
										</thead>
										<tbody>
											<tr id="delete_1">
												<td>
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control"  id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['descr'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['descr'];?>"  id="order_no" name="order_no" placeholder="">
											<?php } ?> 
												</td>
												<td>
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control"  id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['compo'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['compo'];?>"  id="order_no" name="order_no" placeholder="">
											<?php } ?> 
												</td>

												<td>
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control"  id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['process_loss'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['process_loss'];?>"  id="order_no" name="order_no" placeholder="">
											<?php } ?> 
												</td>
												<td>
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control"  id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['rejection'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['rejection'];?>"  id="order_no" name="order_no" placeholder="">
											<?php } ?> 
												</td>
												<td>
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control"  id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['overhead'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['overhead'];?>"  id="order_no" name="order_no" placeholder="">
											<?php } ?> 
												</td>
												<td>
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control"  id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['farwarding_charges'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['farwarding_charges'];?>"  id="order_no" name="order_no" placeholder="">
											<?php } ?> 
												</td>
												<td>
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control"  id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['process_profit'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['process_profit'];?>"  id="order_no" name="order_no" placeholder="">
											<?php } ?> 
												</td>
												<td>
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control"  id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['commission'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['commission'];?>"  id="order_no" name="order_no" placeholder="">
											<?php } ?> 
												</td>
												<td>
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control"  id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['conversion'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" value="<?php echo $sel_costing1['conversion'];?>"  id="order_no" name="order_no" placeholder="">
											<?php } ?> 
												</td>
												<td>
												<?php if($_REQUEST['costing_no']==''){?>
												<input type="text" class="form-control"  id="lname" name="order_no"  placeholder="" value="<?php echo $sel_entry1['currency'];?>">
											<?php } else{
													?>
												<input type="text" class="form-control" 
												value="<?php echo $sel_costing1['currency'];?>"  id="order_no" name="order_no" placeholder="">
											<?php } ?> 
												</td>
											</tr>
										</tbody>
									</table>
								<div class="border-top">
									<div class="card-body" style="margin-left: 250px;">
										<button type="submit" name="submit" class="btn btn-success">Save</button>
										<button type="reset" class="btn btn-primary">Reset</button>
										<a href="expense_costing_list.php">
											<button type="button" class="btn btn-danger">Back</button></a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Sales chart -->
					<!-- ============================================================== -->
				</div>
				</form>
				<!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- End Wrapper -->
	<!-- ============================================================== -->
            <!-- footer -->
            <?php include('includes/footer.php');?>
            <!-- End footer -->
            <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
	<script type="text/javascript">
function sel_details(costing_id){
	$.ajax({
			url : 'ajax/costing.php',
			data: {
			   action: "get_cost_details",
			   costing_id: costing_id
			},
			success: function( data ) {
				//alert(data);
				data = data.split("~~");
				$('#order_no').val(data['0']);
				$('#style_no').val(data['1']);
				$('#buyer_name').val(data['2']);
				$('#order_date').val(data['0']);
			},
			error: function (textStatus, errorThrown) {
				//DO NOTHINIG
			}
		});
}

$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
	var actions = $("table td:last-child").html();
	// Append table with add row form on add new button click
    $(".add-new").click(function(){
	//	$(this).attr("disabled", "disabled");
		var index = $("table tbody tr:last-child").index();
        var row = '<tr>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Description"></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Composition"></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Proces loss"></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Rejection "></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Over Head"></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Courier & Forwarding"></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Profit"></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Commission"></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Convertion "></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Currency "></td>' +

        '</tr>';
    	$("table").append(row);
		$("table tbody tr").eq(index + 1).find(".add, .edit").toggle();
        $('[data-toggle="tooltip"]').tooltip();
    });
	// Add row on add button click
	$(document).on("click", ".add", function(){
		var empty = false;
		var input = $(this).parents("tr").find('input[type="text"]');
        input.each(function(){
		//	if(!$(this).val()){
		//		$(this).addClass("error");
		//		empty = true;
		//	} else{
        //        $(this).removeClass("error");
        //    }
		});
		$(this).parents("tr").find(".error").first().focus();
		if(!empty){
			input.each(function(){
				$(this).parent("td").html($(this).val());
			});
			$(this).parents("tr").find(".add, .edit").toggle();
			$(".add-new").removeAttr("disabled");
		}
    });
	// Edit row on edit button click
	$(document).on("click", ".edit", function(){
        $(this).parents("tr").find("td:not(:last-child)").each(function(){
			$(this).html('<input type="text" class="form-control" value="' + $(this).text() + '">');
		});
		$(this).parents("tr").find(".add, .edit").toggle();
		$(".add-new").attr("disabled", "disabled");
    });
	// Delete row on delete button click
	$(document).on("click", ".delete", function(){
        $(this).parents("tr").remove();
		$(".add-new").removeAttr("disabled");
    });
});
</script>
</body>
</html>