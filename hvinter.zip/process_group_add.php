<?php 
include('includes/config.php');
extract($_REQUEST);

if($_SESSION['userid']==''){
	echo "<script>window.location.href='login.php';</script>";
}
$action = 'process_group_add';
	$breadcrumb = 'Add';
	$sucessMsg = 'Process Group Added Successfully';
	if(isset($colid)){
		$sucessMsg = 'Process Group Updated Successfully';
		$action = 'process_group_edit';
		$breadcrumb = 'Edit';
		$edtColQry = "SELECT * FROM process_groups WHERE process_id='".$colid."'";
		$edtColResource = mysqli_query($zconn,$edtColQry);
		$colData = mysqli_fetch_array($edtColResource,MYSQLI_ASSOC);
		$colid = $colData['process_id'];
		$status = $colData['status'];
        $process_flow = $colData['process_flow'];
		$dept_flow = $colData['dept_flow'];
	}

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - Process Group add</title>
    <!-- Custom CSS -->
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper-->
        <div class="page-wrapper" style="min-height: 100%; height: auto;">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
             <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Process Group Add</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="process_group.php">Process Group Info</a>
									</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Sales chart -->
			<form name="supplier_info" id="supplier_info" method="post">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
							<div class="card-body">
							</div>
								<div class="card-body" style="width:100%">
									<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">Process Group Name</label>
										<div class="col-sm-3">
											<input type="text" class="form-control" id="size_grp_name" name="size_grp_name" placeholder="Process Group Name" autocomplete="off" value="<?php echo $colData['process_name'];?>">
										</div>
									</div>
									<div class="form-group row">
									<!-- <label for="lname" class="col-sm-3 text-right control-label col-form-label">Process Selection	</label> -->
    									<!-- <div class="col-sm-3" style="border:1px solid #000; border-radius:10px; margin:10px; padding:10px; overflow:scroll; height:300px; width:100px;">
    											<?php $sel_size = mysqli_query($zconn,"select * from department_master where status='0'");
    											while($res_size = mysqli_fetch_array($sel_size,MYSQLI_ASSOC)){
    												if($colid!=''){
    													$sel_sizes = explode(",",$colData['process_flow']);
    													$chk_checked='';
    													if(in_array($res_size['dept_name'],$sel_sizes)) {
    														$chk_checked='checked';
    													}
    												}
    											?>
    											<div class="col-sm-6" style="float:left;">
    												<input type="checkbox" name="chk_sizes[]" value="<?php echo $res_size['dept_name'];?>" <?php echo $chk_checked;?> style="float:left;">&nbsp;<?php echo $res_size['dept_name'];?>
											</div>
											<?php } ?>
										</div> -->			
									</div>

                    				<div class="form-group row">
                    					<div class="col-sm-3">
                    						<label for="lname" class="col-sm-12 text-right control-label col-form-label">Process Selection	</label>
                    					</div>	
                    					<div class="col-sm-3">
                    						<table id="example" class="table table-striped table-bordered">
                    		                	<thead style="background-color: #626F80; color: #fff; padding: 0px; font-size: 16px;">
                    				                <tr align="center" valign="middle">
                    				                    <th style="width:98%;">Process Name</th>
                    				                  
                    				                    <th style="width:2%;"><button type="button" class="btn btn-info add-new"><i class="fa fa-plus"></i></button></th>
                    				                </tr>
                    				            </thead>
                    				            <tbody>

	<?php
	if($colid!=''){ 
		$process_flow; 
		$explode=explode(",",$process_flow);
		foreach ($explode as $value) { ?>
		 <tr id="delete_0">
				<td>
					 <select class="select2 form-control custom-select"  name="chk_process[]">
						  <option value="<?php echo $value;?>"><?php echo $value;?></option> 
						   <option value="">Select</option>
						<?php
							$sel_yname = mysqli_query($zconn,"select * from process_master where status='0'");
									while($res_yname = mysqli_fetch_array($sel_yname,MYSQLI_ASSOC)){?>
								<option value="<?php echo $res_yname['process_name'];?>"><?php echo $res_yname['process_name'];?></option>
									<?php } ?>      
					</select>
				</td>
				<td>
					<a class="delete" title="Delete"><button type="button" class="btn btn-info add-new"><i class="fa fa-minus"></i></button></a>
				</td>
			</tr>
		 <?php }  }
	  else { ?>
		<tr id="delete_0">
			<td>
				<select class="select2 form-control custom-select"  name="chk_process[]">
					<option value="">Select</option>
						<?php
							$sel_yname = mysqli_query($zconn,"select * from process_master where status='0'");
									while($res_yname = mysqli_fetch_array($sel_yname,MYSQLI_ASSOC)){?>
								<option value="<?php echo $res_yname['process_name'];?>"><?php echo $res_yname['process_name'];?></option>
									<?php } ?>
				 </select>
			</td>
			 <td>
				 <a class="delete" title="Delete"><button type="button" class="btn btn-info add-new"><i class="fa fa-minus"></i></button></a>
			 </td>
		</tr>
	<?php } ?>
	</tbody> 
	</table>
	</div>
	</div>

	<div class="form-group row">
		<div class="col-sm-3">
			<label for="lname" class="col-sm-12 text-right control-label col-form-label">Department Selection</label>
		</div>
		<div class="col-sm-3">
			<table id="example1" class="table table-striped table-bordered">
				<thead style="background-color: #626F80; color: #fff; padding: 0px; font-size: 16px;">
					<tr align="center" valign="middle">
						<th style="width:98%;">Department Name</th>
						<th style="width:2%;"><button type="button" class="btn btn-info add-new1"><i class="fa fa-plus"></i></button></th>
					</tr>
				</thead>
				<tbody>

	<?php
	if($colid!=''){ 
		$process_flow; 
		$explode=explode(",",$dept_flow);
		foreach ($explode as $value) { ?>
		 <tr id="delete_0">
				<td>
					 <select class="select2 form-control custom-select"  name="chk_sizes[]">
						  <option value="<?php echo $value;?>"><?php echo $value;?></option> 
						   <option value="">Select</option>
						<?php
							$sel_yname = mysqli_query($zconn,"select * from department_master where status='0'");
									while($res_yname = mysqli_fetch_array($sel_yname,MYSQLI_ASSOC)){?>
								<option value="<?php echo $res_yname['dept_name'];?>"><?php echo $res_yname['dept_name'];?></option>
									<?php } ?>      
					</select>
				</td>
				<td>
					<a class="delete" title="Delete"><button type="button" class="btn btn-info add-new"><i class="fa fa-minus"></i></button></a>
				</td>
			</tr>
		 <?php }  }
	  else { ?>
		<tr id="delete_0">
			<td>
				<select class="select2 form-control custom-select"  name="chk_sizes[]">
					<option value="">Select</option>
						<?php
							$sel_yname = mysqli_query($zconn,"select * from department_master where status='0'");
									while($res_yname = mysqli_fetch_array($sel_yname,MYSQLI_ASSOC)){?>
								<option value="<?php echo $res_yname['dept_name'];?>"><?php echo $res_yname['dept_name'];?></option>
									<?php } ?>
				 </select>
			</td>
			 <td>
				 <a class="delete" title="Delete"><button type="button" class="btn btn-info add-new"><i class="fa fa-minus"></i></button></a>
			 </td>
		</tr>
	<?php } ?>
	</tbody> 
	</table>
	</div>
	</div>
					<div class="form-group row">
						<label for="email1" class="col-sm-3 text-right control-label col-form-label">Status</label>
						<div class="col-sm-6" style="margin-top:10px;">
						<input type="radio" id="stat-act"  value="0" <?php if(isset($colData['status'])){ if($colData['status']=='0'){ ?> checked <?php } }else{ ?> checked <?php } ?>  name="status" class="flat-red"> Active
						<input type="radio" id="stat-inact"  value="1" <?php if($colData['status']=='1'){ ?> checked <?php } ?> name="status" class="flat-red"> In Active
						</div>
					</div>
				</div>

							<div class="border-top">
								<div class="card-body" style="margin-left: 250px;">
									<button type="submit" class="btn btn-success">Save</button>
									<button type="submit" class="btn btn-primary">Reset</button>
									<a href="process_group.php"><button type="button" class="btn btn-danger">Back</button></a>
								</div>
							</div>
                        </div>
                    </div>
                </div>
				<input type="hidden" name="action" id="action" value="<?php echo $action ?>" />
	  <?php if(isset($colid)){ ?>
		<input type="hidden" name="colid" id="colid" value="<?php echo $colid ?>" />
	  <?php  } ?>
				</form>
                <!-- Sales chart -->
                <!-- ============================================================== -->
            </div>
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- End Wrapper -->
	<!-- ============================================================== -->
            <!-- footer -->
            <?php include('includes/footer.php');?>
            <!-- End footer -->
    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
      <?php
         $sel_yname = mysqli_query($zconn,"select * from department_master where status='0'");
         $ynamelist= '';
         while($res_yname = mysqli_fetch_array($sel_yname,MYSQLI_ASSOC)){
          $ynamelist .='<option value="'.$res_yname['dept_name'].'">'.$res_yname['dept_name'].'</option>';
          } 
		  
		  
		 $sel_pname = mysqli_query($zconn,"select * from process_master where status='0'");
         $prnamelist= '';
         while($res_pname = mysqli_fetch_array($sel_pname,MYSQLI_ASSOC)){
          $prnamelist .='<option value="'.$res_pname['process_name'].'">'.$res_pname['process_name'].'</option>';
          } 
          ?>
<script type="text/javascript">
		$(document).ready(function(){
			//$('.left-sidebar').slideToggle();
		});

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
    var actions = $("example").html();
    // Append table with add row form on add new button click
    $(".add-new").click(function(){
        var index = $("#example tbody tr:last-child").index();
        var newc = parseInt(index)+parseInt(1);
        var row = '<tr >' +
            '<td><select class="select2 form-control custom-select" id="chk_sizes'+newc+'" name="chk_process[]"><option>Select</option><?php echo $prnamelist;?></select></td>' +
            '<td><a class="delete" title="Delete" ><button type="button" class="btn btn-info add-new"><i class="fa fa-minus"></i></button></a></td>' +
        '</tr>';
        $("#example").append(row);
        $("#example tbody tr").eq(index + 1).find(".add, .edit").toggle();
        $('[data-toggle="tooltip"]').tooltip();
    });

	 $(".add-new1").click(function(){
        var index = $("#example1").index();
        var newc = parseInt(index)+parseInt(1);
        var row = '<tr >' +
            '<td><select class="select2 form-control custom-select" id="chk_sizes'+newc+'" name="chk_sizes[]"><option>Select</option><?php echo $ynamelist;?></select></td>' +
            '<td><a class="delete" title="Delete" ><button type="button" class="btn btn-info add-new"><i class="fa fa-minus"></i></button></a></td>' +
        '</tr>';
        $("#example1").append(row);
        $("#example1").eq(index + 1).find(".add, .edit").toggle();
        $('[data-toggle="tooltip"]').tooltip();
    });

    // Add row on add button click
    $(document).on("click", ".add", function(){
        var empty = false;
        var input = $(this).parents("tr").find('input[type="text"]');
        input.each(function(){
        });
        $(this).parents("tr").find(".error").first().focus();
        if(!empty){
            input.each(function(){
                $(this).parent("td").html($(this).val());
            });
            $(this).parents("tr").find(".add, .edit").toggle();
            $(".add-new").removeAttr("disabled");
            sum_grand();
        }
    });
    // Edit row on edit button click
    $(document).on("click", ".edit", function(){
        $(this).parents("tr").find("td:not(:last-child)").each(function(){
            $(this).html('<input type="text" class="form-control" value="' + $(this).text() + '">');
        });
        $(this).parents("tr").find(".add, .edit").toggle();
        $(".add-new").attr("disabled", "disabled");
        sum_grand();
    });
    // Delete row on delete button click
    $(document).on("click", ".delete", function(){
        $(this).parents("tr").remove();
        //$(".add-new").removeAttr("disabled");
        sum_grand();
    });
});
</script>
	<script>
	$(function () {
		$("form#supplier_info").submit(function(e) {
			e.preventDefault();
			var formData = new FormData(this);
			$.ajax({
				url: "ajax/products.php",
				type: 'POST',
				data: formData,
				success: function (data) {
				 //alert(data);
					if($.trim(data)=='1'){
						alert("<?php echo $sucessMsg; ?>");
						window.location.href="process_group.php";
					} 
					if($.trim(data)=='2'){
						alert("Size_group Name already exists!!");
					} 
					if($.trim(data)=='0'){
						alert("Query Failed");
					}
				},
				cache: false,
				contentType: false,
				processData: false
			});
		});
	 });
	 </script>

</body>
</html>