 <footer class="footer text-center" style="color: #000;">
                All Rights Reserved by <b style="color: #007eff;"><?php echo SITE_TITLE;?></b>. Designed and Developed by <a href="http://www.iorange.in/"><b style="color: orange;">IOrange Innovation</b></a>
			</footer>