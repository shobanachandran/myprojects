<?php 
include('includes/config.php');

if($_SESSION['userid']==''){
	echo "<script>window.location.href='login.php';</script>";
}

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - Duplicate DC</title>
    <!-- Custom CSS -->
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">    
</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <div class="page-wrapper" style="min-height: 100%; height: auto;">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
             <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Return DC View</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="#">Return DC View</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
			<div class="container-fluid">
			<div class="row-fluid sortable">
				<div class="box span12">
					<div class="box-header well" data-original-title>
						<h4><i class="icon-edit"></i>General Return DC Entry Form</h4>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content">
                    <form name="" action="" method="post">
					  <table class="table table-striped table-bordered" width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
						    <tr style="margin-top:25px;">
							    <th width="12%" height="35" align="center"  valign="top">Dc No</th>
					        <td width="29%" align="left" valign="top">
                            		<select name="dcno" data-rel="chosen" onchange="this.form.submit()">
                                    <option>----Select----</option>
                            			<?php 
										$sql=mysqli_query("SELECT DISTINCT(`prime_id`) as `prime_id`  FROM `general_dc` ");
										while($res_dc=mysqli_fetch_object($sql)){?>
                                        <option value="<?php echo $res_dc->prime_id;?>"<?php if($res_dc->prime_id == $_REQUEST['dcno']){?> selected="selected"<?php }?>><?php echo $res_dc->prime_id;?></option>
                                        <?php }?>
                                    </select>
							<?php $get_from_dc=mysqli_fetch_object(mysqli_query("SELECT *  FROM `general_dc` WHERE `prime_id` = '".$_REQUEST['dcno']."'"));
							    $to=$get_from_dc->company_name;
								$note=$get_from_dc->return_notes;
								
								$sq=mysqli_fetch_object(mysqli_query("SELECT * FROM  `master_supplier` WHERE  `customercode` = '$to' or `customername`='$to'"));
  $to1=$sq->customername;
  if($to1!=''){
  $to2=$to1;
  }
  else{
  $to2=$to;
  }
							
							
							
							
							?>
                            </td>
						      <td width="22%" align="center" valign="top"><strong>Date</strong></td>
							    <td width="37%" align="left" valign="middle"><?php echo date("d-m-Y",strtotime($get_from_dc->date));?></td>
					    </tr>
						    <tr>
							  <th height="35" align="center">Receive Date </th>                        
							  <td align="left"><input type="text" name="date" class="datepicker" value="<?php echo date("d-m-Y",strtotime($get_from_dc->return_date_org));?>" /></td>
							  <td align="center"><strong>To Address</strong></td>
							  <td width="37%" align="left" valign="top"><?php echo $to2;?></td>
					      </tr>
							<tr>
							  <th height="35" align="center" valign="top">Notes</th>                       
							  <td align="left"><textarea name="remarks" value="<?php echo $note;?>" cols="25" rows="7"><?php echo $note;?></textarea></td>
							  <td align="center" valign="top"><strong><div class="red1" style="display:none;">Return date</div>
							  Notes</strong></td>
							  <td width="37%" align="left" valign="top"><?php echo $get_from_dc->remarks;?></td>
				        </tr>
					  </table><br />
					   <table width="50%" border="1" align="center" cellpadding="0" cellspacing="0" id="tblPets">
					    <tr>
					      <th width="33%" height="32" align="center" valign="middle"><strong>Particular</strong></th>
					      <th width="49%" align="center" valign="middle"><strong>Qty</strong></th>
				         </tr>
                         <?php 
						 $sql_sql=mysqli_query("SELECT *  FROM `general_dc` WHERE `prime_id` = '".$_REQUEST['dcno']."'");
						 while($res_sql=mysqli_fetch_object($sql_sql)){?>
					    <tr>
					      <td height="29" align="center" valign="middle"><?php echo $res_sql->particular;?></td>
					      <td align="center" valign="middle"><?php echo $res_sql->qty; ?></td>
				         </tr>
                        <?php }?>
				      </table>
					 
					</form>
					</div>
				</div><!--/span-->
			
			</div>  	
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    <!-- End Wrapper -->
	<!-- ============================================================== -->
            <!-- footer -->
           <?php include('includes/footer.php');?>
            <!-- End footer -->
	</div>
	</div>
            <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    
</body>
</html>