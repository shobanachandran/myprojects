<?php
include('includes/config.php');

if($_SESSION['userid']==''){
    echo "<script>window.location.href='login.php';</script>";
}

if(isset($_REQUEST['save']))
{
    $count = count($_REQUEST['wgt']);

    for($i=0;$i<$count;$i++)
    { 
        if ($_REQUEST['wgt'][$i] > 0) {
            $wgt = $_REQUEST['wgt'][$i];
            $style = $_REQUEST['style'];
            $style1 = $_REQUEST['style1'];
            $id = $_REQUEST['id'][$i];
            $order_no = $_REQUEST['order_no'][$i];

            // Subtract stock from the source style
            $subtractQuery = "UPDATE `store_po_details`
                              SET `weight` = `weight` - $wgt
                              WHERE `styleno` = '$style1' AND `id` = '$id' AND `order_no` = '$order_no'";
            
            mysqli_query($zconn, $subtractQuery) or die(mysqli_error($zconn));

            // Add stock to the destination style
            $addQuery = "UPDATE `store_po_details`
                         SET `weight` = `weight` + $wgt
                         WHERE `styleno` = '$style1' AND `id` = '$id' AND `order_no` = '$order_no'";
            
            mysqli_query($zconn, $addQuery) or die(mysqli_error($zconn));

            // Insert the record into the accessories_inward table
            $insertQuery = "INSERT INTO `accessories_inward` (`po_no`, `style_no`, `order_no`, `wgt`, `roll`, `date`, `old_id`)
                            VALUES ('".$_REQUEST['po_no']."', '$style', '$order_no', '$wgt', '".$_REQUEST['roll'][$i]."', NOW(), '$id')";
            
            mysqli_query($zconn, $insertQuery) or die(mysqli_error($zconn));

            // Insert the record into the store_po_details table (assuming the columns match)
            $insertStoreQuery = "INSERT INTO `store_po_details` ( `po_id`, `styleno`, `order_no`, `weight`, `created_at`)
                                VALUES ( '".$_REQUEST['po_no']."', '$style1', '$order_no', '$wgt', NOW())";
            
            mysqli_query($zconn, $insertStoreQuery) or die(mysqli_error($zconn));
        }
    }

    echo("<script>alert('Store Inwarded Successfully');</script>");
}
?>


<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE; ?> - Store Style Transfer</title>
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php'); ?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php include('includes/sidebar.php'); ?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <div class="page-wrapper" style="min-height: 100%; height: auto;">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Store Style Transfer </h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="#">Expenses Costing Info</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <form name="accessories_inward" id="accessories_inward" method="post">
                    <!-- Sales chart -->
                    <div class="form-group row">
                        <label for="fname" class="col-sm-3 text-right control-label col-form-label">&nbsp;Style Code</label>
                        <div class="col-md-2">
                            <select class="select2 form-control custom-select chosen-select" name="style" id="style" onchange="$('#accessories_inward').submit();">
                                <option>Select</option>
                                <?php
                                $sel_po = mysqli_query($zconn, "select distinct styleno from store_po_details where status!='complete'");
                                while ($res_po = mysqli_fetch_array($sel_po, MYSQLI_ASSOC)) {
                                    if ($_REQUEST['style'] == $res_po['styleno']) { ?>
                                        <option selected value="<?php echo $res_po['styleno']; ?>"><?php echo $res_po['styleno']; ?></option>
                                    <?php } else { ?>
                                        <option value="<?php echo $res_po['styleno']; ?>"><?php echo $res_po['styleno']; ?> </option>
                                <?php }
                                } ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="fname" class="col-sm-3 text-right control-label col-form-label">&nbsp;Change to Style Code</label>
                        <div class="col-md-2">
                            <select class="select2 form-control custom-select" name="style1" id="style1" onchange="this.form.submit();">
                                <option value="0">Select</option>
                                <?php
                                $sel_buyer = mysqli_query($zconn, "select * from store_po_details  group by styleno");
                                while ($res_buyer = mysqli_fetch_array($sel_buyer, MYSQLI_ASSOC)) { ?>
                                    <option value="<?php echo $res_buyer['styleno']; ?>" <?php if ($res_buyer['styleno'] == $_REQUEST['style1']) { ?> 
                                        selected="selected" <?php } ?>><?php echo $res_buyer['styleno']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead style="background-color: #626F80; color: #fff; font-size: 16px;">
                                <tr>
                                    <th style="width: 10%">S.NO</th>
                                    <th style="width: 10%">Style No</th>
                                    <th style="width: 10%">order No</th>
                                    <th style="width: 3%" data-toggle="tooltip" title="Fabric Dia">NAME</th>
                                    <th style="width: 5%" data-toggle="tooltip" title="PLANNING Weight">TOTAL QTY</th>
                                    <th style="width: 5%" data-toggle="tooltip" title="PLANNING Weight">RECEIVED</th>
                                    <th style="width: 5%" data-toggle="tooltip" title="PLANNING Weight">DELEVERED </th>
                                    <th style="width: 10%">IN STOCK</th>
                                    <th style="width: 10%">TRANSFER QTY</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM store_po_details where styleno='" . $_REQUEST['style'] . "' ";

                                if (isset($_REQUEST['style']) && $_REQUEST['style'] != '0') {
                                    $query .= "and styleno in('" . $_REQUEST['style'] . "')";
                                }

                                $secBrnResource = mysqli_query($zconn, $query);
                                $sno = 1;
                                while ($coldata = mysqli_fetch_array($secBrnResource, MYSQLI_ASSOC)) {
                                    $id = $coldata['id'];
							$fetch=mysqli_fetch_object(mysqli_query($zconn,"select sum(wgt) as wgt,sum(roll) as roll from  accessories_inward where po_no='".$_REQUEST['po_no']."' and old_id=$id"));

                                    $fetch = mysqli_fetch_object(mysqli_query($zconn, "select sum(wgt) as wgt from  accessories_inward
                                    where style_no='" . $_REQUEST['style'] . "'  and old_id=$id"));

                                //     $sel_dc = mysqli_fetch_array(mysqli_query($zconn, "select * from accessories_dc_out where 
                                // style_no='" . $_REQUEST['style'] . "' and order_no='" . $_REQUEST['order'] . "' 
                                // "), MYSQLI_ASSOC);

                                //     if ($sel_dc['balance_wgt'] != '') {
                                //         $balance_wgt = $sel_dc['balance_wgt'];
                                //     }
                                ?>
                             <tr>
		<td style="width:2%"><?php echo $sno;?><input type="hidden" name="id[]" value="<?php echo $coldata['id'];?>"></td>
		<td style="width:10%"><?php echo $coldata['order_no'];?><input type="hidden" name="order_no[]" value="<?php echo $coldata['order_no'];?>"></td>
		<td style="width:10%"><?php echo $coldata['styleno'];?><input type="hidden" name="style_no[]" value="<?php echo $coldata['styleno'];?>"></td>
        <td style="width:7%"><?php echo $coldata['yarn_name'];?></td>
		<td style="width:7%"><?php echo $coldata['weight'];?></td>
		<td style="width:7%"><?php echo $fetch->wgt;?></td>
		<td style="width: 8%"><div class="col-sm-12">
			<input type="number" class="wgt form-control" id="" name=""  autocomplete="off" value="0"  readonly>
			</div>
		</td>
		<td style="width:3%"><?php echo $coldata['weight']-$fetch->wgt;?></td>
		<!-- <td style="width:6%"><div class="col-sm-12">
		<input type="text" class="rolls form-control" id="roll<?php echo $sno;?>" name="roll" autocomplete="off" onkeyup="cal_bags();">
		</div>
	</td> -->
		<td style="width: 8%"><div class="col-sm-12">
			<input type="number" class="wgt form-control" id="wgt" name="wgt[]"  autocomplete="off" onkeyup="cal_wgt();" >
			</div>
		</td>
	</tr>

	<?php
		$sno++;}
	?>

                            </tbody>
                            <tfoot>
                                <tr>
                                    <td style="width:2%"></td>
                                    <td style="width:10%"></td>
                                    <td style="width:10%"></td>
                                    <td style="width:7%"></td>
                                    <td style="width:7%"></td>
                                    <td style="width:7%"></td>
									<td style="width:7%"></td>
                                    <td style="width:3%"><b>Total</b></td>
                                    <td style="width: 8%">
                                        <div class="col-sm-12">
                                            <input type="text" class="form-control" id="tot_weight" name="total" autocomplete="off" required value="0">
                                        </div>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    <div class="card" style="width:100%">
                        <div class="border-top">
                            <div class="card-body" style="margin-left: 400px;">
                                <button type="submit" name="save" class="btn btn-success">Save</button>
                                <button type="reset" class="btn btn-primary">Reset</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <!-- End Container fluid -->
        </div>
        <!-- End Page wrapper -->
        <!-- ============================================================== -->
        <!-- footer -->
        <?php include('includes/footer.php'); ?>
        <!-- End footer -->
    </div>
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <script>
        function cal_bags() {
            var sum = 0;
            $('.rolls').each(function(index, element) {
                if ($(element).val() != "")
                    sum += parseFloat($(element).val());
            });
            $('#tot_bags').val(sum);
        }

        function cal_wgt() {
            var sum = 0;
            $('.wgt').each(function(index, element) {
                if ($(element).val() != "")
                    sum += parseFloat($(element).val());
            });
            $('#tot_weight').val(sum);
        }

        $(document).ready(function() {
            $('#example').DataTable();
        });

        function DeleteUsrId(ID) {
            var UsrStatus = confirm("Are you sure to delete this company details ?");
            if (UsrStatus) {
                $('#delete_' + ID).hide();
            }
        }

        $('#bill_date').datepicker({
            format: 'dd-mm-yyyy',
            autoclose: true
        });
    </script>
</body>

</html>