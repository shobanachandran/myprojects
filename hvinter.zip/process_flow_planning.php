<?php 
include('includes/config.php');
extract($_REQUEST);

	if($_SESSION['userid']==''){
		echo "<script>window.location.href='login.php';</script>";
	}

	if(isset($_REQUEST['save'])){
	   $sql0 = mysqli_query($zconn,"insert into `process_planning_flow`(order_no,style_no,process_flow,status)values('".$_REQUEST['order_no']."','".$_REQUEST['style_no']."','".$_REQUEST['process_name']."','0')");
	}

	if(isset($_REQUEST['update'])){
	   $sqlu = mysqli_query($zconn,"update `process_planning_flow` set order_no='".$_REQUEST['order_no']."',style_no='".$_REQUEST['style_no']."',process_flow='".$_REQUEST['process_name']."' where id='$id'");
	}

	if($sql0) {
	   echo "<script>alert('Added Successfully!!!');</script>";
	   echo "<script>window.location.href='prcocess_flow_planning_list.php';</script>";
	}

	if($sqlu) {
		echo "<script>alert('Updated Successfully!!!');</script>";
		echo "<script>window.location.href='prcocess_flow_planning_list.php';</script>";
	}

	$sql = mysqli_fetch_array(mysqli_query($zconn,"select * from `process_planning_flow` where id='".$id."'"),MYSQLI_ASSOC);

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - Add Planning Process Flow</title>
    <!-- Custom CSS -->
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">

    <link href="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.min.css" rel="stylesheet"/>
	<script src="dist/js/jquery.min.js"></script>
	<script src="dist/js/chosen.jquery.min.js"></script>
</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper-->
        <div class="page-wrapper" style="min-height: 100%; height: auto;">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
             <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Planning Process Flow</h4>
                        <h4 class="page-title"></h4> &nbsp;&nbsp;&nbsp;&nbsp;
						<a href="planning.php"> <button type="button" class="btn btn-info">Process Planning</button></a>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        <a href="planning.php">Planning</a>
									</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Sales chart -->
			<form name="supplier_info" id="supplier_info" method="post">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
							<div class="card-body"></div>
								<div class="card-body" style="width:100%">
									<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">Planning Indent No</label>
										<div class="col-sm-3">
											<select class="select2 form-control custom-select chosen-select"  name="order_no"  onchange="this.form.submit();">
                                                <option value="">Select</option>
													<?php
													$sel_yname = mysqli_query($zconn,"SELECT DISTINCT order_no, costing_no
                                                    FROM order_entry_master;
                                                    ");
													while($res_yname = mysqli_fetch_array($sel_yname,MYSQLI_ASSOC)){
														if($res_yname['order_no']==$sql['order_no']){ ?>
															<option selected="selected" value="<?php echo $res_yname['order_no'];?>"><?php echo $res_yname['order_no'];?>
															</option>
														<?php } else { ?>
															<option value="<?php echo $res_yname['order_no'];?>" <?php if($res_yname['order_no']==$_REQUEST['order_no']){ echo "selected"; }?>><?php echo $res_yname['order_no'];?>-(<?php echo $res_yname['costing_no'];?>)</option>
														<?php }  ?> 
														<?php } ?>
                                            </select>
                                           
										</div>
									</div>
                                    <div class="form-group row">
                                        <label for="fname" class="col-sm-3 text-right control-label col-form-label">Planning Style Code</label>
                                        <div class="col-sm-3">
                                            <select class="select2 form-control custom-select chosen-select" name="style_no">
                                                <option value="<?php echo $sql['style_no']; ?>"><?php echo $sql['style_no']; ?></option>
                                                <option value="">Select</option>
												<?php
													$sel_yname = mysqli_query($zconn,"select * from order_entry_master  where  order_no='".$_REQUEST['order_no']."'");
													while($res_yname = mysqli_fetch_array($sel_yname,MYSQLI_ASSOC)){?>
														<option value="<?php echo $res_yname['style_no'];?>"><?php echo $res_yname['style_no'];?>
														</option>
												 <?php } ?>
                                            </select>
                                            <script type="text/javascript">
												$(".chosen-select").chosen({
											  	no_results_text: "Oops, nothing found!"
												})
											</script>
                                        </div>
                                    </div>
                    				<div class="form-group row">
                    					<div class="col-sm-3">
                    						<label for="lname" class="col-sm-12 text-right control-label col-form-label">Select Flow Group</label>
                    					</div>
                    					<div class="col-sm-3">
                    						<select class="select2 form-control custom-select chosen-select"  name="process_name" id="process_name">
                                            <option value="">Select</option>
											<?php $sel_yname = mysqli_query($zconn,"select * from process_groups where status='0'");
											while($res_yname = mysqli_fetch_array($sel_yname,MYSQLI_ASSOC)){
											   if($res_yname['process_name']==$sql['process_flow']) {  ?>
												<option selected="selected"value="<?php echo $res_yname['process_name'];?>"><?php echo $res_yname['process_name'];?></option>
												<?php }  else {?>
												<option  value="<?php echo $res_yname['process_name'];?>"><?php echo $res_yname['process_name'];?></option>
												<?php } 
												}
												?>
                                            </select>
                                          
                                        </div>
                                        </div>

                                        <div class="form-group row">
                                        <div class="col-sm-3">
                                            <label for="lname" class="col-sm-12 text-right control-label col-form-label">Planning Flow</label>
                                        </div>  
                                        <div class="col-sm-3">
                                        <strong>
                                        <span id="process" name="process"><?php   $sql1 = mysqli_fetch_array(mysqli_query($zconn,"select * from process_groups where process_name='".$sql['process_flow']."'"),MYSQLI_ASSOC);
                                        echo $sql1['process_flow'];?>
                                        </span>
                                        </strong>
                                        </div>
                                        </div>
										<div class="form-group row">
											<div class="col-sm-3">
												<label for="lname" class="col-sm-12 text-right control-label col-form-label">Department Flow</label>
											</div>
											<div class="col-sm-3">
												<strong>
													<span id="deptflow" name="deptflow">
													<?php // $sql1 = mysqli_fetch_array(mysqli_query($zconn,"select * from process_groups where process_name='".$sql['process_flow']."'"),MYSQLI_ASSOC);
													echo $sql1['dept_flow'];?>
													</span>
												</strong>
											</div>
                                          
                                        </div>
								</div>
							<div class="border-top">
								<div class="card-body" style="margin-left: 250px;">
                                    <?php if(isset($id)){ ?>
										<button type="submit" class="btn btn-success" name="update">Update</button>
									<?php } else { ?>
										<button type="submit" class="btn btn-success" name="save">Save</button>
									<?php } ?>
										<button type="submit" class="btn btn-primary">Reset</button>
										<a href="prcocess_flow_planning_list.php"><button type="button" class="btn btn-danger">Back</button></a>
								</div>
							</div>
                        </div>
                    </div>
                </div>
				</form>
                <!-- Sales chart -->
                <!-- ============================================================== -->
            </div>
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- End Wrapper -->
	<!-- ============================================================== -->
            <!-- footer -->
            <?php include('includes/footer.php');?>
            <!-- End footer -->
	<!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
      <?php
        $sel_yname = mysqli_query($zconn,"select * from department_master where status='0'");
        $ynamelist= '';
        while($res_yname = mysqli_fetch_array($sel_yname,MYSQLI_ASSOC)){
			$ynamelist .='<option value="'.$res_yname['dept_name'].'">'.$res_yname['dept_name'].'</option>';
        } 
          ?>
    <script type="text/javascript">
$(document).ready(function(){
    //$('.left-sidebar').slideToggle();
});

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
    var actions = $("table td:last-child").html();
    // Append table with add row form on add new button click
    $(".add-new").click(function(){
        var index = $("table tbody tr:last-child").index();
        var newc = parseInt(index)+parseInt(1);
        var row = '<tr>' +
            '<td><select class="select2 form-control custom-select" id="chk_sizes'+newc+'" name="chk_sizes[]"><option>Select</option><?php echo $ynamelist;?></select></td>' +
            '<td><a class="delete" title="Delete" ><button type="button" class="btn btn-info add-new"><i class="fa fa-minus"></i></button></a></td>' +
        '</tr>';
        $("table").append(row);
        $("table tbody tr").eq(index + 1).find(".add, .edit").toggle();
        $('[data-toggle="tooltip"]').tooltip();
    });

    // Add row on add button click
    $(document).on("click", ".add", function(){
        var empty = false;
        var input = $(this).parents("tr").find('input[type="text"]');
        input.each(function(){
        });
        $(this).parents("tr").find(".error").first().focus();
        if(!empty){
            input.each(function(){
                $(this).parent("td").html($(this).val());
            });
            $(this).parents("tr").find(".add, .edit").toggle();
            $(".add-new").removeAttr("disabled");
            sum_grand();
        }
    });
    // Edit row on edit button click
    $(document).on("click", ".edit", function(){
        $(this).parents("tr").find("td:not(:last-child)").each(function(){
            $(this).html('<input type="text" class="form-control" value="' + $(this).text() + '">');
        });
        $(this).parents("tr").find(".add, .edit").toggle();
        $(".add-new").attr("disabled", "disabled");
        sum_grand();
    });
    // Delete row on delete button click
    $(document).on("click", ".delete", function(){
        $(this).parents("tr").remove();
        //$(".add-new").removeAttr("disabled");
        sum_grand();
    });
});
</script>

<script>
$(document).ready(function(){
	$("#process_name").change(function(){
	var process_name = document.getElementById('process_name').value;

	$.ajax({
		type:"POST",
		url:"ajax/planning_flow.php",
		data:{process_name:process_name},
		success:function(data1){
			data1 = data1.split("~~");
			 $("#process").html(data1['0']);
			 $("#deptflow").html(data1['1']);
		}
	 }); 
  });
});
</script>
<script type="text/javascript">
	$(document).bind("pageinit", function() {
    $(".chzn-select").chosen();
});

		$(".chosen-select").chosen({
		no_results_text: "Oops, nothing found!"
		})
	
		$(document).ready(function() {
			$(".chzn-select").chosen();

		$('#example').DataTable();
		});
	</script>


</body>
</html>