

<?php 
include('includes/config.php');
// extract($_REQUEST);
// if($_SESSION['userid']==''){
// 	echo "<script>window.location.href='login.php';</script>";
// }
// $action = 'usertypeadd';
// 	$breadcrumb = 'Add';
// 	$sucessMsg = 'User Type Added Successfully';
// 	if(isset($typeid)){
// 		$sucessMsg = 'User Type Updated Successfully';
// 		$action = 'usertypeedit';
// 		$breadcrumb = 'Edit';
// 		$edtUsrQry = "SELECT * FROM emp_salary WHERE id='".$typeid."'";
// 		$edtUsrResource = mysqli_query($zconn,$edtUsrQry);
// 		$usertypeData = mysqli_fetch_array($edtUsrResource,MYSQLI_ASSOC);
// 		$typeid = $usertypeData['id'];
// 		$emp_id = $usertypeData['emp_id'];
// 		$staff_id = $usertypeData['staff_id'];
//         $emp_amt = $usertypeData['emp_amt'];

// 	}
?>




<?php 
include('includes/config.php');

if($_SESSION['userid']==''){
	echo "<script>window.location.href='login.php';</script>";
}

$id=$_GET['id'];
if (isset($_REQUEST['save_fabric'])) {
//UPDATE `staff_salary` SET `id`=[value-1],`staff_id`=[value-2],`TYPEID`=[value-3],
 //`staff_name`=[value-4],`salary`=[value-5],`allowance`=[value-6],`created_at`=[value-7],`emp1_id`=[value-8] WHERE 1
$ins=mysqli_query($zconn,"update emp_salary set 
`staff_id`='".$_REQUEST['staff_id']."',`emp_id`='".$_REQUEST['emp_id']."',
`emp_amt`='".$_REQUEST['emp_amt']."' where id='$typeid'" );

if (isset($ins)) {
 echo '<script>alert("Staffs Salary update has been Sucessfully !!!")</script>';
 header('location:staffs_salary.php');
}
}
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - User</title>
    <!-- Custom CSS -->
	<!--  datatables CSS -->
    <link href="dist/css/bootstrap.css" rel="stylesheet">    
    <link href="dist/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet"> 
	<link rel="stylesheet" href="select2.css">
<link rel="stylesheet" href="select2-bootstrap.css">

<link href="dist/css/style.min.css" rel="stylesheet"> 
    <link href="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.min.css" rel="stylesheet"/>
	<script src="dist/js/jquery.min.js"></script>
	<script src="dist/js/chosen.jquery.min.js"></script>
	



</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
		 <?php  include('includes/header.php');?> 
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
		 <?php  include('includes/sidebar.php');?> 
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
             <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Salary Details</h4> &nbsp;&nbsp;&nbsp;&nbsp;
						<a href="accounts_master.php"> <button type="button" class="btn btn-info">Accounts Master</button></a>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">							
                                <ol class="breadcrumb">
									<!-- <li class="breadcrumb-item"><a href="employees_add..php"><button type="button" class="btn btn-success">Add</button></a></li> -->
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Sales chart -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
						<div class="card-body">
							<!-- accoridan part -->
                            <?php 
                $select=mysqli_query($zconn,"select * from staff_salary where id='".$typeid."'");
                while($dta=mysqli_fetch_object($select)){
                	$fabric_name=$dta->staff_id;
                	$style_no=$dta->emp_id;
                	// $orderno=$dta->order_no;
                	// $color=$dta->color;
                	// $dia=$dta->dia;
                	// $gsm=$dta->gsm;
                	// $order_qty=$dta->order_qty;
                	// $req_qty=$dta->req_qty;
                	// $total=$dta->total;
                }
                ?>
     		 <form name="" id="" method="post" enctype="multipart/form-data" action="">
     		 	<div class="box box-default">
     		 	  <div class="box-header with-border">
     		 	    <h3 class="box-title">Salary Details</h3>
     		 	    <div class="box-tools pull-right">
     		 	    </div>
     		  	 </div>
     		   <div class="box-body">
		 		 <div class="row">
		 			<div class="col-md-4">
		 			  <div class="form-group">
                       <?php
											$sectBrnQry = "SELECT * FROM department_master  where staff_id=$fabric_name";
											$secBrnResource = mysqli_query($zconn,$sectBrnQry);
											while($coldata = mysqli_fetch_array($secBrnResource,MYSQLI_ASSOC)){
											?>
											<label>Department</label>
												
													<select class="select2 form-control" name="staff_id">
														<option value="<?php echo $coldata['dept_name'];?>"><?php echo $coldata['dept_name'];?></option>
														<option>Select</option>
														<?php $select=mysqli_query($zconn,"select * from department_master where status='0' ");
														while($data=mysqli_fetch_array($select,MYSQLI_ASSOC)){
															?>
															<option value="<?php echo $data['dept_name']; ?>"><?php echo $data['dept_name']; ?></option>
														<?php } ?>
													</select>
                                                    <?php
												}
											?>
                      
		 										  </div>
				   </div>
			
					
          			<?php $typQuery = "SELECT staff_id,dept_name FROM department_master  WHERE staff_id='$fabric_name'";
										$typResource = mysqli_query($zconn,$typQuery);
										while($typdata = mysqli_fetch_array($typResource,MYSQLI_ASSOC)){ ?>
						<div class="col-md-6">
			 			 <div class="form-group">
								<label>Employee Name</label>
                                <?php
											$sectBrnQry = "SELECT * FROM employees  where emp_id=$style_no";
											$secBrnResource = mysqli_query($zconn,$sectBrnQry);
											while($coldata = mysqli_fetch_array($secBrnResource,MYSQLI_ASSOC)){
											?>
                                                  <select class="form-select2 form-control" name="emp_id">
														<option value="<?php echo $coldata['emp_name'];;?>"><?php echo $coldata['emp_name'];;?></option>
														<option>select</option>
														<?php $color=mysqli_query($zconn,"SELECT * FROM employees  where staff_id='$fabric_name' 
                                            ");
														while($codata=mysqli_fetch_array($color,MYSQLI_ASSOC)){?>
														<option value="<?php echo $codata['emp_name'];?>"><?php echo $codata['emp_name'];?></option>
													<?php } ?>
													</select>
                                                    <?php
												}
											?>
							     
			                    
					
					</div>

			    </div>

		     </div>

		      	<div class="row">
			        <div class="col-md-12">
			            <div class="form-group">

			                <div class="table-responsive">
									<table id="example" class="table table-striped table-bordered" style="width:100%">
										<thead style="background-color: #626F80; color: #fff; font-size: 16px;">
											<tr>
												<!-- <th></th> -->
												<th>S.NO</th>
												<th>DEPARTMMENT</th>
												<th>EMPLYOEE NAME</th>
												<th>SHIFT AMOUNT</th>
												<th>NEW SHIFT AMOUNT</th>

												
											</tr>
										</thead>
										<tbody> 
										<?php
								
                                         $sectBrnQry = "SELECT * FROM employees  where emp_id=$style_no";
                                        $secBrnResource = mysqli_query($zconn,$sectBrnQry);
                                        while($coldata1 = mysqli_fetch_array($secBrnResource,MYSQLI_ASSOC)){
                                        
									$secBrnResource = mysqli_query($zconn,"SELECT * FROM emp_salary where id=$typeid ");
									$ut=1;
									    while($coldata = mysqli_fetch_array($secBrnResource,MYSQLI_ASSOC)){
											
											?>
											<!--?php echo 'hello',$typdata['staff_id']; ?-->
											<tr>

											 <td><?php echo $ut; ?></td>
                                             <td><?php echo $typdata['dept_name'];?> 
											 <input type="hidden" name="staff_id" id="staff_id" 
                                             value="<?php echo $typdata['staff_id'];?>"></td>

											 <td><?php echo $coldata1['emp_name'];?>
											 <input type="hidden" name="emp1_id" id="emp1_id" 
											 value="<?php echo $coldata['emp_id'];?>">

											  <input type="hidden" name="emp_id" id="emp_id" 
                                              value="<?php echo $coldata['emp_id'];?>">
											</td>
											

												<td><?php echo $coldata1['emp_shiftamt'];?> <input type="hidden" name="emp_shiftamt[]" 
												id="emp_shiftamt" value="<?php echo $coldata['emp_shiftamt'];?>"></td>

												<td><input type="text" name="emp_amt" id="emp_amt" class=" form-control"  value="<?php echo  $coldata['emp_amt'];?>" /></td>

												<!-- <td><input type="text" name="now[]" id="now<?php echo $coldata['id'];?>" onkeyup="now_wanted(<?php echo $coldata['id'];?>)" class=" form-control now"  /></td> -->
												
												</tr>
																
																<?php
											
											$ut++; 	}
											?>	
										<!-- <tr>
											<td colspan="4">emp_amt</td>
											<td><input type="text" name="total_weight" id="total_weight" class=" form-control"  /></td>
										</tr> -->
										</tbody>
									</table>
								

								<?php } ?>
                                <?php } ?>
                                <?php// } ?>
							</div>			
			        </div>
		     </div>
	
        
    
			 

	   <div class="row">
			<div class="col-md-12">
				<div class="btn-group-vertical">
				  <button type="submit" name="save_fabric" tabindex="12"  class="btn btn-success">Save</button>
				</div>
				<div class="btn-group-vertical">
				  <button type="reset" tabindex="13" class="btn btn-danger">Reset</button>
				</div>
                <div class="btn-group-vertical">
                <a href="employee_salary.php"><button type="button" class="btn btn-danger">Back</button></a>

				</div>
			</div>
        </div>
      	<!-- </div> -->
	  	<input type="hidden" name="action" id="action" value="<?php echo $action ?>" />
	  	<?php if(isset($typeid)){ ?>
			<input type="hidden" name="typeid" id="typeid" value="<?php echo $typeid ?>" />
	  	<?php  } ?>
	    </form>
		

		</div>

                            </div>
                        </div>
                        </div>
                    </div>
                </div>


	     </div>
			


				</div>
                </div>
                <!-- Sales chart -->
                <!-- ============================================================== -->
            </div>
			

			
                <!-- Sales chart -->
                <!-- ============================================================== -->     
			</div>
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <?php  include('includes/footer.php');?>
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- End Wrapper -->
    <!-- ============================================================== -->
   <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
	<!--datatables JavaScript -->
    <script src="dist/js/jquery.dataTables.min.js"></script>
    <script src="dist/js/dataTables.bootstrap4.min.js"></script>
 <script>
    function sel_usertype(typeid){
        window.location.href='employees_salary_add.php?id='+typeid;
    }

    // $("#addAll").click(function(){
    //      $('.add_rows').not(this).prop('checked', this.checked);
    // });

    // $("#editAll").click(function(){
    //      $('.edit_rows').not(this).prop('checked', this.checked);
    // });

    //  $("#delAll").click(function(){
    //      $('.del_rows').not(this).prop('checked', this.checked);
    // });

    //  $("#viewAll").click(function(){
    //      $('.view_rows').not(this).prop('checked', this.checked);
    // });
    // $("#printAll").click(function(){
    //      $('.print_rows').not(this).prop('checked', this.checked);
    // });

</script>

<script>
		$(function () {
		$("form#usertypeInfo").submit(function(e) {
			//$('.loader').show();
			e.preventDefault();    
			var formData = new FormData(this);
			// if($('#bank_name').val()==''){
			// 	alert("Please enter Type Name");
			// 	$('#bank_name').focus();
			// 	//$('.loader').hide();
			// 	return false;
			// }
		//	$("#save").hide();
			$.ajax({
				url: "ajax/employees_salary.php",
				type: 'POST',
				data: formData,
				success: function (data) {
					// alert(data);
					// if($.trim(data)=="exist"){
					// 	alert("User Type name Already Exist");
					// 	$('.loader').hide();
					// }
					if($.trim(data)==true){
						alert("<?php echo $sucessMsg; ?>");
						<?php if(!isset($typeid)){ ?>
						document.getElementById("usertypeInfo").reset();
					   <?php } ?>
						//$('.loader').hide();
						window.location.href='employee_salary.php';
					}
					if($.trim(data)=="error"){
						alert("Process Failed Kindly. Try again");
						document.getElementById("usertypeInfo").reset();
						//$('.loader').hide();
					}
				},
				cache: false,
				contentType: false,
				processData: false
			});
		});
	 });
</script>

<script>
	


	 $('.now').keyup(function () {
		var sum = 0;
		$('.now').each(function() {
			sum += Number($(this).val());
		});
		$('#total_weight').val(sum);
	});


	</script>
 

</body>
</html>