<style>
    .footer {
        position: fixed;
        bottom: 0;
        background-color: white;
        text-align: center;
        color: #000;
        padding: 10px;
        border-top: 1px solid #ccc;
        width: 100%; /* Ensure the width spans the entire viewport */
        /* Set both left and right placement in pixels */
        left: 130px; /* Adjust this value for left placement */
        right: 20px; /* Adjust this value for right placement */
    }
</style>

<footer class="footer">
    All Rights Reserved by <b style="color: #007eff;"><?php echo SITE_TITLE;?></b>. Designed and Developed by <a href="http://www.iorange.in/"><b style="color: orange;">IOrange Innovation</b></a>
</footer>






