<?php 
include('includes/config.php');

if($_SESSION['userid']==''){
	echo "<script>window.location.href='login.php';</script>";
}

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - Labour Report 	</title>
    <!-- Custom CSS -->
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">    
</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <div class="page-wrapper" style="min-height: 100%; height: auto;">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
             <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Labour Report </h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="#">Labour Report </a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
			<div class="container-fluid">               
                <!-- ============================================================== -->
                <!-- Sales chart -->
                <div class="box-content">
                    
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
	<tr>
    	<td height="52" align="center" valign="middle">
        <form id="non-printable" name="form1" method="post" action="">
        	<div>Filter Department&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        	  <select name="dept" onchange="this.form.submit()" >
              					  <option value="All" selected="selected">All</option>
                                  <option value="Cutting" <? if($dept=='Cutting'){?> selected="selected"<? }?>>Cutting</option>
                                  <option value="Power" <? if($dept=='Power'){?> selected="selected"<? }?>>Power Table</option>
                                  <option value="Singer" <? if($dept=='Singer'){?> selected="selected"<? }?>>Singer </option>
                                  <option value="Ironing" <? if($dept=='Ironing'){?> selected="selected"<? }else{}?>>Ironing & packing</option>
                                  <option value="Checking" <? if($dept=='Checking'){?> selected="selected"<? }?>>Checking</option>
                                  <option value="Printing" <? if($dept=='Printing'){?> selected="selected"<? }?>>Printing</option>
                                  <option value="Embroidery" <? if($dept=='Embroidery'){?> selected="selected"<? }?>>Embroidery</option>
                                  <option value="Sticker" <? if($dept=='Sticker'){?> selected="selected"<? }?>>Sticker</option>
                                  <option value="Fusing" <? if($dept=='Fusing'){?> selected="selected"<? }?>>Fusing</option>
                                  <option value="Stone" <? if($dept=='Stone'){?> selected="selected"<? }?>>Stone</option>
                                  <option value="Sequence" <? if($dept=='Sequence'){?> selected="selected"<? }?>>Sequence</option>
                                  <option value="Kaja_button"<? if($dept=='Kaja_button'){?> selected="selected"<? }?>>Kaja Button</option>
                                  <option value="rope"<? if($dept=='rope'){?> selected="selected"<? }?>>Rope</option>
                                  <option value="dye_and_dye"<? if($dept=='dye_and_dye'){?> selected="selected"<? }?>>Dye and Dye</option>
                                  <option value="shaping"<? if($dept=='shaping'){?> selected="selected"<? }?>>Shaping</option>
                                  <option value="cutting_sticker"<? if($dept=='cutting_sticker'){?> selected="selected"<? }?>>Cutting Sticker</option>
                                  <option value="embroidery_applique"<? if($dept=='embroidery_applique'){?> selected="selected"<? }?>>Embroidery Applique</option>
                                  <option value="sublimation_printing"<? if($dept=='sublimation_printing'){?> selected="selected"<? }?>>Sublimation Printing</option>
                                  <option value="bow"<? if($dept=='bow'){?> selected="selected"<? }?>>Bow</option>
                                  <option value="others"<? if($dept=='others'){?> selected="selected"<? }?>>Others</option>
                                  <option value="final_checking"<? if($dept=='final_checking'){?> selected="selected"<? }?>>Final Checking</option>
								   <option value="panel_checking"<? if($dept=='panel_checking'){?> selected="selected"<? }?>>Panel Checking</option>
								   
								   <option value="washing"<? if($dept=='washing'){?> selected="selected"<? }?>>Washing</option>
                </select>
        	</div>
        </form>    	</td>
     </tr>
     <tr>
    <td align="center" valign="middle"><table width="100%" border="1" cellspacing="0" cellpadding="0">
    <? $total_cutting=''; $advance_cutting=''; $tota='';$conta='';
        $select=mysql_query("SELECT * FROM `cutting_workdone` WHERE `status`='unpaid'");
		if(mysql_num_rows($select)!==0)
		{
		?>
      <tr>
       <td width="75%"  align="center" valign="middle"><? if($dept=='All' or $dept=='Cutting'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Cutting</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'Cutting'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `cutting_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `cutting_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `cutting_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color' and `status`='unpaid' and `total` != '0'");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `cutting_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select cuttingrs as ra, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ra']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                  <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
				  ?>
                  <a href='contractorsalary_accounts.php?dept=cutting&contid=<?php echo $id;?>&go='>Send To Approval</a>
                 <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$cutting_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	  </tr>
        <?
		}
        $select=mysql_query("SELECT * FROM `power_workdone` WHERE  `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{
		?>
        <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='Power'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Power Table</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'Power'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `power_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `power_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `power_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid'  and `total` != '0'");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `power_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select powertablers as ra, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ra']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  persondetail WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=power&contid=<?=$id?>&go='>Send To Approval</a>
                <?php }?>  
                </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$power_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}
		
		
		$select=mysql_query("SELECT * FROM `inhouse_department_workdone` WHERE  `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{
		?>
        <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='inhouse_department'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Inhouse Department Table</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'inhouse_department'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `inhouse_department_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `inhouse_department_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `inhouse_department_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid'  and `total` != '0'");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `inhouse_department_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select inhousers as ra, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ra']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  persondetail WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=power&contid=<?=$id?>&go='>Send To Approval</a>
                <?php }?>  
                </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$inhouse_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}
		
		
        $select=mysql_query("SELECT * FROM `singer_workdone` WHERE `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{
		?>
        <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='Singer'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Singer</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'Singer'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `singer_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `singer_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `singer_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `singer_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select singers as ra, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ra']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                <a href='contractorsalary_accounts.php?dept=singer&contid=<?=$id?>&go='>Send To Approval</a>
                <?php }?>
                </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$siger_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}
        $select=mysql_query("SELECT * FROM `checking_workdone` WHERE `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{
		?>
         <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='Checking'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Checking</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'Checking'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `checking_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `checking_workdone` WHERE `id`='$id' and  `status`='unpaid' and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `checking_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `checking_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select checkingrs as ra, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ra']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=checking&contid=<?=$id?>&go='>Send To Approval</a>
                <?php }?>  
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$checking_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}
        $select=mysql_query("SELECT * FROM `printing_workdone` WHERE  `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{
		?>
         <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='Printing'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Printing</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'Printing'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `printing_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `printing_workdone` WHERE `id`='$id' and  `status`='unpaid' and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `printing_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `printing_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select printingrs as ra, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ra']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                  <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=printing&contid=<?=$id?>&go='>Send To Approval</a>
                  <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$printing_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}
        $select=mysql_query("SELECT * FROM `embroid_workdone` WHERE `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{
		?>
         <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='Embroidery'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
              <tr>
                <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Embroidery</strong></h2></td>
                </tr>
              <tr>
                <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
                <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
                <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
                <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
                <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
                <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
                <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
                <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
                </tr>
              <? {
              $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'Embroidery'");
            while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
                $sqll=mysql_query("SELECT DISTINCT(id)FROM  `embroid_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
                while($ids=mysql_fetch_object($sqll))
                {
                    $id=$ids->id;
                    $sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `embroid_workdone` WHERE `id`='$id' and  `status`='unpaid' and `total` != '0'");
                    while($sala=mysql_fetch_object($sal))
                    {
                        $style=$sala->styleno;
                        $color=$sala->color_name;
                        $sqaa=mysql_query("select SUM(total)as total from `embroid_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
                        while($sqlaa=mysql_fetch_object($sqaa))
                        $total=$sqlaa->total;
              ?>
                          <tr>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                            while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                              <? echo($n);?></td>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `embroid_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select embroidrs as ra, buyername from product where `styleno`='$style'"); 
                            while($rates=mysql_fetch_array($rate))
                            {
                                 $r=$rates['ra']; 
                                 $buyer=$rates['buyername'];
                            }
                            echo($buyer);?></td>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                            </tr>
                            <? }?>
                      <?
                    $advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
                        if(mysql_num_rows($advance1)=='0'){
                        $advance='0';
                        }
                        else{
                        $advance2=mysql_fetch_object($advance1);
                        
                        $advance=$advance2->advance;
                        }
                    $total_cutting+=$conta; ?>
                <tr bgcolor="#FFFFFF">
                      <td colspan='6' align='center'><strong>
                      <?php
               		 $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
					 if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			         ?>
                      <a href='contractorsalary_accounts.php?dept=embroidery&contid=<?=$id?>&go='>Send To Approval</a>
	                <?php } ?>
                      </strong></td>
                      <td align='right' height='35'><strong>Total Amount</strong></td>
                      <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
                      <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
                      <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
                      <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
                      <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$embroidery_grand+=$totaladvacen;?></strong></td>
                      </tr>
                    
                <?	$advance_cutting+=$advance;
                 }
                }
                }
              ?>
            </table><? }?></td>
	    </tr>
		
		
		
		
		
		
		
		<?php
		}
		
		$select=mysql_query("SELECT * FROM `panel_checking_workdone` WHERE `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{
		?>
         <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='panel_checking'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
              <tr>
                <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Panel Checking</strong></h2></td>
                </tr>
              <tr>
                <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
                <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
                <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
                <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
                <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
                <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
                <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
                <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
                </tr>
              <? {
              $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'panel_checking'");
            while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
                $sqll=mysql_query("SELECT DISTINCT(id)FROM  `panel_checking_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
                while($ids=mysql_fetch_object($sqll))
                {
                    $id=$ids->id;
                    $sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `panel_checking_workdone` WHERE `id`='$id' and  `status`='unpaid' and `total` != '0'");
                    while($sala=mysql_fetch_object($sal))
                    {
                        $style=$sala->styleno;
                        $color=$sala->color_name;
                        $sqaa=mysql_query("select SUM(total)as total from `panel_checking_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
                        while($sqlaa=mysql_fetch_object($sqaa))
                        $total=$sqlaa->total;
              ?>
                          <tr>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                            while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                              <? echo($n);?></td>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `panel_checking_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select panelcheckers as pc, buyername from product where `styleno`='$style'"); 
                            while($rates=mysql_fetch_array($rate))
                            {
                                 $pc=$rates['pc']; 
                                 $buyer=$rates['buyername'];
                            }
                            echo($buyer);?></td>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($pc);	?></td>
                            <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$pc;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                            </tr>
                            <? }?>
                      <?
                    $advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
                        if(mysql_num_rows($advance1)=='0'){
                        $advance='0';
                        }
                        else{
                        $advance2=mysql_fetch_object($advance1);
                        
                        $advance=$advance2->advance;
                        }
                    $total_cutting+=$conta; ?>
                <tr bgcolor="#FFFFFF">
                      <td colspan='6' align='center'><strong>
                      <?php
               		 $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
					 if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			         ?>
                      <a href='contractorsalary_accounts.php?dept=panel_checking&contid=<?=$id?>&go='>Send To Approval</a>
	                <?php } ?>
                      </strong></td>
                      <td align='right' height='35'><strong>Total Amount</strong></td>
                      <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
                      <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
                      <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
                      <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
                      <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$panel_checking_grand+=$totaladvacen;?></strong></td>
                      </tr>
                    
                <?	$advance_cutting+=$advance;
                 }
                }
                }
              ?>
            </table><? }?></td>
	    </tr>
		
		
		
		
		
		
		
		
		
		
        <?
		}
        $select=mysql_query("SELECT * FROM `stricker_workdone` WHERE  `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{
		?>
         <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='Sticker'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Sticker</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'Sticker'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `stricker_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `stricker_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `stricker_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `stricker_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select strickerrs as ra, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ra']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=sticker&contid=<?=$id?>&go='>Send To Approval</a>
                <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$sticker_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}
		
		$select=mysql_query("SELECT * FROM `dye_and_dye_workdone` WHERE  `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{
		?>
        <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='dye_and_dye'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Dye And Dye</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'dye_and_dye'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `dye_and_dye_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `dye_and_dye_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `dye_and_dye_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid'  and `total` != '0'");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `power_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select dyers as ra, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ra']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  persondetail WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=dye_and_dye&contid=<?=$id?>&go='>Send To Approval</a>
                  <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$dye_and_dye_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}

        $select=mysql_query("SELECT * FROM `fusing_workdone` WHERE  `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{
		?>
         <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='Fusing'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Fusing</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'Fusing'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `fusing_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `fusing_workdone` WHERE `id`='$id' and  `status`='unpaid' and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `fusing_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `fusing_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select fusingrs as ra, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ra']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=fusing&contid=<?=$id?>&go='>Send To Approval</a>
                  <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$fusing_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}
        $select=mysql_query("SELECT * FROM `stone_workdone` WHERE `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{
		?>
         <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='Stone'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Stone</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'stone'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `stone_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `stone_workdone` WHERE `id`='$id' and  `status`='unpaid' and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `stone_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `stone_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select stoners as ra, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ra']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                  <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=stone&contid=<?=$id?>&go='>Send To Approval</a>
                 <?php }?> 
                 </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$stone_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
         <?
		}
        $select=mysql_query("SELECT * FROM `sequence_workdone` WHERE  `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{
		?>
         <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='Sequence'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Sequence</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'Sequence'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `sequence_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `sequence_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `sequence_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `sequence_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select sequences as ra, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ra']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                  <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=sequence&contid=<?=$id?>&go='>Send To Approval</a>
                  <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$sequence_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}
		$select=mysql_query("select * from `kajabutton_workdone` where `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{?>
        <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='Kaja_button'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Kaja Button</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'kajabutton'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `kajabutton_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `kajabutton_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `kajabutton_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `kajabutton_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select kajars as ra, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ra']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                  <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=kajabutton&contid=<?=$id?>&go='>Send To Approval</a>
                  <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$kajabutton_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}




$select=mysql_query("select * from `rope_workdone` where `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{?>
        <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='rope'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Rope</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'rope'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `rope_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `rope_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `rope_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `rope_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select ropers as ra, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ra']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                  <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=rope&contid=<?=$id?>&go='>Send To Approval</a>
                  <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$rope_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}




$select=mysql_query("select * from `shaping_workdone` where `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{?>
        <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='shaping'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Shaping</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'shaping'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `shaping_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `shaping_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `shaping_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `shaping_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select shapers as sh, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['sh']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                  <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=shaping&contid=<?=$id?>&go='>Send To Approval</a>
                  <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$shaping_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}


		
		
		
		$select=mysql_query("select * from `cutting_sticker_workdone` where `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{?>
        <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='cutting_sticker'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Cutting Sticker</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'cutting_sticker'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `cutting_sticker_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `cutting_sticker_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `cutting_sticker_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `cutting_sticker_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select cutting_stickers as cs, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['cs']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                  <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=cutting_sticker&contid=<?=$id?>&go='>Send To Approval</a>
                  <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$cuttsticker_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}

		
		
		
		$select=mysql_query("select * from `embroidery_applique_workdone` where `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{?>
        <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='embroidery_applique'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Cutting Sticker</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'embroidery_applique'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `embroidery_applique_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `embroidery_applique_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `embroidery_applique_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `embroidery_applique_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select embroidery_appliquiers as em, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['em']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                  <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=embroidery_applique&contid=<?=$id?>&go='>Send To Approval</a>
                  <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$embapplique_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}
		
		
		
		
		
		
		
		
		$select=mysql_query("select * from `sublimation_printing_workdone` where `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{?>
        <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='sublimation_printing'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Sublimation
			Printing</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'sublimation_printing'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `sublimation_printing_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `sublimation_printing_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `sublimation_printing_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `sublimation_printing_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select sublimation_printers as sp, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['sp']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                  <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=sublimation_printing&contid=<?=$id?>&go='>Send To Approval</a>
                  <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$subprinter_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}
		
		
			$select=mysql_query("select * from `bow_workdone` where `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{ echo "true"; ?>
        <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='bow'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Bow</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'bow'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `bow_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `bow_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `bow_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `bow_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select bowers as bo, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['bo']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                  <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=bow&contid=<?=$id?>&go='>Send To Approval</a>
                  <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$bow_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}
		
		
		
		
		
	
		
		
		
		$select=mysql_query("select * from `others_workdone` where `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{?>
        <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='others'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Others</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'others'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `others_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `others_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `others_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `others_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select others as ot, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ot']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                  <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=others&contid=<?=$id?>&go='>Send To Approval</a>
                  <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$others_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}
		
		
		
		
			
		
		$select=mysql_query("select * from `final_checking_workdone` where `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{?>
        <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='final_checking'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Final Checking</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'final_checking'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `final_checking_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `final_checking_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `final_checking_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `final_checking_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select final_checkers as fc, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['fc']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                  <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=final_checking&contid=<?=$id?>&go='>Send To Approval</a>
                  <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$fincheck_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        
		
		
		<?
		}
		
		
		
		
			
		
		$select=mysql_query("select * from `washing_workdone` where `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{
		?>
        <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='washing'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Washing</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'washing'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `washing_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `washing_workdone` WHERE `id`='$id' and  `status`='unpaid'  and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `washing_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `washing_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select washers as ws, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ws']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                  <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=washing&contid=<?=$id?>&go='>Send To Approval</a>
                  <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$washing_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <?
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		



        $select=mysql_query("SELECT * FROM `iron_workdone` WHERE `status`='unpaid'");
		if(mysql_num_rows($select)!=0)
		{
		?>
        <tr>
        <td width="75%" align="center" valign="middle"><? if($dept=='All' or $dept=='Ironing'){?><table width="100%" height="95" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="39" colspan="9" align="center" valign="middle" bgcolor="#CCCCCC"><h2><strong>Department: Ironing & packing</strong></h2></td>
            </tr>
          <tr>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Contractors ID</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Date</strong></td>
            <td width="11%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Style No</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Buyer</strong></td>
            <td width="12%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Color </strong></td>
            <td width="14%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Total Pcs</strong></td>
            <td width="13%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Per Rate</strong></td>
            <td width="15%" align="center" valign="middle" bgcolor="#AFBEBC"><strong>Amount</strong></td>
            </tr>
          <? {
		  $person_detaklss=mysql_query("SELECT * FROM  `persondetail` WHERE  `unit` !=  'jobwork' AND  `possion` =  'Contractor' AND  `dept` =  'Ironing & packing'");
		while($person_detaklss_row=mysql_fetch_object($person_detaklss)){
			$sqll=mysql_query("SELECT DISTINCT(id)FROM  `iron_workdone` WHERE  `status`='unpaid' and `id`='$person_detaklss_row->id'");
			while($ids=mysql_fetch_object($sqll))
			{
				$id=$ids->id;
				$sal=mysql_query("SELECT DISTINCT(styleno),(color_name) FROM  `iron_workdone` WHERE `id`='$id' and  `status`='unpaid' and `total` != '0'");
				while($sala=mysql_fetch_object($sal))
				{
					$style=$sala->styleno;
					$color=$sala->color_name;
					$sqaa=mysql_query("select SUM(total)as total from `iron_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");
					while($sqlaa=mysql_fetch_object($sqaa))
					$total=$sqlaa->total;
		  ?>
                      <tr>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $nam=mysql_query("select name from `persondetail` where `id`='$id'");
                        while($name=mysql_fetch_object($nam)){$n=$name->name;} ?>
                          <? echo($n);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $sqaa=mysql_query("select * from `iron_workdone` WHERE `id`='$id'  and `styleno`='$style' and `color_name`='$color'and `status`='unpaid' ");$sqlaa=mysql_fetch_object($sqaa);	echo date("d-m-Y",strtotime($sqlaa->date));?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($style);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $rate=mysql_query("select ironingrs as ra, buyername from product where `styleno`='$style'"); 
                        while($rates=mysql_fetch_array($rate))
                        {
                             $r=$rates['ra']; 
                             $buyer=$rates['buyername'];
                        }
                        echo($buyer);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($color);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($total);?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? echo($r);	?></td>
                        <td align="center" valign="middle" bgcolor="#FFFFFF"><? $amou=$total*$r;echo($amou); $tota+=$amou; $conta+=$amou;?></td>
                        </tr>
						<? }?>
	          	  <?
				$advance1=mysql_query("SELECT * FROM  `persondetail` WHERE  `id` =  '$id'");
					if(mysql_num_rows($advance1)=='0'){
					$advance='0';
					}
					else{
					$advance2=mysql_fetch_object($advance1);
					
					$advance=$advance2->advance;
					}
				$total_cutting+=$conta; ?>
			<tr bgcolor="#FFFFFF">
				  <td colspan='6' align='center'><strong>
                  <?php
                $dummy_cont_mysql_num=mysql_query("SELECT * FROM `dummy_contractor` WHERE `contid` = '$id' AND `status` IN ('pending','show') ORDER BY `id` ASC");
				if(mysql_num_rows($dummy_cont_mysql_num) == '0'){
  			    ?>
                  <a href='contractorsalary_accounts.php?dept=ironing&contid=<?=$id?>&go='>Send To Approval</a>
                  <?php }?>
                  </strong></td>
				  <td align='right' height='35'><strong>Total Amount</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><? echo($conta);$totaladvacen=$conta-$advance; $conta="";?></strong></td>
				  <tr bgcolor='#FFFFFF'><td align='right' height='35' colspan='7'><strong>Advance</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$advance?></strong></td></tr>
				  <tr bgcolor='#FFFFFF'><td  height='35' colspan='7' align='right'><strong>Total Salary</strong></td>
				  <td align='center' valign='middle' bgcolor='#20CAAF'><strong><?=$totaladvacen;$ironing_grand+=$totaladvacen;?></strong></td>
                  </tr>
				
			<?	$advance_cutting+=$advance;
			 }
			}
			}
		  ?>
        </table><? }?></td>
	    </tr>
        <tr>
          <td align="center" valign="middle"><table width="50%" border="0" cellpadding="5" cellspacing="5">
            <tr>
              <td width="28%" height="35" align="right"><strong>Cutting</strong></td>
              <td width="4%" align="center">&nbsp;</td>
              <td width="18%" align="left" valign="middle"><?=$cutting_grand;$final_grand+=$cutting_grand;?></td>
              <td width="31%" height="35" align="right"><strong>Sticker</strong></td>
              <td width="5%" align="center">&nbsp;</td>
              <td width="14%" align="left" valign="middle"><?=$sticker_grand;$final_grand+=$sticker_grand;?></td>
            </tr>
            <tr>
              <td height="35" align="right"><strong>Singer</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$siger_grand;$final_grand+=$siger_grand;?></td>
              <td height="35" align="right"><strong>Fusing</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$fusing_grand;$final_grand+=$fusing_grand;?></td>
            </tr>
            <tr>
              <td height="35" align="right"><strong>Power Table</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$power_grand;$final_grand+=$power_grand;?></td>
              <td height="35" align="right"><strong>Stone</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$stone_grand;$final_grand+=$stone_grand;?></td>
            </tr>
            <tr>
              <td height="35" align="right"><strong>Checking</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$checking_grand;$final_grand+=$checking_grand;?></td>
              <td height="35" align="right"><strong>Sequence</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$sequence_grand;$final_grand+=$sequence_grand;?></td>
            </tr>
            <tr>
              <td height="35" align="right"><strong>Printing</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$printing_grand;$final_grand+=$printing_grand;?></td>
              <td height="35" align="right"><strong>Kaja Button</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$kajabutton_grand;$final_grand+=$kajabutton_grand;?></td>
            </tr>
            <tr>
              <td height="35" align="right"><strong>Embroidery</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$embroidery_grand;$final_grand+=$embroidery_grand;?></td>
              <td height="35" align="right"><strong>Dye and Dye</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$dye_and_dye_grand;$final_grand+=$dye_and_dye_grand;?></td>
            </tr>
            <tr>
              
              <td height="35" align="right"><strong>Ironing Packing</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$ironing_grand;$final_grand+=$ironing_grand;?></td>
			  <td height="35" align="right"><strong>Rope</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$rope_grand;$final_grand+=$rope_grand;?></td>
            </tr>

			
			
			 <tr>
              
              <td height="35" align="right"><strong>Shaping</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$shaping_grand;$final_grand+=$shaping_grand;?></td>
			  <td height="35" align="right"><strong>Cutting Sticker</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$cuttsticker_grand;$final_grand+=$cuttsticker_grand;?></td>
            </tr>
			
			
			 <tr>
              
              <td height="35" align="right"><strong>Embroidery Applique</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$embapplique_grand;$final_grand+=$embapplique_grand;?></td>
			  <td height="35" align="right"><strong>Sublimation Printing</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$subprinter_grand;$final_grand+=$subprinter_grand;?></td>
            </tr>
			
			 <tr>
              
              <td height="35" align="right"><strong>Bow</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$bow_grand;$final_grand+=$bow_grand;?></td>
			  <td height="35" align="right"><strong>Others</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$others_grand;$final_grand+=$others_grand;?></td>
            </tr>
			
			<tr>
              
              <td height="35" align="right"><strong>Final Checking</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$fincheck_grand;$final_grand+=$fincheck_grand;?></td>
              <td height="35" align="right">Panel Checking</td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$panel_checking_grand;$final_grand+=$panel_checking_grand;?></td>
            </tr>
			
			
			<tr>
              
              <td height="35" align="right"><strong>Washing</strong></td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$washing_grand;$final_grand+=$washing_grand;?></td>
              <td height="35" align="right">&nbsp;</td>
              <td align="center">&nbsp;</td>
              <td align="left" valign="middle"><?=$washing_grand;$final_grand+=$washing_grand;?></td>
            </tr>
			
			
			
			
			
			
			
			
			
            <tr>
              <td height="35" align="right">&nbsp;</td>
              <td align="center">&nbsp;</td>
              <td colspan="2" align="left" valign="middle"><h2>Grand Total</h2></td>
              <td align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle"><?=$final_grand;?></td>
            </tr>
          </table></td>
        </tr>
		  <?
          }
          ?>
    </table></td>
  </tr>
  <tr>
    <td align="right" valign="middle">&nbsp;</td>
  </tr>
</table>  
</div>
				</div>
    </div>
    <!-- End Wrapper -->
	<!-- ============================================================== -->
            <!-- footer -->
            <?php include('includes/footer.php');?>
            <!-- End footer -->
            <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    
</body>
</html>