<div class="row">
	<div class="col-12">
<table border="0" cellpadding="0" cellspacing="0" class="MsoNormalTable" style="border-collapse: collapse; margin-left: 4.65pt; width: 481px;">
 <tbody>
<tr style="height: 18.75pt; mso-yfti-firstrow: yes; mso-yfti-irow: 0;">
  <td colspan="4" nowrap="" style="background: rgb(250, 191, 143); border-bottom: 1pt solid windowtext; border-left: none; border-right: none; border-top: 1pt solid windowtext; height: 18.75pt; mso-background-themecolor: accent6; mso-background-themetint: 153; mso-border-bottom-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 360.75pt;" valign="bottom" width="481"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
<b>COST SHEET <o:p></o:p></b></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 1;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Product<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<b>Women&nbsp; T-Shirt<o:p></o:p></b></div>
</td>
  <td colspan="2" nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 149pt;" valign="bottom" width="199"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
<b>Yarn-dyed feeder stripes<o:p></o:p></b></div>
</td>
 </tr>
<tr style="height: 15.75pt; mso-yfti-irow: 2;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Style no:<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
XYZ<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Country<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
USA<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 15.75pt; mso-yfti-irow: 3;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Buyer:<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
ABC<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Fabric<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
Viscose jersey<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 15.75pt; mso-yfti-irow: 4;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
GSM/width<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
150/34-31"<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
<br /></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 5;">
  <td nowrap="" style="background: rgb(191, 191, 191); border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="background: rgb(191, 191, 191); border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<b>Particulars<o:p></o:p></b></div>
</td>
  <td nowrap="" style="background: rgb(191, 191, 191); border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
<b>Details<o:p></o:p></b></div>
</td>
  <td nowrap="" style="background: rgb(191, 191, 191); border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
<b>Amount (INR)<o:p></o:p></b></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 6;">
  <td colspan="4" nowrap="" style="background: rgb(250, 191, 143); border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-background-themecolor: accent6; mso-background-themetint: 153; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 360.75pt;" valign="bottom" width="481"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<b>Fabric Costing&nbsp;<o:p></o:p></b></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 7;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Yarn Price as per supplier list<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Per Kg&nbsp;<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
250.00&nbsp;<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 15.75pt; mso-yfti-irow: 8;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Knitting charges<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
&nbsp;Per Kg<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
25.00<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 15.75pt; mso-yfti-irow: 9;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"></td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<b>Greige Fabric Cost<o:p></o:p></b></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<b>Per Kg&nbsp;<o:p></o:p></b></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<b>275.00<o:p></o:p></b></div>
</td>
 </tr>
<tr style="height: 15.75pt; mso-yfti-irow: 10;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Average dyeing cost<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"></td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
20.00<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 18.85pt; mso-yfti-irow: 11;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 18.85pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 18.85pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Weight loss on dyed fabric:<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 18.85pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
9.00%<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 18.85pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
26.55<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 15.75pt; mso-yfti-irow: 12;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Fleece brushing /Peaching<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
-<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 15.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
-<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 13;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Loss Due To Printing<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
-<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
-<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 14;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Subtotal<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<b>321.55<o:p></o:p></b></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 15;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Interest on yarn prices:/margin<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
10.00%<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
32.16<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 16;">
  <td colspan="3" nowrap="" style="background: rgb(191, 191, 191); border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 293.25pt;" valign="bottom" width="391"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
&nbsp;<b>Dyed Fabric Cost:&nbsp;<o:p></o:p></b></div>
</td>
  <td nowrap="" style="background: rgb(191, 191, 191); border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<b>353.71<o:p></o:p></b></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 17;">
  <td colspan="4" nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 360.75pt;" valign="bottom" width="481"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<br /></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 18;">
  <td colspan="4" nowrap="" style="background: rgb(250, 191, 143); border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-background-themecolor: accent6; mso-background-themetint: 153; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 360.75pt;" valign="bottom" width="481"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<b>Garment costing&nbsp;<o:p></o:p></b></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 19;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Avg. &nbsp;Fabric Consumption
  (gram)<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
210.00<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<b>74.28<o:p></o:p></b></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 20;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<br /></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 21;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<b>CMTP Charges<o:p></o:p></b></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"></td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 22;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Stitching:<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
20.00<o:p></o:p></div>
</td>
  <td nowrap="" rowspan="6" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<br /></div>
<div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<br /></div>
<div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<br /></div>
<div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<br /></div>
<div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<b>&nbsp;39.50&nbsp;</b><o:p></o:p></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 23;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Cutting:<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
2.50<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 24;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Finishing:<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
6.00<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 25;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Packaging:<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
4.50<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 26;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Embellishment<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
2.50<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 27;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Trims<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
4.00<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 28;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<br /></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 29;">
  <td nowrap="" style="background: rgb(166, 166, 166); border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-background-themecolor: background1; mso-background-themeshade: 166; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="background: rgb(166, 166, 166); border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-background-themecolor: background1; mso-background-themeshade: 166; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<b>Sub Total<o:p></o:p></b></div>
</td>
  <td nowrap="" style="background: rgb(166, 166, 166); border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-background-themecolor: background1; mso-background-themeshade: 166; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
<br /></div>
</td>
  <td nowrap="" style="background: rgb(166, 166, 166); border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-background-themecolor: background1; mso-background-themeshade: 166; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<b>113.78<o:p></o:p></b></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 30;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Overhead cost<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
12.00%<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
13.65<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 31;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Margin (after overhead)<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
20.00%<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
25.49<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 32;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<b>Ratio/Rejection<o:p></o:p></b></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
4.00%<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<b>5.10<o:p></o:p></b></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 33;">
  <td nowrap="" style="border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
Charges for On Board<o:p></o:p></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
<br /></div>
</td>
  <td nowrap="" style="border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
1.00<o:p></o:p></div>
</td>
 </tr>
<tr style="height: 12.75pt; mso-yfti-irow: 34;">
  <td colspan="3" nowrap="" style="background: rgb(184, 204, 228); border-top: none; border: 1pt solid windowtext; height: 12.75pt; mso-background-themecolor: accent1; mso-background-themetint: 102; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 293.25pt;" valign="bottom" width="391"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<b>&nbsp;The total price of this apparel item&nbsp;<o:p></o:p></b></div>
</td>
  <td nowrap="" style="background: rgb(184, 204, 228); border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 12.75pt; mso-background-themecolor: accent1; mso-background-themetint: 102; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<b>159.02<o:p></o:p></b></div>
</td>
 </tr>
<tr style="height: 18.75pt; mso-yfti-irow: 35;">
  <td nowrap="" style="background: rgb(184, 204, 228); border-top: none; border: 1pt solid windowtext; height: 18.75pt; mso-background-themecolor: accent1; mso-background-themetint: 102; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<br /></div>
</td>
  <td nowrap="" style="background: rgb(184, 204, 228); border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 18.75pt; mso-background-themecolor: accent1; mso-background-themetint: 102; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<b>Fob prices: US$<o:p></o:p></b></div>
</td>
  <td nowrap="" style="background: rgb(184, 204, 228); border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 18.75pt; mso-background-themecolor: accent1; mso-background-themetint: 102; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"><div align="center" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: center;">
<b>Rate:
  49.00<o:p></o:p></b></div>
</td>
  <td nowrap="" style="background: rgb(184, 204, 228); border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 18.75pt; mso-background-themecolor: accent1; mso-background-themetint: 102; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<b>&nbsp;$&nbsp;&nbsp;&nbsp;&nbsp;
  3.25 <o:p></o:p></b></div>
</td>
 </tr>
<tr style="height: 21pt; mso-yfti-irow: 36; mso-yfti-lastrow: yes;">
  <td nowrap="" style="background: rgb(184, 204, 228); border-top: none; border: 1pt solid windowtext; height: 21pt; mso-background-themecolor: accent1; mso-background-themetint: 102; mso-border-bottom-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 66.75pt;" valign="bottom" width="89"></td>
  <td nowrap="" style="background: rgb(184, 204, 228); border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 21pt; mso-background-themecolor: accent1; mso-background-themetint: 102; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 145pt;" valign="bottom" width="193"><div class="MsoNormal" style="margin-bottom: 0.0001pt;">
<b>Internal Price FOB<o:p></o:p></b></div>
</td>
  <td nowrap="" style="background: rgb(184, 204, 228); border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 21pt; mso-background-themecolor: accent1; mso-background-themetint: 102; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 81.5pt;" valign="bottom" width="109"></td>
  <td nowrap="" style="background: rgb(184, 204, 228); border-bottom: 1pt solid windowtext; border-left: none; border-right: 1pt solid windowtext; border-top: none; height: 21pt; mso-background-themecolor: accent1; mso-background-themetint: 102; mso-border-bottom-alt: solid windowtext .5pt; mso-border-right-alt: solid windowtext .5pt; padding: 0in 5.4pt; width: 67.5pt;" valign="bottom" width="90"><div align="right" class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: right;">
<b>&nbsp;$&nbsp;&nbsp;&nbsp;&nbsp;
  3.25</b></div>
</td></tr>
</tbody></table>
	</div>
	</div>