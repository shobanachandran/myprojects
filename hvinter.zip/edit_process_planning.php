<?php 
include('includes/config.php');

if($_SESSION['userid']==''){
    echo "<script>window.location.href='login.php';</script>";
}

if ($_REQUEST['id'] != '') {
    $sel_process = mysqli_fetch_array(mysqli_query($zconn, "SELECT * FROM process_planning_master WHERE id='" . $_REQUEST['id'] . "'"), MYSQLI_ASSOC);
	$id = $sel_process['id'];
	$processName = $sel_process['process_name'];
	$orderNo = $sel_process['order_no'];
	$styleNo = $sel_process['style_no'];


}

if (isset($_POST['save'])) {
    $order = $_POST['order_no'];
    $style_no = $_POST['txt_style'];

    $process_sql = mysqli_query($zconn, "UPDATE process_planning_master SET total_loss = '" . $_POST['total_loss'] . "'
        WHERE id = '" . $_POST['id'] . "' AND order_no = '$order' AND style_no = '$style_no'");

    if ($process_sql) {
        $trows = count($_POST['ycolor']);

        // Update data in dyeing_planning
        $success = true; // Variable to track whether all updates were successful

        for ($tr = 0; $tr < $trows; $tr++) {
            $id = $_POST['ddi'][$tr];
            $fabric_name = $_POST['fab_name'][$tr];
            $process_name = $_POST['process_name'][$tr];
            $ycolor = $_POST['ycolor'][$tr];
            $content = $_POST['content'][$tr];
            $dia = $_POST['dia'][$tr];
            $gsm = $_POST['gsm'][$tr];
            $ycomp = $_POST['ycomp'][$tr];
            $wgt = $_POST['weight'][$tr];
            $process_loss = $_POST['process_loss_percent'][$tr];

            $updateDetails = mysqli_query($zconn, "UPDATE process_planning SET
                fabric_name = '$fabric_name',
                process_name = '$process_name',
                ycolor = '$ycolor',
                content = '$content',
                dia = '$dia',
                gsm = '$gsm',
                ycomp = '$ycomp',
                wgt = '$wgt',
                process_loss = '$process_loss'
                WHERE id = '$id'");

            if (!$updateDetails) {
                $success = false;
                die("SQL Error: " . mysqli_error($zconn));
            }
        }

        if ($success) {
            echo "<script>alert('Updated Successfully!!!');</script>";
            echo "<script>window.location.href='process_planning_list.php';</script>";
        } else {
            echo "<script>alert('Failed to update process_planning details.');</script>";
        }
    } else {
        echo "<script>alert('Failed to update process_planning_master details.');</script>";
    }
}


?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - Other Process Costing Entry</title>
    <!-- Custom CSS -->
	<link href="dist/css/bootstrap.css" rel="stylesheet">
<link href="dist/css/dataTables.bootstrap4.min.css" rel="stylesheet">
<!-- Custom CSS -->
<link href="dist/css/style.min.css" rel="stylesheet">
<style>
th{font-size:12px; font-weight:bold; background-color:#626F80; color: #fff; text-align:center;}

</style>
<!-- Custom CSS -->


	<style>
        /* CSS for the container */
        .scroll-container {
            width: 100%; /* Set the width as needed */
            overflow-x: auto; /* Enable horizontal scrolling */
        }
		.hidden {
    display: none;
}
.table-container {
            width: 100%; /* Set the width as needed */
            overflow-x: auto; /* Enable horizontal scrolling */
            white-space: nowrap; /* Prevent text wrapping */
        }

        th {
            font-size: 12px;
            font-weight: bold;
            background-color: #626F80;
            color: #fff;
            text-align: center;
        }

    </style>


</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php  include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- Page wrapper  -->
        <div class="page-wrapper" >
            <!-- Bread crumb and right sidebar toggle -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Process Planning</h4>
						&nbsp;&nbsp;&nbsp;&nbsp;<a href="planning.php"> <button type="button" class="btn btn-info">Planning Process</button></a>
						<div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item " aria-current="page">Merch</li>
									<!-- <li class="breadcrumb-item " aria-current="page"><a href="costing.php">Costing</a></li> -->
									<li class="breadcrumb-item active" aria-current="page"><a href="planning.php">Process Palnning</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- Container fluid  -->
        <div class="container-fluid">
                <!-- Sales chart -->
			<form name="other_process" method="post">
				
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
								<div class="card-body" style="width:100%">
									
										<div class="card" style="width:50%; float:left; left: 50px; ">
										
										<div class="form-group row">
										<label for="fname" class="col-sm-3 text-right control-label col-form-label">Order No</label>
										<div class="col-sm-6">
                                			<input type="text" name="order_no" value="<?php echo $sel_process['order_no'];?>" readonly>
										</div>
									</div>
									
		<?php $sel_style = mysqli_fetch_array(mysqli_query($zconn,"select * from order_entry_master where order_no='".$sel_process['order_no']."'"),MYSQLI_ASSOC);
			
			$order_date_arr = explode(" ",$sel_style['created_date']);
			$order_dt_arr = explode("-",$order_date_arr['0']);
			$order_date = $order_dt_arr['2']."-".$order_dt_arr['1']."-".$order_dt_arr['0'];
		
		?>
		<div class="form-group row">
			<label for="fname" class="col-sm-3 text-right control-label col-form-label">Style No</label>
			<div class="col-sm-6"><input type="text" name="txt_style" id="txt_style" value="<?php echo $sel_process['style_no'];?>" class="form-control" readonly>
			</div>
		</div>

	</div>
	<div class="card" style="width:50%; float:left; right: 50px;">
		<div class="form-group row">
			<label for="fname" class="col-sm-3 text-right control-label col-form-label">Buyer name</label>
			<div class="col-sm-6"><input type="text" name="buyer_name" id="buyer_name" value="<?php echo $sel_style['buyer_name'];?>" class="form-control" readonly>
				
			</div>
		</div>
		<div class="form-group row">
			<label for="cono1" class="col-sm-3 text-right control-label col-form-label">Order Date</label>
			<div class="col-sm-6">
		<?php echo $order_date; ?>
				</div>
				</div>

			</div>



        
			<div class="table-container" >
        <table id="example" style="width:150%">
            <thead>
                <tr>
                    <th class="hidden"></th>
                    <th style="width:10%">Fabric Name</th> <!-- Increase width to 10% -->
                    <th style="width:10%">Process Name</th> <!-- Increase width to 10% -->
                    <th style="width:10%">Color</th> <!-- Increase width to 10% -->
                    <th style="width:10%">Content</th> <!-- Increase width to 10% -->
                    <th style="width:10%">Component</th> <!-- Increase width to 10% -->
                    <th style="width:5%">Dia</th>
                    <th style="width:5%">Gsm</th>
                    <th style="width:5%">Weight</th>
                    <th style="width:5%">Process Loss</th>
                    <th style="width:5%">Total</th>
                    <th style="width:5%">
                        <button type="button" class="btn btn-info add-new"><i class="fa fa-plus"></i></button>
                    </th>
                </tr>
            </thead>
		<tbody>
		<?php 
		 $sel_process1 = mysqli_query($zconn,"select * from process_planning where process_id='".$_GET['id']."'");
		$p1=0;
			while($res_process_item = mysqli_fetch_array( $sel_process1,MYSQLI_ASSOC)){
			
				$id=$res_process_item['id'];
		?>
		
			<tr id="delete_<?php echo $p1;?>">
			<td style="display: none;"><input type="hidden" name="ddi[]" class="form-control" id="ddi" autocomplete="off" value="<?php echo $res_process_item['id'];?>"></td>

					<td style="width:10%"><select name="fab_name[]" class="form-control">
						<option value="">--Select--</option>
						<?php 
					$sql_fabs = mysqli_query($zconn,"select * from fabric_master where status='0'");
					$fabs_list ='';
					while($res_fabs = mysqli_fetch_array($sql_fabs,MYSQLI_ASSOC)){
						
					if($res_process_item['fabric_name']==$res_fabs['fabric_name']){
						$fabs_list .='<option selected value="'.$res_fabs['fabric_name'].'">'.$res_fabs['fabric_name'].'</option>';
					} else {
						$fabs_list .='<option value="'.$res_fabs['fabric_name'].'">'.$res_fabs['fabric_name'].'</option>';
					}
				
					?>
					<?php echo $fabs_list;?>
					<?php }?>
					
			</select>
		</td>
					<td style="width:10%">
					<select class="select2 form-control custom-select " id="process_name" name="process_name[]">
						<option value="">Select</option>
					<?php
					 $sel_process = mysqli_query($zconn,"select * from process_master where status='0'"); 
                     while($res_process = mysqli_fetch_array($sel_process,MYSQLI_ASSOC)){
						
						if( $res_process_item['process_name'] == $res_process["process_name"]) {?>
							<option value="<?php echo $res_process['process_name'];?>" selected><?php echo $res_process['process_name'];?></option>
							<?php } else { ?>
							<option value="<?php echo $res_process['process_name'];?>"><?php echo $res_process['process_name'];?></option>
							<?php } ?>
                            <?php } ?>


					</select>
					
					
						
				</td>
					
				
				<td style="width:10%">

<select class="select2 form-control custom-select" name="ycolor[]" id="ycolor0">
   <option value="">Select</option>
<?php
$sel_ycolor = mysqli_query($zconn,"select * from color_master where status='0'");
while($res_ycolor = mysqli_fetch_array($sel_ycolor,MYSQLI_ASSOC)){

if($res_process_item['ycolor']== $res_ycolor['colour_name']){?>
<option value="<?php echo $res_ycolor['colour_name'];?>" selected><?php echo $res_ycolor['colour_name'];?></option>
<?php } else { ?>
<option value="<?php echo $res_ycolor['colour_name'];?>"><?php echo $res_ycolor['colour_name'];?></option>
<?php } ?>
<?php } ?>
</select> 
<script type="text/javascript">
				   $(".chosen-select").chosen({
					 no_results_text: "Oops, nothing found!"
				   })
			   </script>
	   </td>
		   

	   <td style="width:10%">
				<select class="select2 form-control custom-select" name="content[]" id="content">
					<option value="">Select</option>
					<?php
					$sel_ycolor1 = mysqli_query($zconn,"select * from content_master where status='0'");
					while($res_ycolor1 = mysqli_fetch_array($sel_ycolor1,MYSQLI_ASSOC)){
						if($res_process_item['content']==$res_ycolor1['content_name']){	?>
						<option selected  value="<?php echo $res_ycolor1['content_name'];?>"><?php echo $res_ycolor1['content_name'];?></option>
						<?php } else { ?>
						<option value="<?php echo $res_ycolor1['content_name'];?>"><?php echo $res_ycolor1['content_name'];?></option>
						<?php } ?>
					<?php } ?>
				</select> 
			</td>

			
										<td style="width:10%">
										<select class="select2 form-control custom-select chosen-select" name="ycomp[]" id="ycomp<?php echo $co;?>">
										<option value="">Select</option>
										<?php $selcomp = mysqli_query($zconn,"select * from components where status='0'");
										while($res_comp = mysqli_fetch_array($selcomp,MYSQLI_ASSOC)){
											if($res_process_item['ycomp']==$res_comp['comp_name']){
										?>
										<option selected value="<?php echo $res_comp['comp_name'];?>"><?php echo $res_comp['comp_name'];?></option>
											<?php } else { ?>
											<option value="<?php echo $res_comp['comp_name'];?>"><?php echo $res_comp['comp_name'];?></option>
										<?php } 
										} ?>
										</select>
										</td>

			<td style="width:5%"><input type="text" name="dia[]"  class="form-control" id="dia"  onKeyUp="multiply()" required autocomplete="off"  value="<?php echo $res_process_item['dia']; ?>"></td>
				<td style="width:5%">
					<input type="text" name="gsm[]"  class="form-control " id="gsm" required onKeyUp="multiply_loss()"  value="<?php echo $res_process_item['gsm']; ?>">
				</td>
					
					
					<td style="width:5%">
    <input type="text" class="form-control weight" id="weight<?php echo $p1; ?>" name="weight[]" placeholder="Weight" value="<?php echo $res_process_item['wgt']; ?>">
</td>
<td style="width:5%">
    <input type="text" class="form-control process_loss_percent" id="process_loss_percent<?php echo $p1; ?>" name="process_loss_percent[]" placeholder="Process Loss %" value="<?php echo $res_process_item['process_loss']; ?>">
</td>
<td style="width:5%">
    <input type="text" class="form-control total_weight" id="total_weight<?php echo $p1; ?>" name="total_weight[]" placeholder="Total" value="<?php echo $res_process_item['total_weight']; ?>" readonly>
</td>

<td style="width:5%">
						<a class="delete-row" title="Delete"><button type="button" class="btn btn-info"><i class="fa fa-minus"></i></button></a>
					</td>
									</tr>
			<?php $p1++;} ?>
			</tbody>
			</table>
			
			</div>
						</div>
						
			<table class="table table-striped table-bordered">
				<tr id="">
					<td width="50%">&nbsp;</td>
					<td width="15%"> </td>
					<td width="15%">
					  <h6 class="page-title">Total:</h6></td>
					  <td width="8%">
            <input type="text" class="form-control" id="total" name="total" readonly placeholder="" style="border: 1px solid #000;">
        </td>
       
					<td width="7%">		<!--td>
        <input type="text" class="form-control percentage_loss" readonly style="border: 1px solid #000;">
      </td-->
				</tr>
			</table>

						

			<div class="border-top">
				<div class="card-body" style="margin-left: 250px;">
					<button type="submit" name="save" class="btn btn-success" value="<?php echo $action;?>">Save</button>
					<button type="reset" class="btn btn-primary">Reset</button>
					<a href="dyeing_planning_list.php"><button type="button" class="btn btn-danger">List</button></a>
				</div>
			</div>
	</tbody>
</table>
					      			</div>
									</div>
				
									</div>
									</div>
      
									<?php include('includes/footer.php');?>
			</form>
        </div>

        
    </div>
									</div>
									</div>
						
						<br>
						<br>
						<br>
						<hr>
						<br>
						<br>
						<br>
    <!-- End Wrapper -->
	<!-- ============================================================== -->
            <!-- footer -->
            
								
            <!-- End footer -->
    <!-- All Jquery -->

    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
<!--Wave Effects -->
<!--Menu sidebar -->
<script src="dist/js/sidebarmenu.js"></script>
<!--Custom JavaScript -->
<script src="dist/js/custom.min.js"></script>
<!--datatables JavaScript -->
<script src="dist/js/jquery.dataTables.min.js"></script>
<script src="dist/js/dataTables.bootstrap4.min.js"></script>

<script>
	$(document).on("input", "input[name^='wgt'], input[name^='process_loss_percent']", function () {
    calculateRowTotal($(this));
});

function calculateRowTotal(input) {
    var row = input.closest('tr');
    var wgt = parseFloat(row.find("input[name^='wgt']").val()) || 0;
    var processLossPercentage = parseFloat(row.find("input[name^='process_loss_percent']").val()) || 0;
    
    var processLoss = (wgt * processLossPercentage) / 100;
    var total = wgt - processLoss;
    
    row.find("input[name^='total_weight']").val(total.toFixed(2));
}
$(document).on("click", ".add-new", function () {
    var index = $("#example tbody tr:last-child").index() + 1;
    var newRow = $("#example tbody tr:first").clone(true);
    newRow.find("input").val("");
    newRow.find("select").val("");
    newRow.find("input[name^='wgt'], input[name^='process_loss_percent']").on("input", function () {
        calculateRowTotal($(this));
    });
    newRow.insertAfter($("#example tbody tr:last"));
});
</script>


<script src="dist/js/custom.min.js"></script>
	<?php

		$sel_fabrics = mysqli_query($zconn,"select * from fabric_master where status='0'");
		$fabslist= '';
		while($res_fabrics = mysqli_fetch_array($sel_fabrics,MYSQLI_ASSOC)){
			$fabslist .='<option value="'.$res_fabrics['fabric_name'].'">'.addslashes($res_fabrics['fabric_name']).'</option>';
		}

	    $sel_ycolor = mysqli_query($zconn,"select * from color_master where status='0'");
	    $color_list='';
		while($res_ycolor = mysqli_fetch_array($sel_ycolor,MYSQLI_ASSOC)){
			$color_list .='<option value="'.$res_ycolor['colour_name'].'">'.$res_ycolor['colour_name'].'</option>';
		}

		$selcomp = mysqli_query($zconn,"select * from components where status='0'");
		$comp_list='';
		while($res_comp = mysqli_fetch_array($selcomp,MYSQLI_ASSOC)){
			$comp_list .='<option value="'.$res_comp['comp_name'].'">'.$res_comp['comp_name'].'</option>';
		}

?>
<script type="text/javascript">
$(document).ready(function(){
	//$('.left-sidebar').slideToggle();
});

$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
	var actions = $("#example1 td:last-child").html();
	// Append table with add row form on add new button click
    $(".add-new").click(function(){
		var index = $("table tbody tr:last-child").index();
		var newc = parseInt(index)+parseInt(1);
            var row =
                '<tr>' +
                '<td><select name="fab_name[]" class="select2 form-control custom-select chosen-select"><option value="">--Select--</option><?php echo $fabs_list; ?></select></td>' +
                '<td><select class="select2 form-control custom-select chosen-select" name="process_name[]" data-no="' + id + '" id="process_name' + id + '" onchange="sel_sub(this);"><option value="">Select</option><?php $sel_process = mysqli_query($zconn, "select * from process_master where status='0'"); while ($res_process = mysqli_fetch_array($sel_process, MYSQLI_ASSOC)) { ?> <option value="<?php echo $res_process['process_name']; ?>"><?php echo $res_process['process_name']; ?></option><?php } ?></select></td>' +

                '<td><select class="select2 form-control custom-select" name="ycolor[]" id="ycolor0' + id + '"><option value="">--Select--</option><?php echo $color_list; ?></select>' +
                '<td><select class="select2 form-control custom-select" name="content[]" id="content' + id + '"><option value="">--Select--</option><?php echo $content_list; ?></select>' +
                '<td><input type="text" name="dia[]" class="form-control" id="dia' + id + '" onKeyUp="multiply()" required autocomplete="off"></td>' +
                '<td><input type="text" name="gsm[]" class="form-control " id="gsm' + id + '" required onKeyUp="multiply_loss()"></td>' +
                '<td><input type="text" class="form-control wgt" id="wgt_' + id + '" placeholder="Weight" name="wgt[]" onkeyup="rate_cal(' + id + ');" onblur="rate_cal(' + id + ');"></td>' +
                '<td><input type="text" class="form-control proloss " id="process_loss' + id + '" onkeyup="proloss(this);" name="process_loss[]" placeholder="Process Loss"></td>' +
                '<td><input type="text" class="form-control total" id="total' + id + '" name="total[]" readonly placeholder="Total"></td>' +
                '<td><a class="delete-row" title="Delete"><button type="button" class="btn btn-info"><i class="fa fa-minus"></i></button></a></td>' +
                '</tr>';

				$("#example1").append(row);
		$("#example1 tr").eq(index + 1).find(".add, .edit").toggle();
        $('[data-toggle="tooltip"]').tooltip();
    });

	// Add row on add button click
	$(document).on("click", ".add", function(){
		var empty = false;
		var input = $(this).parents("tr").find('input[type="text"]');
        input.each(function(){
		});
		$(this).parents("tr").find(".error").first().focus();
		if(!empty){
			input.each(function(){
				$(this).parent("td").html($(this).val());
			});
			$(this).parents("tr").find(".add, .edit").toggle();
			$(".add-new").removeAttr("disabled");
		}
    });
	// Edit row on edit button click
	$(document).on("click", ".edit", function(){
        $(this).parents("tr").find("td:not(:last-child)").each(function(){
			$(this).html('<input type="text" class="form-control" value="' + $(this).text() + '">');
		});
		$(this).parents("tr").find(".add, .edit").toggle();
		$(".add-new").attr("disabled", "disabled");
    });
	// Delete row on delete button click
	$(".add-new").click(function() {
        var newRow = $("#example tbody tr:first").clone(true);
        newRow.find("input, select").val(""); // Clear input and select values
        newRow.insertAfter("#example tbody tr:last");
    });

    // Delete row on delete button click
    $(document).on("click", ".delete-row", function() {
        if ($("#example tbody tr").length > 1) { // Ensure there's at least one row left
            $(this).closest("tr").remove();
        } else {
            alert("You can't delete the last row.");
        }
    });

});


$('#order_date').datepicker({
	format:'dd-mm-yyyy',
      autoclose: true
    })
</script>
<!-- <script>
function calculateTotal(input) {
    var row = input.closest('tr'); // Find the parent row
    var wgt = parseFloat(row.querySelector('[name="wgt[]"]').value) || 0; // Get the value of "wgt" or 0 if empty
    var processLossPercentage = parseFloat(row.querySelector('[name="process_loss[]"]').value) || 0; // Get the value of "process_loss" percentage or 0 if empty

    // Calculate the process loss based on the percentage
    var processLoss = (wgt * processLossPercentage) / 100;

    // Calculate the total weight
    var total = wgt - processLoss;

    // Update the "total_weight" input field in the same row
    row.querySelector('[name="total_weight[]"]').value = total.toFixed(2);
}
</script> -->




</body>
</html>