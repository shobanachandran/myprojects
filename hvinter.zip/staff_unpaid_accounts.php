<?php 
include('includes/config.php');

if($_SESSION['userid']==''){
	echo "<script>window.location.href='login.php';</script>";
}
if(isset($_GET['date']) && ($_GET['id']))
{
	mysqli_query("UPDATE `dummy_staff` SET  `status` =  'PAID' WHERE `dummy_staff`.`id` = '".$_GET['id']."' AND `dummy_staff`.`salary_month` = '".$_GET['date']."' LIMIT 1")or die(mysql_error());
	echo("<script>alert('Remove successfully')</script>");
//	echo "<meta http-equiv='refresh' content='0;URL=staff_unpaid_accounts.php' />";
	
}

?>



<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - Staff Attendence 	</title>
    <!-- Custom CSS -->
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
      

</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <div class="page-wrapper" style="min-height: 100%; height: auto;">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
             <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Staff Attendance </h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="#">Staff Attendance</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
			<div class="container-fluid">
            <div class="row">
                    <div class="col-md-12">
                        <div class="card">
						<div class="card-body">
    <h2>Attendance Table</h2>
   
        <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
        <tr>
        <th width="6%" height="32" align="center" valign="middle">Id</th>
                    <th width="10%" align="center" valign="middle">Date</th>
                    <th width="10%" align="center" valign="middle">Name</th>
                    <th width="10%" align="center" valign="middle">Dept</th>
                    <th width="6%" align="center" valign="middle"><strong>Leave Taken</strong></th>
                    <th width="7%" align="center" valign="middle"><strong>Worked Days</strong></th>
                    <th width="6%" align="center" valign="middle"><strong>Salary Per month</strong></th>
                    <th width="5%" align="center" valign="middle"><strong>Loss Of Pay</strong></th>
                    <th width="4%" align="center" valign="middle"><strong>Net Amt</strong></th>
                    <th width="6%" align="center" valign="middle"><strong>Petrol Allow</strong></th>
                    <th width="5%" align="center" valign="middle"><strong>Total Adv</strong></th>
                    <th width="7%" align="center" valign="middle">Adv reduced</th>
                    <th width="4%" align="center" valign="middle"><strong>Adv Bal</strong></th>
                    <th width="6%" align="center" valign="middle">Salary</th>
                    <th align="center" valign="middle"><!--<a href="staff_unpaid.php?date=alldata" onclick="return confirmBox()">Delete All</a>--></th>
        </tr>
        </thead>
        <tbody>
        <?php
        $fabric = mysqli_query($con, "SELECT * FROM attendance WHERE `status`='unpaid' ORDER BY id ASC");
        $lab_salary_total = '0';
        while ($fabrics = mysqli_fetch_object($fabric)) {
            $dates = "01-" . $fabrics->startdate . "-" . $fabrics->enddate;
            $fabricsab = mysqli_fetch_object(mysqli_query($con, "SELECT * FROM `persondetail` WHERE `id`='" . $fabrics->id . "'"));
            ?>
            <tr height="24">
            <td width="6%"  align="center" valign="middle" bgcolor="#FFFFFF"  style="padding:0px;"><?php echo($fabrics->id);?></td>
    <td width="10%" align="center" valign="middle" bgcolor="#FFFFFF"  style="padding:0px;"><?php=date("d-m-y",strtotime($fabrics->date))?></td>
    <td width="10%" align="center" valign="middle" bgcolor="#FFFFFF"  style="padding:0px;"><?php echo($fabrics->name);?></td>
    <td width="10%" align="center" valign="middle" bgcolor="#FFFFFF"  style="padding:0px;"><?php echo($fabrics->department);?></td>
    <td width="6%"  align="center" valign="middle" bgcolor="#FFFFFF"  style="padding:0px;"><?php echo($fabrics->leave_taken);?></td>
    <td width="7%"  align="center" valign="middle" bgcolor="#FFFFFF"  style="padding:0px;"><?php echo($fabrics->worked_days);?></td>
    <td width="6%"  align="center" valign="middle" bgcolor="#FFFFFF"  style="padding:0px;"><?php echo($fabrics->salary_month);?></td>
    <td width="5%"  align="center" valign="middle" bgcolor="#FFFFFF"  style="padding:0px;"><?php echo($fabrics->loss_pay);?></td>
    <td width="4%"  align="center" valign="middle" bgcolor="#FFFFFF"  style="padding:0px;"><?php echo($fabrics->net_amount);?></td>
    <td width="6%"  align="center" valign="middle" bgcolor="#FFFFFF"  style="padding:0px;"><?php echo($fabrics->petrol_allowance);?></td>
    <td width="5%"  align="center" valign="middle" bgcolor="#FFFFFF"  style="padding:0px;"><?php echo($fabrics->total_advance);?></td>
    <td width="7%"  align="center" valign="middle" bgcolor="#FFFFFF"  style="padding:0px;"><?php echo($fabrics->advance_reduced);?></td>
    <td width="4%"  align="center" valign="middle" bgcolor="#FFFFFF"  style="padding:0px;"><?php echo($fabrics->advance_balance);?></td>
    <td width="6%"  align="center" valign="middle" bgcolor="#FFFFFF"  style="padding:0px;"><?php echo($fabrics->salary);?></td>
    <td width="10%"  align="center" valign="middle" bgcolor="#FFFFFF" >
    <strong>
        <a href="salary_session.php?data=staff&id=<?php echo($fabrics->i);?>"><button type="button" class="btn btn-primary">Pay Now</button></a></strong>
        &nbsp;&nbsp;<strong><a href="staff_unpaid.php?date=<?php echo($fabrics->salary);?>&id=<?php echo($fabrics->id);?>" title="Delete" onclick="return confirmBox()"><button type="button"class="btn btn-danger">Delete</button></a></strong></td>
    </tr>
            
        <?php  } ?>
        </tbody>
        <tfoot>
        <tr height="24">
        <td height="28" colspan="13"  align="center" valign="middle" bgcolor="#FFFFFF" >&nbsp;</td>
    <td  align="center" valign="middle" bgcolor="#FFFFFF" ><strong><?php echo $lab_salary_total;?></strong></td>
    <td  align="center" valign="middle" bgcolor="#FFFFFF" >&nbsp;</td>
        </tr>
        </tfoot>
    </table>
</div>
        </div>
        </div>
        </div>

        </div>
        </div>
                <!--/row-->		
    <!-- End Wrapper -->
	<!-- ============================================================== -->
            <!-- footer -->
            <?php include('includes/footer.php');?>
        </div>
        </div>
            <!-- End footer -->
            <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    
</body>
</html>