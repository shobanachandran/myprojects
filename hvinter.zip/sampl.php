<!-- <?php 
$name = array("Apple", "Banana", "Orange");
foreach ($name as $value){
 //echo $value.", ";
 $value1.= $value;

}
echo $value1;



?> -->

<!-- <?php
$cars = array("Volvo", "BMW", "Toyota");
$arrlength = count($cars);

for($x = 0; $x < $arrlength; $x++) {
    $car.= $cars[$x].",";
    
}
echo $car;
?> -->
<!-- <form oninput="result.value=parseInt(x.value)+parseInt(y.value)">
    <input type="range" name="x" value="25" min="0" max="100" /> +
    <input type="number" name="y" value="75" /> =
    <output name="result">100</output>
</form> -->

<p>The party starts at <time>22:00</time>. </p>
<p>Deadline: <time datetime="2018-12-24 12:00">Christmas</time>.</p>