<?php 
include('includes/config.php');

if($_SESSION['userid']==''){
	echo "<script>window.location.href='login.php';</script>";
}

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - Bill Pass 	</title>
    <!-- Custom CSS -->
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">    
</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <div class="page-wrapper" style="min-height: 100%; height: auto;">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
             <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Bill Pass </h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="#">Bill Pass </a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
			<div class="container-fluid">   
				<div class="row">
                    <div class="col-md-12">
                        <div class="card">            
                <!-- ============================================================== -->
                <!-- Sales chart -->
				
				
			<form name="colInfo" id="colInfo" method="post" enctype="multipart/form-data" action="">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
							<div class="card-body">
							</div>
								<div class="card-body" style="width:100%">
								
		<div class="container">
    <div class="row justify-content-center">
        <div class="col-sm-9">
            <div class="form-group">
                <div class="row">
    <div class="col-sm-4">
        <label for="option1">Bill by</label>
        <select class="form-control" name="option1" id="option1">
            <option value="">Select</option>
            <option value="supplier">Supplier</option>
            <option value="process">Process</option>
            <option value="jobwork">Jobwork</option>
        </select>
    </div>
    <div class="col-sm-4">
        <label for="option2">Department</label>
        <select class="form-control" name="option2" id="option2">
            <option value="">Select</option>
        </select>
    </div>
    <div class="col-sm-4">
        <label for="option3">Supplier</label>
        <select class="form-control" name="option3" id="option3">
            <option value="">Select</option>
        </select>
    </div>
</div>

            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        $('#option1').change(function () {
            var selectedOption = $(this).val();
            $('#option2').empty().append('<option value="">Select</option>'); // Reset second dropdown
            $('#option3').empty().append('<option value="">Select</option>'); // Reset third dropdown
            
            if (selectedOption === 'supplier') {
                $('#option2').append('<option value="fabric">Fabric</option>');
                $('#option2').append('<option value="yarn">Yarn</option>');
                $('#option2').append('<option value="store">Store</option>');
            } else if (selectedOption === 'process') {
                // Add options for 'process'
                $('#option2').append('<option value="process_option_1">Process Option 1</option>');
                $('#option2').append('<option value="process_option_2">Process Option 2</option>');
                // Add more options as needed
            } else if (selectedOption === 'jobwork') {
                // Add options for 'jobwork'
                $('#option2').append('<option value="jobwork_option_1">Jobwork Option 1</option>');
                $('#option2').append('<option value="jobwork_option_2">Jobwork Option 2</option>');
                // Add more options as needed
            }
        });

        $('#option2').change(function () {
            var selectedOption = $(this).val();
            $('#option3').empty().append('<option value="">Select</option>'); // Reset third dropdown
            
           
                  if (selectedOption === 'fabric') {
                // If 'fabric' is selected in the second dropdown,
                // Perform an AJAX call to fetch supplier names based on 'fabric'
       $.ajax({
                        url: 'billpass/fabric_supplier.php',
                        method: 'POST',
                        data: { selectedOption: selectedOption },
                        success: function (response) {
                            // Check if the response is not empty and is in the expected JSON format
                            if (response && typeof response === 'object' && Array.isArray(response)) {
                                // Process the response here
                                $.each(response, function(index, supplier) {
                                    $('#option3').append('<option value="' + supplier.supplier_id + '">' + supplier.supplier_name + '</option>');
                                });
                            } else {
                                console.error("Empty or invalid response received");
                            }
                        },
                        error: function (xhr, status, error) {
                            console.error("AJAX request error:", error);
                        }
                    });


            } else if (selectedOption === 'yarn') {
                // Add options for 'yarn'
                     $.ajax({
                        url: 'billpass/yarn_supplier.php',
                        method: 'POST',
                        data: { selectedOption: selectedOption },
                        success: function (response) {
                            // Check if the response is not empty and is in the expected JSON format
                            if (response && typeof response === 'object' && Array.isArray(response)) {
                                // Process the response here
                                $.each(response, function(index, supplier) {
                                    $('#option3').append('<option value="' + supplier.supplier_id + '">' + supplier.supplier_name + '</option>');
                                });
                            } else {
                                console.error("Empty or invalid response received");
                            }
                        },
                        error: function (xhr, status, error) {
                            console.error("AJAX request error:", error);
                        }
                    });
                // Add more options as needed
            } else if (selectedOption === 'store') {
                // Add options for 'store'
               $.ajax({
                        url: 'billpass/store_supplier.php',
                        method: 'POST',
                        data: { selectedOption: selectedOption },
                        success: function (response) {
                            // Check if the response is not empty and is in the expected JSON format
                            if (response && typeof response === 'object' && Array.isArray(response)) {
                                // Process the response here
                                $.each(response, function(index, supplier) {
                                    $('#option3').append('<option value="' + supplier.supplier_id + '">' + supplier.supplier_name + '</option>');
                                });
                            } else {
                                console.error("Empty or invalid response received");
                            }
                        },
                        error: function (xhr, status, error) {
                            console.error("AJAX request error:", error);
                        }
                    });
                // Add more options as needed
            }
        });
    });
</script>



						
									
									
		
			
								
							
							
								</div>
									
				
                        </div>
                    </div>
                </div>
				<input type="hidden" name="action" id="action" value="<?php echo $action ?>" />
	  <?php if(isset($colid)){ ?>
		<input type="hidden" name="colid" id="colid" value="<?php echo $colid ?>" />
	  <?php  } ?>
				</form>
                <!-- Sales chart -->
                <!-- ============================================================== -->           
			<form name="" action="supplier_bill2.php?choose=<?php echo $_SESSION['choose'];?>&supplier=<?php echo $_REQUEST['supplier'];?>" method="post">
                    <?php if(isset($_SESSION['choose']) && $_SESSION['choose'] == 'fabric' ){?>
                            <table width="75%" border="0" align="center" cellpadding="0" cellspacing="0" class="table table-striped table-bordered">
                                  <thead>
                                  <tr>
                                    <td width="2%">&nbsp;</td>
                                    <td width="15%">Date</td>
                                    <td width="15%">Pono</td>
                                    <td width="13%">Style No</td>
                                    <td width="13%">Fabric</td>
                                    <td width="10%">Color</td>
                                    <td width="10%">Kgs</td>
                                    <td width="16%">Rate</td>
                                    <td width="13%">Amount</td>
                                  </tr>
                                  </thead>
                                  <tbody>
                                  <?php
                                /*  $sql_get="SELECT * FROM `fabric_received` WHERE `status` = '' and `date` >= '2014-07-15' and `supplier_id` = '".$_REQUEST['supplier']."' and `kgs` != '0'";
								  //echo $sql_get;
                                  $sql_get=mysqli_query($sql_get)or die(mysqli_error());
                                  while($res_get=mysqli_fetch_object($sql_get)){
                                  ?>
                                  <tr>
                                    <td><input type="checkbox" name="id[]" value="<?php echo $res_get->id;?>" /></td>
                                    <td><?php echo date("d-m-Y",strtotime($res_get->date));?></td>
                                    <td><?php echo $res_get->pono;?></td>
                                    <td><?php echo $res_get->styleno;?></td>
                                    <td><?php echo $name=$res_get->fab_name;?></td>
                                    <td><?php echo $res_get->color;?></td>
                                    <td><?php echo $res_get->kgs;?></td>
                                    <td><?php echo $res_get->price;?></td>
                                    
                      <!--  <td><input type="text" name="price_rate_<?php echo $res_get->i;?>" id="price_rate" class="span8" value="<?php echo $res_get->price_rate;?>"></td>-->
                        
                                   <td><?php echo $res_get->kgs * $res_get->price;?> </td>

                                   
                                  </tr>
                                  <?php }?>
                                  </tbody>
                                  <tfoot>
                                  <tr>
                                    <td colspan="9" class="form-actions">
                                    <input type="submit" name="submit123" value="Save Changes" class="btn btn-primary" />
                                    <input type="reset" name="reset123" value="Cancel" class="btn" />
                                    </td>
                                    </tr>
                                  </tfoot>
                                </table>
                    <?php }elseif($_SESSION['choose'] == 'store'){ */?>
                   			<table width="75%" border="0" align="center" cellpadding="0" cellspacing="0" class="table table-striped table-bordered">
                                  <thead>
                                  <tr>
                                    <td width="2%">&nbsp;</td>
                                    <td width="15%">Date</td>
                                    <td width="15%">Pono</td>
                                    <td width="13%">Style No</td>
                                    <td width="13%">Fabric</td>
                                    <td width="10%">Kgs</td>
                                    <td width="16%">Rate</td>
                                    <td width="13%">Amount</td>
                                  </tr>
                                  </thead>
                                  <tbody>
                                  <?php
                                /*  $sql_get="SELECT * FROM `store_received` WHERE `status` = '' and `date` >= '2015-06-15' and `supplier_id` = '".$_REQUEST['supplier']."' and `kgs` != '0'";
                                  $sql_get=mysqli_query($sql_get)or die(mysqli_error());
                                  while($res_get=mysqli_fetch_object($sql_get)){
                                  ?>
                                  <tr>
                                    <td><input type="checkbox" name="id[]" value="<?php echo $res_get->i;?>" /></td>
                                    <td><?php echo date("d-m-Y",strtotime($res_get->date));?></td>
                                    <td><?php echo $res_get->pono;?></td>
                                    <td><?php echo $res_get->styleno;?></td>
                                    <td><?php echo $name=$res_get->name;?></td>
                                    <td><?php echo $res_get->kgs;?></td>
                                    <td><?php echo $res_get->price;?></td>
                                    <td><?php echo $res_get->kgs*$res_get->price;?></td>
                                  </tr>
                                  <?php }?>
                                  </tbody>
                                  <tfoot>
                                  <tr>
                                    <td colspan="8" class="form-actions">
                                    <input type="submit" name="submit123" value="Save Changes" class="btn btn-primary" />
                                    <input type="reset" name="reset123" value="Cancel" class="btn" />
                                    </td>
                                    </tr>
                                  </tfoot>
                                </table>
							
                    <?php }elseif($_SESSION['choose'] == 'yarn'){*/?>
                    		<table width="75%" border="0" align="center" cellpadding="0" cellspacing="0" class="table table-striped table-bordered">
                                  <thead>
                                  <tr>
                                    <td width="2%">&nbsp;</td>
                                    <td width="15%">Date</td>
                                    <td width="15%">Pono</td>
                                    <td width="13%">Style No</td>
                                    <td width="13%">Fabric</td>
                                    <td width="10%">Kgs</td>
                                    <td width="16%">Rate</td>
                                    <td width="13%">Amount</td>
									
                                  </tr>
                                  </thead>
                                  <tbody>
                                  <?php
                                /*  $sql_get="SELECT * FROM `yarns_received` WHERE `status` = '' and `date` >= '2014-06-15' and `supplier_id` = '".$_REQUEST['supplier']."' and `wgt` != '0'";
                                  $sql_get=mysqli_query($sql_get)or die(mysqli_error());
                                  while($res_get=mysqli_fetch_array($sql_get)){
                                  ?>
								 
                                  <tr>
                                    <td><input type="checkbox" name="id[]" value="<?php echo $res_get['id'];?>" /></td>
                                    <td><?php echo date("d-m-Y",strtotime($res_get['date']));?></td>
                                    <td><?php echo $res_get['pono'];?></td>
                                    <td><?php echo $res_get['styleno'];?></td>
                                    <td><?php echo $res_get['yarn_name'];?></td>
                                    <td><?php echo $res_get['wgt'];?></td>
                                    <td><?php echo $res_get['price'];?></td>
                                    <td><?php echo $res_get['wgt']*$res_get['price'];?></td>
                                  </tr>
                                  <?php }*/?>
                                  </tbody>
                                  <tfoot>
                                  <tr>
                                    <td colspan="8" class="form-actions">
                                    <input type="submit" name="submit123" value="Save Changes" class="btn btn-primary" />
                                    <input type="reset" name="reset123" value="Cancel" class="btn" />
                                    </td>
                                    </tr>
                                  </tfoot>
                                </table>
                    <?php }?>
                    </form>
				
            </div>
			</div>
			</div>
	
	
    <!-- End Wrapper -->
	<!-- ============================================================== -->
            <!-- footer -->
            <?php include('includes/footer.php');?>
            <!-- End footer -->
	</div>
	</div>
            <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    
</body>
</html>