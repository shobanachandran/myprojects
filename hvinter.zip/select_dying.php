<?php 
include('includes/config.php');
include('includes/base_functions.php');  

if($_REQUEST['order']){
$buyer=$_REQUEST['order'];
$select=mysqli_query($zconn,"select distinct(style_no) as style_no,(order_id) as order_id from order_entry_master where order_no='".$buyer."'");
$rowcount=mysqli_num_rows($select);
if($rowcount >0){
 echo '<option value="Select">Select</option>';
while ($row=mysqli_fetch_object($select)) {
  //  echo '<option value="'.$row->order_id."~~".$row->style_no.'">'.$row->style_no.'</option>';
    echo '<option value="'.$row->style_no.'">'.$row->style_no.'</option>';
}
}
else {
       echo '<option value="">Order No not available</option>';
}
}

?>



