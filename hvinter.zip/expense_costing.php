<?php 
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

include('includes/config.php');

if($_SESSION['userid']==''){
	echo "<script>window.location.href='login.php';</script>";
}

// Assuming you have established a database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $costing_no = $_POST['costing_no'];
    $order_no = $_POST['order_no'];
    $descr = $_POST['descr'];
    $compos = $_POST['compos'];
    $process_loss = $_POST['process_loss'];
    $others = $_POST['others'];
    $other_cost = $_POST['other_cost'];
    $factory_cost = $_POST['factory_cost'];
    $buyer = $_POST['buyer'];
    $style_no = $_POST['style_no'];
   // $order_date = $_POST['order_date'];
    $rejection = $_POST['rejection'];
    $over_head = $_POST['over_head'];
    $transportation_cost = $_POST['transportation_cost'];
    $final_product = $_POST['final_product'];
	
	//$order_date = date('Y-m-d', strtotime($_POST['order_date']));

	$order_date_input = $_POST['order_date'];
echo "Received Date: " . $order_date_input; // Check the received date format

$order_date = date('Y-m-d', strtotime($order_date_input));
echo "Converted Date: " . $order_date; // Check the converted date format


    // SQL query to insert data into the table
    $sql = "INSERT INTO expenses_costing1 (costing_no, order_no, descr, compos, process_loss, others, other_cost, factory_cost, buyer, style_no, order_date, rejection, over_head, transportation_cost, final_product) 
            VALUES ('$costing_no', '$order_no', '$descr', '$compos', '$process_loss', '$others', '$other_cost', '$factory_cost', '$buyer', '$style_no', '$order_date', '$rejection', '$over_head', '$transportation_cost', '$final_product')";

   
if (mysqli_query($zconn, $sql)) {
    echo '<script>alert("Data inserted successfully");</script>';
	header("Location: expense_costing_list.php"); // Redirect to expense_costing_list.php
    exit(); // Ensure no further code execution after redirection
} else {
    echo '<script>alert("Error: ' . $sql . '\\n' . mysqli_error($zconn) . '");</script>';
}



    // Close the connection
    mysqli_close($zconn);
}


?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Garments ERP">
    <meta name="author" content="Iorange Innovation">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo SITE_TITLE;?> - Expenses Costing Entry</title>
    <!-- Custom CSS -->
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet"> 
	<link href="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.min.css" rel="stylesheet"/>
	<script src="dist/js/jquery.min.js"></script>
	<script src="dist/js/chosen.jquery.min.js"></script>   
</head>

<body>
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include('includes/header.php');?>
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php include('includes/sidebar.php');?>
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <div class="page-wrapper" style="min-height: 100%; height: auto;">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
             <div class="page-breadcrumb">
			 
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Expenses Costing Entry</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="costing.php"> Costing Info</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Sales chart -->
				<form method="post" name="expense_costing">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
							<div class="card-body">
							</div>
								<div class="card-body" style="width:100%">
									<div class="card-body" style="width:100%">
										<div class="card" style="width:50%; float:left; left: 50px; ">
											<div class="form-group row">
												<label for="fname" class="col-sm-3 text-right control-label col-form-label">Costing No</label>
												<div class="col-sm-6">
													<select class="select2 form-control custom-select chosen-select" onchange="sel_details(this.value);" name="costing_no" id="costing_no">
										<option value="">Select</option>
										<?php $sel_costing = mysqli_query($zconn,"select * from costing_entry_master");
										while($res_costing = mysqli_fetch_array($sel_costing,MYSQLI_ASSOC)){
											if($res_costing['id']==$_REQUEST['costing_no']){
										?>
										<option selected value="<?php echo $res_costing['id'];?>"><?php echo $res_costing['costing_no'];?></option>
										<?php } else  { ?>
										<option value="<?php echo $res_costing['id'];?>">
										<?php echo $res_costing['costing_no'];?> - (<?php echo $res_costing['order_no'];?>)
									</option>
										<?php } ?>
										<?php } ?>
											</select>
											<script type="text/javascript">
												$(".chosen-select").chosen({
											  	no_results_text: "Oops, nothing found!"
												})
											</script>
												</div>
											</div>
											<div class="form-group row">
												<label for="lname" class="col-sm-3 text-right control-label col-form-label">Indent No</label>
												<div class="col-sm-6">
							
													<input type="text" class="form-control"  id="order_no" name="order_no" placeholder="">
												</div>
											</div>

											<div class="form-group row">
												<label for="lname" class="col-sm-3 text-right control-label col-form-label">Description</label>
												<div class="col-sm-6">
													<input type="text" class="form-control"  id="descr" name="descr"placeholder="">
												</div>
											</div>

											<div class="form-group row">
												<label for="lname" class="col-sm-3 text-right control-label col-form-label">Margin (%)</label>
												<div class="col-sm-6">
													<input type="text" class="form-control"  id="compos" name="compos" placeholder="">
												</div>
											</div>

											<div class="form-group row">
												<label for="lname" class="col-sm-3 text-right control-label col-form-label">Proces loss (%)</label>
												<div class="col-sm-6">
													<input type="text" class="form-control"  id="process_loss" name="process_loss" placeholder="">
												</div>
											</div>
												<!--div class="form-group row">
												<label for="lname" class="col-sm-3 text-right control-label col-form-label">others(%)</label>
												<div class="col-sm-6">
													<input type="text" class="form-control"  id="process_loss" name="others" placeholder="">
												</div>
											</div-->
												<div class="form-group row">
												<label for="lname" class="col-sm-3 text-right control-label col-form-label">Other Cost</label>
												<div class="col-sm-6">
													<input type="text" class="form-control"  id="process_loss" name="other_cost" placeholder="">
												</div>
											</div>
											<div class="form-group row">
												<label for="lname" class="col-sm-3 text-right control-label col-form-label">Packing Trim Cost</label>
												<div class="col-sm-6">
													<input type="text" class="form-control"  id="process_loss" name="factory_cost" placeholder="">
												</div>
											</div>

											<div class="form-group row">
											</div>	

											<!--div class="form-group row">
												<h4 class="page-title"><b>Material Details</b></h4>
											</div-->


										</div>
										<div class="card" style="width:50%; float:left; right: 50px;">
											<div class="form-group row">
												<label for="fname" class="col-sm-3 text-right control-label col-form-label">Buyer name</label>
												<div class="col-sm-6">
													<input type="text" class="form-control"  id="buyer_name" name="buyer" placeholder="">
												</div>
											</div>
											<div class="form-group row">
												<label for="cono1" class="col-sm-3 text-right control-label col-form-label">Style Code</label>
												<div class="col-sm-6">
													<input type="text" class="form-control"  name="style_no" id="style_no" placeholder="">
												</div>
											</div>
											<div class="form-group row">
												<label for="cono1" class="col-sm-3 text-right control-label col-form-label">Order Date</label>
												<div class="col-sm-6">
													<input type="text" class="form-control"  id="order_date" name="order_date">
												</div>
											</div>
											<script>
    // Get the current date in YYYY-MM-DD format
var currentDate = new Date().toISOString().slice(0, 10);

// Format the date as dd-mm-yyyy
var formattedDate = currentDate.split('-').reverse().join('-');

// Set the input field's value to the formatted date
document.getElementById('order_date').value = formattedDate;

</script>

											<div class="form-group row">
												<label for="lname" class="col-sm-3 text-right control-label col-form-label">Rejection (%)</label>
												<div class="col-sm-6">
													<input type="text" class="form-control"  id="process_loss" name="rejection" placeholder="">
												</div>
											</div>
											<div class="form-group row">
												<label for="lname" class="col-sm-3 text-right control-label col-form-label">Over head (%)</label>
												<div class="col-sm-6">
													<input type="text" class="form-control"  id="process_loss" name="over_head" placeholder="">
												</div>
											</div>
										
											<div class="form-group row">
												<label for="lname" class="col-sm-3 text-right control-label col-form-label">Transportation Cost</label>
												<div class="col-sm-6">
													<input type="text" class="form-control"  id="process_loss" name="transportation_cost" placeholder="">
												</div>
											</div>
												<!--div class="form-group row">
												<label for="lname" class="col-sm-3 text-right control-label col-form-label">Final Product Cost</label>
												<div class="col-sm-6">
													<input type="text" class="form-control"  id="process_loss" name="final_product" placeholder="">
												</div>
											</div-->
											
										</div>
									</div>
										
							</div>
							<div class="border-top">
									<div class="card-body" style="margin-left: 250px;">
										<button type="submit" name="submit" class="btn btn-success">Save</button>
										<button type="reset" class="btn btn-primary">Reset</button>
										<a href="expense_costing_list.php"><button type="button" class="btn btn-danger">List</button></a>
									</div>
								</div>
						</div>
					</div>
					<!-- Sales chart -->
					<!-- ============================================================== -->
				</div>
				</form>
				<!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- End Wrapper -->
	<!-- ============================================================== -->
            <!-- footer -->
            <?php include('includes/footer.php');?>
            <!-- End footer -->
            <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
	<script type="text/javascript">
function sel_details(costing_id){
	$.ajax({
			url : 'ajax/costing.php',
			data: {
			   action: "get_cost_details",
			   costing_id: costing_id
			},
			success: function( data ) {
				alert(data);
				data = data.split("~~");
				$('#order_no').val(data['0']);
				$('#style_no').val(data['1']);
				$('#buyer_name').val(data['2']);
				$('#order_date').val(data['3']);
			},
			error: function (textStatus, errorThrown) {
				//DO NOTHINIG
			}
		});
}

$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
	var actions = $("table td:last-child").html();
	// Append table with add row form on add new button click
    $(".add-new").click(function(){
	//	$(this).attr("disabled", "disabled");
		var index = $("table tbody tr:last-child").index();
        var row = '<tr>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Description"></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Composition"></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Proces loss"></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Rejection "></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Over Head"></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Courier & Forwarding"></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Profit"></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Commission"></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Convertion "></td>' +
            '<td><input type="text" class="form-control" id="fname" placeholder="Currency "></td>' +

        '</tr>';
    	$("table").append(row);
		$("table tbody tr").eq(index + 1).find(".add, .edit").toggle();
        $('[data-toggle="tooltip"]').tooltip();
    });
	// Add row on add button click
	$(document).on("click", ".add", function(){
		var empty = false;
		var input = $(this).parents("tr").find('input[type="text"]');
        input.each(function(){
		//	if(!$(this).val()){
		//		$(this).addClass("error");
		//		empty = true;
		//	} else{
        //        $(this).removeClass("error");
        //    }
		});
		$(this).parents("tr").find(".error").first().focus();
		if(!empty){
			input.each(function(){
				$(this).parent("td").html($(this).val());
			});
			$(this).parents("tr").find(".add, .edit").toggle();
			$(".add-new").removeAttr("disabled");
		}
    });
	// Edit row on edit button click
	$(document).on("click", ".edit", function(){
        $(this).parents("tr").find("td:not(:last-child)").each(function(){
			$(this).html('<input type="text" class="form-control" value="' + $(this).text() + '">');
		});
		$(this).parents("tr").find(".add, .edit").toggle();
		$(".add-new").attr("disabled", "disabled");
    });
	// Delete row on delete button click
	$(document).on("click", ".delete", function(){
        $(this).parents("tr").remove();
		$(".add-new").removeAttr("disabled");
    });
});
</script>
</body>
</html>