<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        .invoice {
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
            border: 1px solid #ccc;
            padding: 20px;
        }

        .header {
            text-align: center;
        }

        .invoice-title {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .invoice-details {
            margin-bottom: 20px;
        }

        .invoice-details p {
            margin: 0;
        }

        .row {
            display: flex;
            justify-content: space-between;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        .total {
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="invoice">
        <div class="header">
            <h1>Invoice</h1>
        </div>
        <div class="row">
            <div class="invoice-details">
                <p><strong>Invoice Number:</strong> INV-123456</p>
                <p><strong>Invoice Date:</strong> October 15, 2023</p>
                <p><strong>Due Date:</strong> October 30, 2023</p>
            </div>
            <div class="invoice-details">
                <p><strong>Invoice Number:</strong> INV-123457</p>
                <p><strong>Invoice Date:</strong> October 16, 2023</p>
                <p><strong>Due Date:</strong> October 31, 2023</p>
            </div>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Description</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Item 1</td>
                    <td>Description 1</td>
                    <td>2</td>
                    <td>$50.00</td>
                    <td>$100.00</td>
                </tr>
                <tr>
                    <td>Item 2</td>
                    <td>Description 2</td>
                    <td>1</td>
                    <td>$75.00</td>
                    <td>$75.00</td>
                </tr>
            </tbody>
        </table>
        <div class="total">
            <p><strong>Subtotal:</strong> $175.00</p>
            <p><strong>Tax (10%):</strong> $17.50</p>
            <p><strong>Total:</strong> $192.50</p>
        </div>
    </div>
</body>
</html>
